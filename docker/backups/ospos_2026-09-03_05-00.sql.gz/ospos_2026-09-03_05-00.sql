/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','number'),
('barcode_first_row','category'),
('barcode_font','fontawesome-webfont.ttf'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','1'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C39'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','0'),
('category_dropdown',''),
('company','Ghazi Trader'),
('company_logo','pngegg.png'),
('country_codes','pk'),
('currency_code','PKR'),
('currency_decimals','2'),
('currency_symbol','Rs'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format',''),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category','Standard'),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','0'),
('dinner_table_enable','0'),
('email','usman@gmail.com'),
('email_receipt_check_behaviour','last'),
('enforce_privacy','0'),
('fax',''),
('financial_year','1'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','gif,jpg,png'),
('image_max_height','480'),
('image_max_size','128'),
('image_max_width','640'),
('include_hsn','0'),
('invoice_default_comments','This is a default comment'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','0'),
('last_used_quote_number','1'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form',''),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('phone','+923015804375'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','last'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','12'),
('receipt_show_company_name','1'),
('receipt_show_description','1'),
('receipt_show_serialnumber','1'),
('receipt_show_taxes','0'),
('receipt_show_tax_ind','0'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_short'),
('receiving_calculate_average_price',''),
('recv_invoice_format','{CO}'),
('return_policy','Test'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id',''),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','Asia/Karachi'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Company','DROPDOWN',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,NULL,NULL,NULL,NULL),
(2,1,NULL,NULL,NULL,NULL),
(2,1,3,NULL,1,NULL),
(2,1,3,NULL,NULL,'1-3');
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,'FFC',NULL,NULL),
(2,'FFC2',NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-08-28 17:53:43','2026-08-28 17:53:43',12000.00,2000.00,1,10000.00,3000.00,0.00,0.00,'',1,1,0,1000.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(3,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-02 14:38:53',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('usman','$2y$10$ZvVKAzhXryVPTpyt41nE0uUt4Cy5ABsKWCbO45hEHRQYKQwTYx5Iq',1,0,2,'','');
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
INSERT INTO `ospos_expense_categories` VALUES
(1,'FFC','New Expens',0);
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
INSERT INTO `ospos_giftcards` VALUES
('2026-09-02 14:42:34',1,'455413123121312',50.00,0,3);
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_Shop',1,'--'),
('items_Warehouse',1,'--'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_Shop',1,'--'),
('receivings_Warehouse',1,'--'),
('reports',1,'home'),
('reports_categories',1,'--'),
('reports_customers',1,'--'),
('reports_discounts',1,'--'),
('reports_employees',1,'--'),
('reports_expenses_categories',1,'--'),
('reports_inventory',1,'--'),
('reports_items',1,'--'),
('reports_payments',1,'--'),
('reports_receivings',1,'--'),
('reports_sales',1,'--'),
('reports_sales_taxes',1,'--'),
('reports_suppliers',1,'--'),
('reports_taxes',1,'--'),
('sales',1,'home'),
('sales_change_price',1,'--'),
('sales_delete',1,'--'),
('sales_Shop',1,'--'),
('sales_Warehouse',1,'--'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',1,20.000),
(2,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',2,10.000),
(3,1,1,'2026-08-28 16:47:27','POS 1',1,-1.000),
(4,1,1,'2026-08-28 16:50:56','Manual Edit of Quantity',2,-10.000),
(5,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',1,80.000),
(6,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',2,0.000),
(7,1,1,'2026-08-28 16:54:53','POS 2',1,-1.000),
(8,1,1,'2026-08-28 16:57:10','POS 3',1,-1.000),
(9,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',1,100.000),
(10,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',2,0.000),
(11,3,1,'2026-08-28 17:57:35','RECV 1',1,6000.000),
(12,3,1,'2026-08-30 10:48:38','Manual Edit of Quantity',2,40.000),
(13,2,1,'2026-08-30 10:49:11','Manual Edit of Quantity',2,20.000),
(14,1,1,'2026-08-30 10:50:47','Manual Edit of Quantity',2,12.000),
(15,3,1,'2026-08-30 10:51:09','Manual Edit of Quantity',1,-5500.000),
(16,1,1,'2026-09-02 14:39:45','POS 4',2,-10.000),
(17,1,1,'2026-09-02 14:41:47','POS 5',1,5.000),
(18,1,1,'2026-09-02 14:44:04','POS 6',1,-5.000),
(19,2,1,'2026-09-02 15:42:27','POS 7',1,-1.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,17.000),
(1,2,2.000),
(2,1,79.000),
(2,2,20.000),
(3,1,600.000),
(3,2,40.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Cocke Half Leter','Beverage',NULL,'123','',20.00,20.00,1.000,1.000,1,NULL,0,0,0,0,0,NULL,1.000,'Each',1,''),
('Cocke Leter','Beverage',NULL,NULL,'',80.00,0.00,1.000,4000.000,2,NULL,0,0,0,0,0,NULL,1.000,'Each',2,''),
('Sprite','Beverage',NULL,'12312-123123','',500.00,600.00,1.000,50.000,3,NULL,0,0,0,0,0,NULL,1.000,'Each',3,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1787915084,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1787915084,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1787915084,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1787915084,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1787915084,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1787915084,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1787915084,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1787915084,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1787915084,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1787915084,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1787915084,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1787915084,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1787915084,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1787915084,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1787915084,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1787915084,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1787915084,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1787915084,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1787915084,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1787915084,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1787915084,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1787915084,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1787915084,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1787915084,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1787915084,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1787915084,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1787915084,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1787915085,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1787915085,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1787915085,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1787915085,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1787915085,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1787915085,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1787915085,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1787915085,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1787915085,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1787915085,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1787915085,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1787915085,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1787915085,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1787915085,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1787915085,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1787915085,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1787915085,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1787915085,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('Usman','IlamDin',1,'+923014567595','usman65@gmail.com','Address 1','','','','','','',1),
('Alex','Alex',1,'','','','','','','','','',2),
('WalkIN','WalkIN',NULL,'','','','','','','','','',3);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_Shop','items',2),
('items_Warehouse','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_Shop','receivings',2),
('receivings_Warehouse','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_Shop','sales',2),
('sales_Warehouse','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
INSERT INTO `ospos_receivings` VALUES
('2026-08-28 17:57:35',2,1,'',1,'Cash','123123123');
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
INSERT INTO `ospos_receivings_items` VALUES
(1,3,'','',1,120.000,500.00,500.00,0.00,0,1,50.000);
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-08-28 16:47:27',NULL,1,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-08-28 16:54:53',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-08-28 16:57:10',NULL,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-02 14:39:45',3,1,'This is the final sale of the person\n\n','0',NULL,4,'Q26000001',0,NULL,1),
('2026-09-02 14:41:47',NULL,1,'',NULL,NULL,5,NULL,0,NULL,4),
('2026-09-02 14:44:04',3,1,'',NULL,NULL,6,NULL,0,NULL,0),
('2026-09-02 15:42:27',NULL,1,'',NULL,NULL,7,NULL,0,NULL,0);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,1.000,0.00,0.00,0.00,0,1,0),
(2,1,'','',1,1.000,20.00,20.00,0.00,0,1,0),
(3,1,'','',2,1.000,20.00,20.00,0.00,0,1,0),
(4,1,'','',1,10.000,20.00,567.00,0.00,0,2,0),
(5,1,'','',1,-5.000,20.00,20.00,0.00,0,1,0),
(6,1,'','',1,5.000,20.00,10.00,0.00,0,1,0),
(7,2,'','',1,1.000,80.00,100.00,0.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,2,'Cash',20.00,0.00,0,1,'2026-08-28 11:54:53',''),
(2,3,'Cash',100.00,80.00,0,1,'2026-08-28 11:57:10',''),
(4,5,'Cash',-100.00,0.00,0,1,'2026-09-02 09:41:47',''),
(5,6,'Cash',50.00,0.00,0,1,'2026-09-02 09:44:04',''),
(6,7,'Cash',100.00,0.00,0,1,'2026-09-02 10:42:27','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:075b59f0f1ec0a96e695fdecc366f747','127.0.0.1','2026-09-02 10:23:57','__ci_last_regenerate|i:1788344637;csrf_ospos_v4|s:32:\"21fcfebabea34c7985940b3843ff5cfe\";'),
('ospos_session:0a8e41cbfdcb03278fa079b099ec201e','127.0.0.1','2026-09-02 09:40:44','__ci_last_regenerate|i:1788342044;csrf_ospos_v4|s:32:\"6f8abf93e1e0a0f881ee259ab7a0c371\";'),
('ospos_session:0aa789716b9e40b5cbe6efd38e8944d3','127.0.0.1','2026-09-02 09:54:51','__ci_last_regenerate|i:1788342891;csrf_ospos_v4|s:32:\"9afa9aae43157ea07a7afe4745153d7e\";'),
('ospos_session:0b85373fa22b06045b5ee2e1b597662c','127.0.0.1','2026-09-02 10:02:21','__ci_last_regenerate|i:1788343341;csrf_ospos_v4|s:32:\"37bc442fdab86c434fb65af8e713ebf0\";'),
('ospos_session:0bd0a593914515cbff9fe5d3eab4079c','127.0.0.1','2026-09-02 09:51:20','__ci_last_regenerate|i:1788342680;csrf_ospos_v4|s:32:\"ec20702f8c28da64ba1e58eeca127315\";'),
('ospos_session:0bddb7e8db47d6f860872295d6c4a117','127.0.0.1','2026-09-02 10:11:40','__ci_last_regenerate|i:1788343900;csrf_ospos_v4|s:32:\"55c0a8cdd62d82c33242cb23b83da427\";'),
('ospos_session:0c50807599927fd0649d727b66504cea','127.0.0.1','2026-09-02 10:38:47','__ci_last_regenerate|i:1788345527;csrf_ospos_v4|s:32:\"9a74707c7127973344a93bfd66a29e71\";'),
('ospos_session:0f2ac94421abe183407a3e2c9d6a1ea7','127.0.0.1','2026-09-02 09:47:45','__ci_last_regenerate|i:1788342465;csrf_ospos_v4|s:32:\"b0c470d030a0e01329a6c09a5ed56ce1\";'),
('ospos_session:108eddb0bf80997df6258f43ecb52d16','127.0.0.1','2026-09-02 10:43:18','__ci_last_regenerate|i:1788345798;csrf_ospos_v4|s:32:\"97f2430f9f2a7d3f7018e8413ac2ed60\";'),
('ospos_session:11399aa72509a7a644593259af3fb469','172.22.0.3','2026-09-02 10:21:29','__ci_last_regenerate|i:1788344489;csrf_ospos_v4|s:32:\"a0ffa8ba11d1ffc2f48c06488d1e88bd\";'),
('ospos_session:135984dfed2d90849103d05865f5c064','127.0.0.1','2026-09-02 10:47:48','__ci_last_regenerate|i:1788346068;csrf_ospos_v4|s:32:\"0e5693e2c0499ba0a83f7e9ca5cf21ea\";'),
('ospos_session:1575f456691f722131a38812dd733797','127.0.0.1','2026-09-02 09:38:44','__ci_last_regenerate|i:1788341924;csrf_ospos_v4|s:32:\"ed5e9993fc31f1ed76af77a375d591d8\";'),
('ospos_session:15eab2fe9a174598b4a3e74a0caf89b1','127.0.0.1','2026-09-02 09:35:44','__ci_last_regenerate|i:1788341744;csrf_ospos_v4|s:32:\"31085748dbc6e9e2684dae1d69b92b11\";'),
('ospos_session:16b94931dfac3c1af1e680ac895d465f','127.0.0.1','2026-09-02 09:58:51','__ci_last_regenerate|i:1788343131;csrf_ospos_v4|s:32:\"cf65afe1ebcf3fd529d00d31e3ca0fc3\";'),
('ospos_session:1abeb8e21602dd9f2680228679407a56','127.0.0.1','2026-09-02 10:20:22','__ci_last_regenerate|i:1788344422;csrf_ospos_v4|s:32:\"55f17c48161ca46542326d3ef5b05ef6\";'),
('ospos_session:1ef181b4165ae705ae7c333d50921757','127.0.0.1','2026-09-02 10:46:18','__ci_last_regenerate|i:1788345978;csrf_ospos_v4|s:32:\"b7a2a202591bab76c346d77e1e752c0f\";'),
('ospos_session:20acf03b3939ec2c8809c768b6e00105','127.0.0.1','2026-09-02 09:51:50','__ci_last_regenerate|i:1788342710;csrf_ospos_v4|s:32:\"ae74a8dc0461a882550aeda1df66ab88\";'),
('ospos_session:255db4ae48a44d446e9a2f423ea82a52','127.0.0.1','2026-09-02 10:35:04','__ci_last_regenerate|i:1788345304;csrf_ospos_v4|s:32:\"c340ca2794d4dd1181c09391fcfb9d20\";'),
('ospos_session:25f6c8be63543bad4f3975f44706bb60','127.0.0.1','2026-09-02 10:03:52','__ci_last_regenerate|i:1788343432;csrf_ospos_v4|s:32:\"1b6e0990c755e3e87ea264ada4696bba\";'),
('ospos_session:2691829224db3e44c1b31d5de59814cb','127.0.0.1','2026-09-02 10:01:51','__ci_last_regenerate|i:1788343311;csrf_ospos_v4|s:32:\"6282a14b6b7bc7b54a300ddc24a771dc\";'),
('ospos_session:27795ba3fc36c0d5452e40bc4e4ecdbd','127.0.0.1','2026-09-02 09:33:13','__ci_last_regenerate|i:1788341593;csrf_ospos_v4|s:32:\"1dcb7930195bb30f6364013fe6a774a9\";'),
('ospos_session:28418cc676a078d17da18abf4669a4d8','127.0.0.1','2026-09-02 10:04:22','__ci_last_regenerate|i:1788343462;csrf_ospos_v4|s:32:\"fcf2999f2a34b98c6c8dbcb65851cb78\";'),
('ospos_session:28e6abc119c9bc57808a45b3373bf087','127.0.0.1','2026-09-02 10:20:52','__ci_last_regenerate|i:1788344452;csrf_ospos_v4|s:32:\"66af329fd25c1fc906ca040fe617c9b9\";'),
('ospos_session:2943c24978efcfc8219f0cd347e3ad89','127.0.0.1','2026-09-02 10:09:09','__ci_last_regenerate|i:1788343749;csrf_ospos_v4|s:32:\"59319e6a2dbb79a60c2b55b9217283af\";'),
('ospos_session:2a8dc513075a080ae20318040d7e2862','127.0.0.1','2026-09-02 10:06:22','__ci_last_regenerate|i:1788343582;csrf_ospos_v4|s:32:\"48d17159090728a072bc43b97fe8e840\";'),
('ospos_session:2fbed42cf25af2538224bdc755c2b101','127.0.0.1','2026-09-02 09:37:44','__ci_last_regenerate|i:1788341864;csrf_ospos_v4|s:32:\"97ba787dc7bb5a984f31c18c5150f84b\";'),
('ospos_session:300152b541bfbf3227472ebc8cc4529d','127.0.0.1','2026-09-02 10:37:47','__ci_last_regenerate|i:1788345467;csrf_ospos_v4|s:32:\"3681f9958e61297b208f656be1393f81\";'),
('ospos_session:3525f483d5ff3c62646c1f1c4c91f2d3','127.0.0.1','2026-09-02 10:07:22','__ci_last_regenerate|i:1788343642;csrf_ospos_v4|s:32:\"0a914dd8f74a01b7a678a955031c1df9\";'),
('ospos_session:372360c4cdb71ee2463a869524394403','172.22.0.3','2026-09-02 10:14:10','__ci_last_regenerate|i:1788344050;csrf_ospos_v4|s:32:\"f3cf199d320de23ec820e4cd217f88e9\";'),
('ospos_session:3abbf73be89f97fd81fc530e50639b24','127.0.0.1','2026-09-02 10:49:19','__ci_last_regenerate|i:1788346159;csrf_ospos_v4|s:32:\"84f95d357fb57ed9470162d214522ce6\";'),
('ospos_session:3b3a27bb34f3920c0dcf4635b1ebf5da','127.0.0.1','2026-09-02 09:52:20','__ci_last_regenerate|i:1788342740;csrf_ospos_v4|s:32:\"42b3de41aedab351bfe8f49f82a559c3\";'),
('ospos_session:3be22e70c1209b8fd10d16bc09746954','127.0.0.1','2026-09-02 10:22:22','__ci_last_regenerate|i:1788344542;csrf_ospos_v4|s:32:\"e650c8afed7f7dff081735edf9574d3f\";'),
('ospos_session:3cdaea5bce45be74df3118c4720581e0','127.0.0.1','2026-09-02 10:04:52','__ci_last_regenerate|i:1788343492;csrf_ospos_v4|s:32:\"b62d1438b5f82fae243d8c74babbc719\";'),
('ospos_session:3db40fe3f3418cb5d536c9349c18caa8','127.0.0.1','2026-09-02 10:36:47','__ci_last_regenerate|i:1788345407;csrf_ospos_v4|s:32:\"acd9a2194acbaad6c14d4401b0964492\";'),
('ospos_session:3e402655fa213dff8fd7f677f49f1753','127.0.0.1','2026-09-02 10:25:55','__ci_last_regenerate|i:1788344755;csrf_ospos_v4|s:32:\"51e89c0cc861d499f5a07ebae1c2e034\";'),
('ospos_session:421f9c3c82052748215cf96e93613bf3','127.0.0.1','2026-09-02 09:42:14','__ci_last_regenerate|i:1788342134;csrf_ospos_v4|s:32:\"c4cc24f8daa53812d4455800462bb39f\";'),
('ospos_session:435f1c9ac405754b005ccda9ea3456d0','127.0.0.1','2026-09-02 09:45:15','__ci_last_regenerate|i:1788342315;csrf_ospos_v4|s:32:\"e4c5642a92cdf40469d3db924e6944d9\";'),
('ospos_session:4391efeab8e31c1fd0dd1290d7ea035d','127.0.0.1','2026-09-02 10:35:16','__ci_last_regenerate|i:1788345316;csrf_ospos_v4|s:32:\"c43961046f07bfb57d57a4c009b8562c\";'),
('ospos_session:44af53e13310846331ee547a090152b9','127.0.0.1','2026-09-02 10:24:57','__ci_last_regenerate|i:1788344697;csrf_ospos_v4|s:32:\"367bb15b14813ccdb9882a548f653174\";'),
('ospos_session:45a604e008451fa168f8c987e1c964a5','127.0.0.1','2026-09-02 10:32:26','__ci_last_regenerate|i:1788345146;csrf_ospos_v4|s:32:\"9a942c43e344dbc47fabf335cf92e4da\";'),
('ospos_session:460461d046885dd5c1eff95ef108973a','127.0.0.1','2026-09-02 09:48:15','__ci_last_regenerate|i:1788342495;csrf_ospos_v4|s:32:\"4bd64f06b0d78b1a58a8a8854d744476\";'),
('ospos_session:477bffdee975369012dbb2b58961ce4d','127.0.0.1','2026-09-02 10:00:21','__ci_last_regenerate|i:1788343221;csrf_ospos_v4|s:32:\"391d1a30141ef380d59392adcf08f8e8\";'),
('ospos_session:4808c8c226a6835c71fd57fb817cb2bf','127.0.0.1','2026-09-02 10:13:10','__ci_last_regenerate|i:1788343990;csrf_ospos_v4|s:32:\"9960c36ca29537b8d12faec4fea60087\";'),
('ospos_session:4a7fdf048c2f4cf7aa0bcb2a4a4f89e0','127.0.0.1','2026-09-02 09:58:21','__ci_last_regenerate|i:1788343101;csrf_ospos_v4|s:32:\"4b0f4d5d7fb4ae093720704eac7395f8\";'),
('ospos_session:4f48630166ae1f0b58688eb7469a662f','127.0.0.1','2026-09-02 10:09:39','__ci_last_regenerate|i:1788343779;csrf_ospos_v4|s:32:\"f983e711e336baaad89fa22f05b73eff\";'),
('ospos_session:5721ebfbdd95d5eb49dcaabb1f65ef27','127.0.0.1','2026-09-02 09:34:14','__ci_last_regenerate|i:1788341654;csrf_ospos_v4|s:32:\"799e504bb33d6f420a75234311be715c\";'),
('ospos_session:57d3674f829636fe22a2aa94f23fca72','127.0.0.1','2026-09-02 09:49:15','__ci_last_regenerate|i:1788342555;csrf_ospos_v4|s:32:\"5ea3692329e18812426a5a12419d12c6\";'),
('ospos_session:5c597b357e57448a737f82e675135dfe','127.0.0.1','2026-09-02 10:34:03','__ci_last_regenerate|i:1788345243;csrf_ospos_v4|s:32:\"1d62baf8f869115661d0132d52cee1e3\";'),
('ospos_session:6388a3b061b8dea1a0bb27f1f62369b3','127.0.0.1','2026-09-02 10:21:22','__ci_last_regenerate|i:1788344482;csrf_ospos_v4|s:32:\"e873d4ee02e7ead6b58e66a8f6063d81\";'),
('ospos_session:649ed3858dcf145dc537fdd418cc6f47','172.22.0.3','2026-09-02 10:30:22','__ci_last_regenerate|i:1788345022;csrf_ospos_v4|s:32:\"c0aa9b42a2eba76dc2a178828197de72\";_ci_previous_url|s:29:\"https://ghazi-pos.local/login\";'),
('ospos_session:64a8b25b9a1b5cb27dc835bc7ef6cd5f','127.0.0.1','2026-09-02 10:19:51','__ci_last_regenerate|i:1788344391;csrf_ospos_v4|s:32:\"f0574d9383ddace6c1fa71ac9aa73e9d\";'),
('ospos_session:662e6f0364d7953f42bd810933d5521c','127.0.0.1','2026-09-02 10:33:03','__ci_last_regenerate|i:1788345183;csrf_ospos_v4|s:32:\"23cfe5c965b0df383fe73ad8dc32185b\";'),
('ospos_session:663b94f69d93234f9ed6fb6144a27e3f','127.0.0.1','2026-09-02 10:29:26','__ci_last_regenerate|i:1788344966;csrf_ospos_v4|s:32:\"4690282cefe4bd2e718fa13410f1b79f\";'),
('ospos_session:6a18b6abe3daca7183a512089bb387a8','127.0.0.1','2026-09-02 10:26:55','__ci_last_regenerate|i:1788344815;csrf_ospos_v4|s:32:\"682a7e165da7d0c0ac28ceb48295b953\";'),
('ospos_session:6ea779221fb8f463b67a408148834fca','127.0.0.1','2026-09-02 09:57:51','__ci_last_regenerate|i:1788343071;csrf_ospos_v4|s:32:\"acdb65604be60df4d39a77bf631a90f0\";'),
('ospos_session:6eea741ad21d948f6c9a1b43589943f2','127.0.0.1','2026-09-02 10:30:26','__ci_last_regenerate|i:1788345026;csrf_ospos_v4|s:32:\"a7b201e2bc1a6857cdd09485fdd8ebaa\";'),
('ospos_session:6f062f4f3418c787bbf771f82ed0c1dc','127.0.0.1','2026-09-02 10:27:55','__ci_last_regenerate|i:1788344875;csrf_ospos_v4|s:32:\"e20c7f60c7aa77d1fad576ec04228424\";'),
('ospos_session:6f19f525aa890708d6bbf50d17fb43b3','127.0.0.1','2026-09-02 10:05:22','__ci_last_regenerate|i:1788343522;csrf_ospos_v4|s:32:\"29f46c1956b2b3d862069b07cc573cb7\";'),
('ospos_session:71e612e9894719971ab0d102bd35cc15','127.0.0.1','2026-09-02 09:46:15','__ci_last_regenerate|i:1788342375;csrf_ospos_v4|s:32:\"b9510b50e6deab331b46b78b13a64bbc\";'),
('ospos_session:731eecb3c04e3720df5e206d4dcffb74','127.0.0.1','2026-09-02 10:38:17','__ci_last_regenerate|i:1788345497;csrf_ospos_v4|s:32:\"def620e0905c00697d0661b0b06e0e93\";'),
('ospos_session:74bf71fb5ff4708a19975f36a84af744','127.0.0.1','2026-09-02 10:39:17','__ci_last_regenerate|i:1788345557;csrf_ospos_v4|s:32:\"5d6ce927d26dbd2acce7b6c3e95b66b2\";'),
('ospos_session:76244966ddad2c957c268ef3635b3d3a','127.0.0.1','2026-09-02 09:34:44','__ci_last_regenerate|i:1788341684;csrf_ospos_v4|s:32:\"786371135c146c1c1f2084d4aa89903a\";'),
('ospos_session:76436b1db3cec6883897b06e565a3278','127.0.0.1','2026-09-02 10:03:22','__ci_last_regenerate|i:1788343402;csrf_ospos_v4|s:32:\"81fa0003e31c1d41cb4ae9e0db682d8f\";'),
('ospos_session:76b96963920188bc34f4099f5d670f68','127.0.0.1','2026-09-02 09:43:45','__ci_last_regenerate|i:1788342225;csrf_ospos_v4|s:32:\"4e07cd906e388b9e519fd30c94af852f\";'),
('ospos_session:77b58249ebd260e0a72f535f155601d3','127.0.0.1','2026-09-02 10:31:26','__ci_last_regenerate|i:1788345086;csrf_ospos_v4|s:32:\"ef8f01092f8d5312d55afc6541dd1a0f\";'),
('ospos_session:77e85e76c04008c4a0e39af2f6a15d6f','127.0.0.1','2026-09-02 10:18:51','__ci_last_regenerate|i:1788344331;csrf_ospos_v4|s:32:\"e28489f20e973082b00ab93d886ab8df\";'),
('ospos_session:790a37760aee576878f9aec4dad71b6e','127.0.0.1','2026-09-02 10:02:52','__ci_last_regenerate|i:1788343372;csrf_ospos_v4|s:32:\"8c90c3bbfbdedb597d796c905982314a\";'),
('ospos_session:79a34a3c59f4c7a5a3e4dcf5e4839c2f','127.0.0.1','2026-09-02 09:54:21','__ci_last_regenerate|i:1788342861;csrf_ospos_v4|s:32:\"80b9b169d168b3885fde253acec82bd3\";'),
('ospos_session:7a4676d95e69e027f048034449d796ac','172.22.0.3','2026-09-02 10:50:12','__ci_last_regenerate|i:1788346212;csrf_ospos_v4|s:32:\"78b730fc5958fc0c5249672fb0305aa0\";_ci_previous_url|s:28:\"https://ghazi-pos.local/home\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:1;item_location|s:1:\"2\";recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_stock_source|i:1;recv_stock_destination|s:1:\"1\";recv_supplier|i:-1;sale_id|i:-1;sales_location|i:1;sales_employee|i:1;cash_adjustment_amount|d:0;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:0:{}sales_customer|i:-1;sales_mode|s:4:\"sale\";sales_payments|a:0:{}'),
('ospos_session:7ad1aacd8b70c4089e6318116deda0a9','172.22.0.3','2026-09-02 10:22:27','__ci_last_regenerate|i:1788344547;csrf_ospos_v4|s:32:\"a10d67df6370d4579d38fc02668f8be7\";'),
('ospos_session:7b575d72a92850c893ce34742f53c1ee','127.0.0.1','2026-09-02 09:36:44','__ci_last_regenerate|i:1788341804;csrf_ospos_v4|s:32:\"4b87d4e1111fa8510f74f8fc935d3daa\";'),
('ospos_session:7f1416b2ee71d8170617e5771ed09d60','127.0.0.1','2026-09-02 09:43:15','__ci_last_regenerate|i:1788342195;csrf_ospos_v4|s:32:\"adc8de2f8dae418a7755c134c1644e0e\";'),
('ospos_session:82b4da09716b66e0fde0c14cd2f3b01d','127.0.0.1','2026-09-02 10:35:47','__ci_last_regenerate|i:1788345347;csrf_ospos_v4|s:32:\"7ae1139da49ad1e8970c8a2d51383b91\";'),
('ospos_session:82f713986376578027463a9c2bd2a2bb','127.0.0.1','2026-09-02 10:27:25','__ci_last_regenerate|i:1788344845;csrf_ospos_v4|s:32:\"4c8580b7341d0fff8b38aab167c3fd6c\";'),
('ospos_session:84308488361e8a5d790f423b8086d4f3','127.0.0.1','2026-09-02 10:08:09','__ci_last_regenerate|i:1788343689;csrf_ospos_v4|s:32:\"e609b2a8d2a535b2d1eca67c7b2f0250\";'),
('ospos_session:867bfb7a20f46f9c08ed12ea97410d96','127.0.0.1','2026-09-02 09:49:45','__ci_last_regenerate|i:1788342585;csrf_ospos_v4|s:32:\"784c57c32f8ddad95146ba713e44ee06\";'),
('ospos_session:8683c736adb9317e466ee7af6f71c81b','127.0.0.1','2026-09-02 10:40:17','__ci_last_regenerate|i:1788345617;csrf_ospos_v4|s:32:\"64633a999db445a026a0a44d954d5065\";'),
('ospos_session:87835426c2a08e486c3503bd96696e79','127.0.0.1','2026-09-02 10:37:17','__ci_last_regenerate|i:1788345437;csrf_ospos_v4|s:32:\"8270400d81e8d591e3bbd322d277f652\";'),
('ospos_session:88432157ea86356255e6d5cfbaa45d5e','127.0.0.1','2026-09-02 09:48:45','__ci_last_regenerate|i:1788342525;csrf_ospos_v4|s:32:\"8404e443e79a33e3e58fc38982106fb6\";'),
('ospos_session:88d0400d52082c677f964e837071cd50','127.0.0.1','2026-09-02 10:00:51','__ci_last_regenerate|i:1788343251;csrf_ospos_v4|s:32:\"f05296b9c16f7bb2036b361e34a29fc1\";'),
('ospos_session:89e3d31ee60dced80c93b448f4867399','127.0.0.1','2026-09-02 09:50:50','__ci_last_regenerate|i:1788342650;csrf_ospos_v4|s:32:\"71068773d7755211a27a8e58bac8ccb9\";'),
('ospos_session:8a7a565152e99efb16693c65db8fcd68','127.0.0.1','2026-09-02 10:32:56','__ci_last_regenerate|i:1788345176;csrf_ospos_v4|s:32:\"3446dff7f9ee8d58f35cb9b2bc75cfd5\";'),
('ospos_session:8a975b6454a5d074ad33e204b8bc1c34','127.0.0.1','2026-09-02 10:13:21','__ci_last_regenerate|i:1788344001;csrf_ospos_v4|s:32:\"ce88b624db2f04f1e287a7397298be8a\";'),
('ospos_session:8a98f7c297905b6e26a483941bd8075b','127.0.0.1','2026-09-02 10:08:39','__ci_last_regenerate|i:1788343719;csrf_ospos_v4|s:32:\"f881295d5fbd22bf59ebfa667b42dfd4\";'),
('ospos_session:8ac3ff166929acb2e755f987a65d684a','127.0.0.1','2026-09-02 09:53:50','__ci_last_regenerate|i:1788342830;csrf_ospos_v4|s:32:\"25d8910f3489642229ad5917a23b4bb5\";'),
('ospos_session:8dc72a18d2377a4d05044bd37f502685','127.0.0.1','2026-09-02 10:42:48','__ci_last_regenerate|i:1788345768;csrf_ospos_v4|s:32:\"5d93e1499786db8a275e3beff5110266\";'),
('ospos_session:8e1e9e7f26a32cf06e8b76ce0c60d13f','127.0.0.1','2026-09-02 10:14:51','__ci_last_regenerate|i:1788344091;csrf_ospos_v4|s:32:\"a361ae3d1b0fe1b8d32da1497f249cf8\";'),
('ospos_session:8e53cd3e27319af012c1c1a4518e80dc','127.0.0.1','2026-09-02 09:59:21','__ci_last_regenerate|i:1788343161;csrf_ospos_v4|s:32:\"0a9488a6f93061e8e9b80ff9f79c081b\";'),
('ospos_session:8f73b718a881fe87a80c63c5083adfe5','127.0.0.1','2026-09-02 10:16:21','__ci_last_regenerate|i:1788344181;csrf_ospos_v4|s:32:\"4f56a5753f76dee46c2f22a9528b624a\";'),
('ospos_session:90d792d485516816668c818f150f5e0b','127.0.0.1','2026-09-02 09:46:45','__ci_last_regenerate|i:1788342405;csrf_ospos_v4|s:32:\"af6a17b8172f2e65dcb4c3768ba73c45\";'),
('ospos_session:9228b9a34163dd20cfcb8d7ee2fa5335','127.0.0.1','2026-09-02 09:44:15','__ci_last_regenerate|i:1788342255;csrf_ospos_v4|s:32:\"228067ff011acbf453d46b55304fc555\";'),
('ospos_session:928d688eaabbdda374b42f2dda0632c9','127.0.0.1','2026-09-02 10:17:51','__ci_last_regenerate|i:1788344271;csrf_ospos_v4|s:32:\"4b414e8560895e030af4273f60cd89c1\";'),
('ospos_session:9304864beeead209804805281fbfe576','127.0.0.1','2026-09-02 10:15:21','__ci_last_regenerate|i:1788344121;csrf_ospos_v4|s:32:\"57d2dab13a4c3b87fd2ae5f2ab6511f8\";'),
('ospos_session:93784b6b2d71aeb77cf0f8072f260449','127.0.0.1','2026-09-02 10:07:52','__ci_last_regenerate|i:1788343672;csrf_ospos_v4|s:32:\"2c38806c0415147b9970640a78ca2467\";'),
('ospos_session:93f77b398d539bbf20a2af360f975969','127.0.0.1','2026-09-02 10:06:52','__ci_last_regenerate|i:1788343612;csrf_ospos_v4|s:32:\"36518c24c093eb1f0ccb66482e6a2be6\";'),
('ospos_session:95e031c62f39d27d41217931d4503576','127.0.0.1','2026-09-02 10:43:48','__ci_last_regenerate|i:1788345828;csrf_ospos_v4|s:32:\"0127bcf9f2d44151b9d534b86aa5be73\";'),
('ospos_session:97b249e0055ffded8ef3693e06c6367c','127.0.0.1','2026-09-02 10:26:25','__ci_last_regenerate|i:1788344785;csrf_ospos_v4|s:32:\"44d4549dd6e60d222ad49bd8d2fbd84b\";'),
('ospos_session:9b5d939a399cc7dd26fa5273d6a75a25','127.0.0.1','2026-09-02 10:46:48','__ci_last_regenerate|i:1788346008;csrf_ospos_v4|s:32:\"dbf48f1a23781c88f85642896a689c6e\";'),
('ospos_session:9de6bce977a2007af40fb4eaf2824647','127.0.0.1','2026-09-02 10:21:52','__ci_last_regenerate|i:1788344512;csrf_ospos_v4|s:32:\"64864f4da8ad60987814e8b6d06f589c\";'),
('ospos_session:a1e73361558f52ad5926c3cc707a4657','127.0.0.1','2026-09-02 10:31:56','__ci_last_regenerate|i:1788345116;csrf_ospos_v4|s:32:\"c53407aaf6c437182ff8749bfd00ecb7\";'),
('ospos_session:a31e1e59f90b4c72381a0cea1c209269','127.0.0.1','2026-09-02 09:38:14','__ci_last_regenerate|i:1788341894;csrf_ospos_v4|s:32:\"d03ca5377eb57046d20a6a44c6e93181\";'),
('ospos_session:a78858a181dfc36e7d6e278f79216bea','127.0.0.1','2026-09-02 09:52:50','__ci_last_regenerate|i:1788342770;csrf_ospos_v4|s:32:\"fda5f55e09f04e93d22515857f90d664\";'),
('ospos_session:a8349fc0f7c88a65a0db17426f77ca6a','127.0.0.1','2026-09-02 10:23:27','__ci_last_regenerate|i:1788344607;csrf_ospos_v4|s:32:\"a98d7931c9478d351279661f9524d339\";'),
('ospos_session:ad7d83b1fe1aefacf0cfd43b93d1f51a','127.0.0.1','2026-09-02 09:39:44','__ci_last_regenerate|i:1788341984;csrf_ospos_v4|s:32:\"267e7b99e8e8bf3d543baf30ff455ab9\";'),
('ospos_session:ae90bb30fa7dffb608d88ddc2f0b3285','127.0.0.1','2026-09-02 10:48:48','__ci_last_regenerate|i:1788346128;csrf_ospos_v4|s:32:\"364bc3038ed1486b638ccd16cce13451\";'),
('ospos_session:b19311762b21ac93b1727cdf1c371bee','127.0.0.1','2026-09-02 10:10:09','__ci_last_regenerate|i:1788343809;csrf_ospos_v4|s:32:\"7d723649825796ba40cfc9717df0aa2d\";'),
('ospos_session:b4f99bc2c7a1ac178ccb70a8e2730268','127.0.0.1','2026-09-02 09:57:21','__ci_last_regenerate|i:1788343041;csrf_ospos_v4|s:32:\"eb389974f7cec6f2c1137fe455625d94\";'),
('ospos_session:b5e7bfdf92ccb0eea628f894eb7404f8','127.0.0.1','2026-09-02 10:19:21','__ci_last_regenerate|i:1788344361;csrf_ospos_v4|s:32:\"76ef4a34712d5a39a437d203eb4ef4e4\";'),
('ospos_session:b62bde98bcb185e9eae2ecf88f2e0851','127.0.0.1','2026-09-02 10:39:47','__ci_last_regenerate|i:1788345587;csrf_ospos_v4|s:32:\"65bcffa4f21f41fe3f0105c445917283\";'),
('ospos_session:b6b0c5d0955706d36e98d412c8d4800b','127.0.0.1','2026-09-02 10:17:21','__ci_last_regenerate|i:1788344241;csrf_ospos_v4|s:32:\"d1bdee886fcefa5d06fc4d42eff65679\";'),
('ospos_session:b89dd68cd3f16ef9669b490fefd86bb0','127.0.0.1','2026-09-02 10:24:27','__ci_last_regenerate|i:1788344667;csrf_ospos_v4|s:32:\"22c5cc0e3844195678f2b8568852acda\";'),
('ospos_session:be721b570823b1ba1c825c0b1a6c5d18','127.0.0.1','2026-09-02 10:28:56','__ci_last_regenerate|i:1788344936;csrf_ospos_v4|s:32:\"62bd9105415c6eae8c8faf1e8efe422d\";'),
('ospos_session:bf8a2595b4c10523eedad4c1766f339d','127.0.0.1','2026-09-02 10:34:33','__ci_last_regenerate|i:1788345273;csrf_ospos_v4|s:32:\"4d48dbd1088aed50e53767e99f042119\";'),
('ospos_session:bf8f3d15a805bf6b48d6021bd50e8cea','127.0.0.1','2026-09-02 09:35:14','__ci_last_regenerate|i:1788341714;csrf_ospos_v4|s:32:\"33348d4fa1b91fd9235bacaade89b2d5\";'),
('ospos_session:c0711581c51a7a7078d66649ff5114b0','127.0.0.1','2026-09-02 10:10:39','__ci_last_regenerate|i:1788343839;csrf_ospos_v4|s:32:\"09b440176213fab2d69aa74003c89985\";'),
('ospos_session:c0c0f3c24d69dafc252b4a4251296fc4','127.0.0.1','2026-09-02 10:13:51','__ci_last_regenerate|i:1788344031;csrf_ospos_v4|s:32:\"e2efa0c62316c328fa234f6f0a224ff4\";'),
('ospos_session:c360223598194c3ee86992b4d9bbdf1f','127.0.0.1','2026-09-02 10:29:56','__ci_last_regenerate|i:1788344996;csrf_ospos_v4|s:32:\"28d9a9f2c8a50eb6f7fbf045f8cf5eee\";'),
('ospos_session:c43044de0b9441966a2d4d08ed24c179','127.0.0.1','2026-09-02 09:45:45','__ci_last_regenerate|i:1788342345;csrf_ospos_v4|s:32:\"962cea4d778a959117e31d83aa1dabb4\";'),
('ospos_session:c5c0ebf2ea13a14614072112a72c328b','172.22.0.3','2026-09-02 10:29:53','__ci_last_regenerate|i:1788344960;csrf_ospos_v4|s:32:\"dcec58825ba2cd37d24e730a6a0272a6\";_ci_previous_url|s:29:\"https://ghazi-pos.local/login\";'),
('ospos_session:c98d6f60c4b42c5bc8dd316722049370','127.0.0.1','2026-09-02 10:22:52','__ci_last_regenerate|i:1788344572;csrf_ospos_v4|s:32:\"de0be484296adb6f206dcfc4527081ef\";'),
('ospos_session:cb416f8c7c738cf19b139391b29b27d6','172.22.0.2','2026-09-02 10:07:40','__ci_last_regenerate|i:1788343659;csrf_ospos_v4|s:32:\"90c6ca7ed6ed5b61989d3bdf9085b024\";_ci_previous_url|s:29:\"https://ghazi-pos.local/items\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:0;item_location|s:1:\"1\";sale_id|i:-1;sales_location|i:1;sales_print_after_sale|b:1;sales_employee|i:1;suspended_id|i:4;recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_stock_source|i:1;recv_stock_destination|s:1:\"1\";recv_supplier|i:-1;cash_adjustment_amount|d:0;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:0:{}sales_customer|i:-1;sales_mode|s:4:\"sale\";sales_payments|a:0:{}'),
('ospos_session:cbbfb248a75d4444037e0141e8349d1e','127.0.0.1','2026-09-02 10:41:17','__ci_last_regenerate|i:1788345677;csrf_ospos_v4|s:32:\"e66efad6b68b617936691e8ff12fd636\";'),
('ospos_session:ccb3d3b0a869933a7ab98daac882a0cf','127.0.0.1','2026-09-02 10:49:49','__ci_last_regenerate|i:1788346189;csrf_ospos_v4|s:32:\"8021674dc40ec9ada75be8a7bc679cc2\";'),
('ospos_session:cd3e3f338beba27a29202350529a6d3f','127.0.0.1','2026-09-02 10:36:17','__ci_last_regenerate|i:1788345377;csrf_ospos_v4|s:32:\"dc1b8b1fcabee039d91fa497ff2b17ef\";'),
('ospos_session:cf53e12904d6957e7e1f8901768fcd21','127.0.0.1','2026-09-02 10:44:18','__ci_last_regenerate|i:1788345858;csrf_ospos_v4|s:32:\"4a1740a3f854dcaf288b9a66833f2e65\";'),
('ospos_session:cfc2e17dd7fbb35e98f74e2257c87566','127.0.0.1','2026-09-02 09:33:44','__ci_last_regenerate|i:1788341624;csrf_ospos_v4|s:32:\"d526a356cdb96d26bd082a81e9f6711a\";'),
('ospos_session:d012a5894ddc0044247508b796251eae','127.0.0.1','2026-09-02 10:05:52','__ci_last_regenerate|i:1788343552;csrf_ospos_v4|s:32:\"5b1abc9506ab4eef216e3983605dbbf0\";'),
('ospos_session:d05685cb3b8e7087b60b33017cd2c746','127.0.0.1','2026-09-02 10:48:18','__ci_last_regenerate|i:1788346098;csrf_ospos_v4|s:32:\"036c6fabc23f3c5d7ea70e69d95c640a\";'),
('ospos_session:d0d1cf3840c1df8b3a9493e9068ef966','127.0.0.1','2026-09-02 09:56:21','__ci_last_regenerate|i:1788342981;csrf_ospos_v4|s:32:\"46e4ce9387f3e453fe6752d04d60f977\";'),
('ospos_session:d1d9dedd07faf0919be14cbb9e1e76dd','127.0.0.1','2026-09-02 10:11:10','__ci_last_regenerate|i:1788343870;csrf_ospos_v4|s:32:\"c9be920791ca68f2680d98654a7f49b6\";'),
('ospos_session:d470dab21b83cda140b25382aa121bd4','172.22.0.3','2026-09-02 10:33:08','__ci_last_regenerate|i:1788345188;csrf_ospos_v4|s:32:\"24518e737e344220a2ddfb740e3f9364\";'),
('ospos_session:d47c320e8ea0c012811171f95ff06d77','127.0.0.1','2026-09-02 09:42:45','__ci_last_regenerate|i:1788342165;csrf_ospos_v4|s:32:\"867651fbedc5e5f4cf33a69c5ae58002\";'),
('ospos_session:d49079733b3866bad3387c739ef3e119','127.0.0.1','2026-09-02 10:44:48','__ci_last_regenerate|i:1788345888;csrf_ospos_v4|s:32:\"dece91bf8b976039fc4b1bb2aaf686a3\";'),
('ospos_session:d5006eac02f330a4466c9ba6fb7dfa44','127.0.0.1','2026-09-02 09:55:51','__ci_last_regenerate|i:1788342951;csrf_ospos_v4|s:32:\"66ae33f70077edffafc1285b5c183a59\";'),
('ospos_session:d50a1170fa6ef74e64c5e3c9c64b0010','127.0.0.1','2026-09-02 10:15:51','__ci_last_regenerate|i:1788344151;csrf_ospos_v4|s:32:\"c4a4ee0340954f3bf293d9bf3c252525\";'),
('ospos_session:d68685841432ef845de170474562551f','172.22.0.3','2026-09-02 10:36:01','__ci_last_regenerate|i:1788345356;csrf_ospos_v4|s:32:\"42e2150129e0a0597790207f38534fc0\";_ci_previous_url|s:33:\"https://ghazi-pos.local/customers\";person_id|s:1:\"1\";'),
('ospos_session:d8bfcc694a29304eed31868bdcd4e733','127.0.0.1','2026-09-02 10:16:51','__ci_last_regenerate|i:1788344211;csrf_ospos_v4|s:32:\"0516d30658a5009cd20c2851c80460f5\";'),
('ospos_session:d8ca56bdd46208057aad0bbe2e6875a3','127.0.0.1','2026-09-02 09:41:44','__ci_last_regenerate|i:1788342104;csrf_ospos_v4|s:32:\"54d8dd26d65a539ad99b64491afbcd07\";'),
('ospos_session:d9eec37c268b90cb49c38ffbeb83def3','172.22.0.3','2026-09-02 10:21:56','__ci_last_regenerate|i:1788344516;csrf_ospos_v4|s:32:\"f8f3ba921503ec79ada9c2489a3f2e9c\";'),
('ospos_session:da3285ceb5960db0c23a8a6630a5c914','127.0.0.1','2026-09-02 10:41:47','__ci_last_regenerate|i:1788345707;csrf_ospos_v4|s:32:\"9fd5372a7b3dab9f6375abb7993d30ff\";'),
('ospos_session:da44787574ffdda9dd6343ddaf0cd4b6','127.0.0.1','2026-09-02 10:12:10','__ci_last_regenerate|i:1788343930;csrf_ospos_v4|s:32:\"2da722fd3869c5776643baed296620de\";'),
('ospos_session:da9e7677536922edff8a7e51d5f6c1f4','127.0.0.1','2026-09-02 09:56:51','__ci_last_regenerate|i:1788343011;csrf_ospos_v4|s:32:\"0af0a5cfa82d64a0974bb8ab581a0413\";'),
('ospos_session:dc833523f1bf2c0d44e08da49df78157','127.0.0.1','2026-09-02 09:59:51','__ci_last_regenerate|i:1788343191;csrf_ospos_v4|s:32:\"34975a1495f230f5138a0191b3fab37c\";'),
('ospos_session:dccdf0920a29493faef27842bf12222d','127.0.0.1','2026-09-02 10:33:33','__ci_last_regenerate|i:1788345213;csrf_ospos_v4|s:32:\"59b2e2b6c140197909d910896fd62bd8\";'),
('ospos_session:dfc4e54038277433a70513305c242671','127.0.0.1','2026-09-02 10:01:21','__ci_last_regenerate|i:1788343281;csrf_ospos_v4|s:32:\"77b9ecc39498124f81dbb6f60ff54ee7\";'),
('ospos_session:e050b5243a36556784c9cbce5f2339d7','127.0.0.1','2026-09-02 10:18:21','__ci_last_regenerate|i:1788344301;csrf_ospos_v4|s:32:\"5264138e1dfca36bdcfaad5a89f355b3\";'),
('ospos_session:e3357179df939a4e1e7eb15aee97be07','127.0.0.1','2026-09-02 09:53:20','__ci_last_regenerate|i:1788342800;csrf_ospos_v4|s:32:\"0651cbe94f703fdd1ae4c1890d6c7e7f\";'),
('ospos_session:e5285cac09ddf7b72aef5a2b400f1ed1','172.22.0.3','2026-09-02 10:14:15','__ci_last_regenerate|i:1788344055;csrf_ospos_v4|s:32:\"e3211e4c5a77fe4ae148c3da43fb3c96\";'),
('ospos_session:e6501ffcab6b223370f5c5da4b6364ee','127.0.0.1','2026-09-02 09:39:14','__ci_last_regenerate|i:1788341954;csrf_ospos_v4|s:32:\"71ed45ed3f3018dfe96cb4dc5460cd9b\";'),
('ospos_session:e7dc7f6525f023ff01c02c9e0053fca6','127.0.0.1','2026-09-02 10:42:17','__ci_last_regenerate|i:1788345737;csrf_ospos_v4|s:32:\"2cd6845a96ea98c6f101146519a51ef0\";'),
('ospos_session:ebcf44a1d3dae8a6cb9648b28c125105','127.0.0.1','2026-09-02 10:28:26','__ci_last_regenerate|i:1788344906;csrf_ospos_v4|s:32:\"05d1d5434fa495dca288f6b709914ab2\";'),
('ospos_session:edc40d1f021a5d2ef503384f1ccb1fb1','127.0.0.1','2026-09-02 10:12:40','__ci_last_regenerate|i:1788343960;csrf_ospos_v4|s:32:\"9d03156b427ab74b0f1d7f8d64cf7818\";'),
('ospos_session:ee2c596a3a7d179f2960cc670c2ca6db','127.0.0.1','2026-09-02 10:14:21','__ci_last_regenerate|i:1788344061;csrf_ospos_v4|s:32:\"2625b2bf54214fdc7222bf79ab3ef368\";'),
('ospos_session:efba54d8047752e8f124c29c2ab59213','127.0.0.1','2026-09-02 09:47:15','__ci_last_regenerate|i:1788342435;csrf_ospos_v4|s:32:\"4e6fd066dbf205490a59580ec35ad388\";'),
('ospos_session:f1d10f70caa0b5dbd9041ec377998d85','127.0.0.1','2026-09-02 10:47:18','__ci_last_regenerate|i:1788346038;csrf_ospos_v4|s:32:\"9d8f5f67c5a7df8040fbc3da747b620d\";'),
('ospos_session:f2647a35a64c7fb95fa5337eaa91bc9e','127.0.0.1','2026-09-02 10:45:18','__ci_last_regenerate|i:1788345918;csrf_ospos_v4|s:32:\"32d4ce45f830e22f76868ef296f96e66\";'),
('ospos_session:f30f59167b21a00ec04a368d589b57b6','127.0.0.1','2026-09-02 10:40:47','__ci_last_regenerate|i:1788345647;csrf_ospos_v4|s:32:\"aaf2ea84d5df650720d5acb8c973bf1a\";'),
('ospos_session:f3fe39286e8a593fb41b79b5068316e5','127.0.0.1','2026-09-02 10:25:27','__ci_last_regenerate|i:1788344727;csrf_ospos_v4|s:32:\"793f8e0f1ff818cff99af2617db2e171\";'),
('ospos_session:f572e666fae0536fd2bc929ed1256bc3','127.0.0.1','2026-09-02 09:37:14','__ci_last_regenerate|i:1788341834;csrf_ospos_v4|s:32:\"ec9eb0ea1870e9a008fda0a90adf8adc\";'),
('ospos_session:f69052a8105232ac4083d4d9dbee30fe','127.0.0.1','2026-09-02 09:44:45','__ci_last_regenerate|i:1788342285;csrf_ospos_v4|s:32:\"036ac1cc55016ce37834c79d8b44a102\";'),
('ospos_session:f773fb17c9fe6b48b86b63f46f93e0b4','127.0.0.1','2026-09-02 09:55:21','__ci_last_regenerate|i:1788342921;csrf_ospos_v4|s:32:\"c1f770227f2a182de04db75c54871615\";'),
('ospos_session:fb9cb5c5b98521a345c8e4bdacd17064','127.0.0.1','2026-09-02 09:41:14','__ci_last_regenerate|i:1788342074;csrf_ospos_v4|s:32:\"c9f549d7ad0b433f96af6f39d460d3bf\";'),
('ospos_session:fcb4d988e29685ae0738ebe5181a0c87','127.0.0.1','2026-09-02 09:40:14','__ci_last_regenerate|i:1788342014;csrf_ospos_v4|s:32:\"a2c81b5315328e533a98f0fd09d66368\";'),
('ospos_session:fcfa12f99746307d6f1250787893b586','127.0.0.1','2026-09-02 09:36:14','__ci_last_regenerate|i:1788341774;csrf_ospos_v4|s:32:\"dd3ab2a20972bed560207c77c8c08d54\";'),
('ospos_session:fe6ac6064034fc60b8377c7f6dfcc5f7','127.0.0.1','2026-09-02 10:30:56','__ci_last_regenerate|i:1788345056;csrf_ospos_v4|s:32:\"107158744d49267e14e344f4177248d9\";'),
('ospos_session:fef869789201bcda91073aaefe7d0a73','127.0.0.1','2026-09-02 10:45:48','__ci_last_regenerate|i:1788345948;csrf_ospos_v4|s:32:\"93915a50adff05113ca89b8a24f89c26\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'Warehouse',0),
(2,'Shop',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(2,'FFC','FFC',NULL,'',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03  5:00:27
