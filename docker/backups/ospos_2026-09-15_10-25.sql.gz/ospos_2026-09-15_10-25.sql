/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','id'),
('barcode_first_row','name'),
('barcode_font','0'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','0'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C128'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','0'),
('category_dropdown','0'),
('clcdesq_api_key',''),
('clcdesq_api_url',''),
('company','CortexFlow Point of Sale'),
('company_logo',''),
('country_codes','us'),
('currency_code',''),
('currency_decimals','2'),
('currency_symbol','$'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format',''),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category','Standard'),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','0'),
('dinner_table_enable','0'),
('email','changeme@example.com'),
('email_receipt_check_behaviour','never'),
('enforce_privacy','0'),
('fax',''),
('financial_year','1'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','jpg,gif,png'),
('image_max_height','480'),
('image_max_size','128'),
('image_max_width','640'),
('include_hsn','0'),
('invoice_default_comments','This is a default comment'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','0'),
('last_used_quote_number','0'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form','floating_labels'),
('mailchimp_api_key',''),
('mailchimp_list_id',''),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('phone','555-555-5555'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','never'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','12'),
('receipt_show_company_name','1'),
('receipt_show_description','0'),
('receipt_show_serialnumber','1'),
('receipt_show_taxes','1'),
('receipt_show_tax_ind','1'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_default'),
('receiving_calculate_average_price','0'),
('recv_invoice_format','{CO}'),
('return_policy','Test'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id',''),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','America/New_York'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Expiry Date','DATE',NULL,7,NULL,0),
(2,'New','DROPDOWN',NULL,7,NULL,0),
(3,'Is Shelf Life','CHECKBOX',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,1,NULL,NULL,'1-1'),
(2,2,NULL,NULL,NULL,NULL),
(3,2,NULL,NULL,NULL,NULL),
(2,2,1,NULL,NULL,'2-1'),
(4,3,1,NULL,NULL,'3-1'),
(5,1,2,NULL,NULL,'1-2'),
(1,1,1,4,NULL,NULL),
(2,2,1,4,NULL,NULL),
(4,3,1,4,NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,NULL,'2026-09-20',NULL),
(2,'A',NULL,NULL),
(3,'B',NULL,NULL),
(4,'1',NULL,NULL),
(5,NULL,'2026-09-24',NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-09-13 13:13:33','2026-09-13 13:13:33',0.00,0.00,0,0.00,0.00,0.00,0.00,'',2,2,0,0.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(3,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-13 13:17:23',1,1),
(4,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-13 13:22:53',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('admin','$2y$10$vJBSMlD02EC7ENSrKfVQXuvq9tNRHMtcOA8MSK2NYS748HHWm.gcG',1,0,2,NULL,NULL),
('admin1','$2y$10$57DDuHE6hTzSpfV8ftRU5OfpVbnsiGOAj38dfXg58mwpfpzYOYhoe',2,0,2,'','');
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('cashups',2,'office'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_stock',1,'home'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_stock',1,'home'),
('reports',1,'home'),
('reports_categories',1,'home'),
('reports_customers',1,'home'),
('reports_discounts',1,'home'),
('reports_employees',1,'home'),
('reports_expenses_categories',1,'home'),
('reports_inventory',1,'home'),
('reports_items',1,'home'),
('reports_payments',1,'home'),
('reports_receivings',1,'home'),
('reports_sales',1,'home'),
('reports_sales_taxes',1,'home'),
('reports_suppliers',1,'home'),
('reports_taxes',1,'home'),
('sales',1,'home'),
('sales',2,'both'),
('sales_change_price',1,'--'),
('sales_change_price',2,'--'),
('sales_delete',1,'--'),
('sales_delete',2,'--'),
('sales_stock',1,'home'),
('sales_stock',2,'--'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-09-13 12:47:09','Manual Edit of Quantity',1,0.000),
(2,1,2,'2026-09-13 13:12:28','POS 1',1,-90.000),
(3,1,1,'2026-09-13 13:15:55','Manual Edit of Quantity',1,20090.000),
(4,1,1,'2026-09-13 13:20:53','POS 2',1,-11.000),
(5,1,1,'2026-09-13 13:23:09','POS 3',1,-1.000),
(6,2,1,'2026-09-13 13:53:16','Manual Edit of Quantity',1,0.000),
(7,1,1,'2026-09-14 07:38:50','POS 4',1,-2.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,19986.000),
(2,1,0.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Coca Cola 1.5L','Beverage',NULL,'Coca Cola 1.5L','',190.00,200.00,10.000,20000.000,1,NULL,0,0,0,0,0,NULL,1.000,'Each',1,''),
('Coca Cola 1L','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,2,NULL,0,0,0,0,0,NULL,1.000,'Each',2,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1789267453,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1789267453,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1789267453,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1789267453,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1789267453,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1789267453,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1789267453,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1789267454,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1789267454,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1789267454,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1789267454,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1789267454,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1789267454,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1789267454,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1789267454,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1789267454,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1789267454,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1789267454,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1789267454,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1789267454,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1789267454,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1789267454,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1789267454,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1789267454,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1789267454,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1789267454,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1789267454,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1789267454,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1789267454,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1789267454,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1789267454,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1789267454,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1789267454,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1789267454,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1789267454,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1789267454,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1789267454,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1789267454,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1789267454,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1789267454,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1789267454,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1789267454,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1789267454,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1789267454,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1789267454,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('John','Doe',NULL,'555-555-5555','changeme@example.com','Address 1','','','','','','',1),
('Admin','Admin',1,'','admin@gmail.com','','','','','','','',2),
('Zahidul','Islam',1,'+9230158043754','changeme@example.com','Street # 4, Makkah Town, Khudian, Kasur','','Kasur','','','Pakistan','',3),
('Alex','Alex',NULL,'','','','','','','','','',4),
('Umair','Umair',1,'','','','','','','','','',5),
('Usman','Usman',NULL,'','','','','','','','','',6);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_stock','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_stock','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_stock','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-09-13 13:12:28',NULL,2,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-09-13 13:20:53',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-09-13 13:23:09',4,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-14 07:38:50',NULL,1,'',NULL,NULL,4,NULL,0,NULL,0);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,90.000,0.00,0.00,0.00,0,1,0),
(2,1,'','',1,11.000,0.00,0.00,0.00,0,1,0),
(3,1,'','',1,1.000,190.00,200.00,0.00,0,1,0),
(4,1,'','',1,2.000,190.00,200.00,0.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,3,'Due',200.00,0.00,0,1,'2026-09-13 17:23:09',''),
(2,4,'Cash',400.00,0.00,0,1,'2026-09-14 11:38:50','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:01579142a32f8edc0220816a00e5b44a','127.0.0.1','2026-09-14 12:03:34','__ci_last_regenerate|i:1789387414;csrf_ospos_v4|s:32:\"2b1bd6c6fc600f9f91dad4a56d775e19\";'),
('ospos_session:043cc4544dc1a8879647d9564c84405a','127.0.0.1','2026-09-14 11:43:01','__ci_last_regenerate|i:1789386181;csrf_ospos_v4|s:32:\"583d50c8d44feb94e3e05403e16e90a6\";'),
('ospos_session:045cf56aa3ca0097d6f9f890975bd136','127.0.0.1','2026-09-14 05:16:56','__ci_last_regenerate|i:1789363016;csrf_ospos_v4|s:32:\"00fc3d8c38e65d880d0dc88227fd108f\";'),
('ospos_session:0462d9f23c1414c6a5c298c10a0e72a2','127.0.0.1','2026-09-14 11:46:02','__ci_last_regenerate|i:1789386362;csrf_ospos_v4|s:32:\"9ea6576a989c5e60d937b01b39bd24e1\";'),
('ospos_session:06243461ed861d9c00a2c1b43a69060c','127.0.0.1','2026-09-14 11:58:04','__ci_last_regenerate|i:1789387084;csrf_ospos_v4|s:32:\"9ae190b13fb54f83998e8700337cc077\";'),
('ospos_session:0686bd07cf38e6fa7345bbdcbe86a9f7','127.0.0.1','2026-09-14 05:27:28','__ci_last_regenerate|i:1789363648;csrf_ospos_v4|s:32:\"38ef4219cea0011a09ad6698d6a64d46\";'),
('ospos_session:083de4c1b8372534882f70fcaec5c8bb','127.0.0.1','2026-09-14 05:28:28','__ci_last_regenerate|i:1789363708;csrf_ospos_v4|s:32:\"9f0072a237eb2806f7debc45cf7429aa\";'),
('ospos_session:09af15aea3d9b4836d4ca4d44839ae18','127.0.0.1','2026-09-14 04:47:22','__ci_last_regenerate|i:1789361242;csrf_ospos_v4|s:32:\"65ff6448e004aa4c8b972d2e089d4c92\";'),
('ospos_session:09d6f95272f6af106c20e51f32bedc92','127.0.0.1','2026-09-14 05:08:25','__ci_last_regenerate|i:1789362505;csrf_ospos_v4|s:32:\"9b3c78219dc52aad2bee56ebcf396f9e\";'),
('ospos_session:0a4c6f97c7d0220ff769388410e41b55','127.0.0.1','2026-09-14 11:42:01','__ci_last_regenerate|i:1789386121;csrf_ospos_v4|s:32:\"c09ba9cd4c7255c5670e83030167a4eb\";'),
('ospos_session:0aa57fcc00cddc8b35f0ad320ad97dbb','127.0.0.1','2026-09-14 05:33:28','__ci_last_regenerate|i:1789364008;csrf_ospos_v4|s:32:\"ba19de90d1507e83b6408ffa5fc5d147\";'),
('ospos_session:0b5a55c4597767becb60f666d847578b','127.0.0.1','2026-09-14 04:52:53','__ci_last_regenerate|i:1789361573;csrf_ospos_v4|s:32:\"cf92e98ffed39cc8037826727cbde70a\";'),
('ospos_session:0e3693b6f9502545bd5ef48c49366c09','127.0.0.1','2026-09-14 11:55:33','__ci_last_regenerate|i:1789386933;csrf_ospos_v4|s:32:\"59236dd3b13d83fdab009a53391f9831\";'),
('ospos_session:0fc5e9be4ea62a68aa4d01014eb88a5c','127.0.0.1','2026-09-14 05:22:57','__ci_last_regenerate|i:1789363377;csrf_ospos_v4|s:32:\"0bde96c411b865bb1694e32f28387c31\";'),
('ospos_session:1004c07ffe2279b1df5e5500486a1dd5','127.0.0.1','2026-09-15 10:23:22','__ci_last_regenerate|i:1789467802;csrf_ospos_v4|s:32:\"9b3a1791d1483f4c02ad89facddd955d\";'),
('ospos_session:108732d67d4681a449f183ed04af27ca','127.0.0.1','2026-09-14 05:44:00','__ci_last_regenerate|i:1789364640;csrf_ospos_v4|s:32:\"ae0e447da65b8a74614c1c144f7384f4\";'),
('ospos_session:1387b1b3da42293ba6319bff31df20f7','127.0.0.1','2026-09-14 12:48:48','__ci_last_regenerate|i:1789390128;csrf_ospos_v4|s:32:\"63d54c55fd5116ba9b255c58eae7550e\";'),
('ospos_session:13d0c9dbca837c06856710ca2873bb5e','127.0.0.1','2026-09-14 05:20:26','__ci_last_regenerate|i:1789363226;csrf_ospos_v4|s:32:\"16eba0ddf3826ccaa0ec49137c5d7766\";'),
('ospos_session:148cab5cdd4a8517ad250857af9063bf','127.0.0.1','2026-09-14 11:53:03','__ci_last_regenerate|i:1789386783;csrf_ospos_v4|s:32:\"0186815e7f6c3bc87725c56a63e9de26\";'),
('ospos_session:173f4209902bd5a3d9911ecd7c7dc0d4','127.0.0.1','2026-09-14 04:53:23','__ci_last_regenerate|i:1789361603;csrf_ospos_v4|s:32:\"f8c4938acf65e7990f4890cd3a2724b2\";'),
('ospos_session:17ea1f475b37d2257b5b32b67e3ef183','127.0.0.1','2026-09-14 05:34:59','__ci_last_regenerate|i:1789364099;csrf_ospos_v4|s:32:\"d28725be8500f3aae85f4e0f2ece97e3\";'),
('ospos_session:1891119cfb6efaac25536f6408e1750a','127.0.0.1','2026-09-14 13:57:44','__ci_last_regenerate|i:1789394264;csrf_ospos_v4|s:32:\"33ea3b3022898aba49649467b13d7342\";'),
('ospos_session:1b18fbb33ce106746ebd0c7015282c00','127.0.0.1','2026-09-14 05:23:57','__ci_last_regenerate|i:1789363437;csrf_ospos_v4|s:32:\"f40fa8af18517107f506d40851787fcc\";'),
('ospos_session:1c636512bbd2fb208b370f2d134fead3','127.0.0.1','2026-09-15 10:20:51','__ci_last_regenerate|i:1789467651;csrf_ospos_v4|s:32:\"c0d68a4932c40103155d64872bdbe45f\";'),
('ospos_session:1c9957e182710ac085be8dc2cc9346cb','127.0.0.1','2026-09-14 12:02:04','__ci_last_regenerate|i:1789387324;csrf_ospos_v4|s:32:\"e78516ff709002deb0f13dc5a869f4a2\";'),
('ospos_session:1cf7a5b40246baeae1b1d34a27396d4c','127.0.0.1','2026-09-14 12:46:17','__ci_last_regenerate|i:1789389977;csrf_ospos_v4|s:32:\"23f1c828e608290d78f2926bf3226bf2\";'),
('ospos_session:1e005d6df262be0b3e19a239d36beeeb','127.0.0.1','2026-09-14 05:25:27','__ci_last_regenerate|i:1789363527;csrf_ospos_v4|s:32:\"3657852cf738eaa87834eb2e8e91bdfd\";'),
('ospos_session:1ebd09de42567ca826e0a184d690aba6','127.0.0.1','2026-09-14 13:57:14','__ci_last_regenerate|i:1789394234;csrf_ospos_v4|s:32:\"74e1dc98d51934a2aa9a0bdc6e8a7eeb\";'),
('ospos_session:1fdcec8c5cbcabcfc7e0f32c38c914a0','127.0.0.1','2026-09-14 05:21:27','__ci_last_regenerate|i:1789363287;csrf_ospos_v4|s:32:\"6563f009ad16f78592a7d52472f8631e\";'),
('ospos_session:201924efa76929f74b260f08ea9af665','127.0.0.1','2026-09-14 05:13:56','__ci_last_regenerate|i:1789362836;csrf_ospos_v4|s:32:\"c8324631a9f2be4ae7231c286d398e13\";'),
('ospos_session:202766bf58d0b57e322e44c3c253fd4d','127.0.0.1','2026-09-14 12:04:05','__ci_last_regenerate|i:1789387445;csrf_ospos_v4|s:32:\"6c6cf5200b476de536be57334ea019b3\";'),
('ospos_session:2145888809ed6cdeba22b9d5732c9b6a','127.0.0.1','2026-09-14 12:02:34','__ci_last_regenerate|i:1789387354;csrf_ospos_v4|s:32:\"2075f764325cf3ce8d9ac8013a21ec00\";'),
('ospos_session:21abc4d2f8599e299e9aecf3a9895edc','127.0.0.1','2026-09-14 04:50:53','__ci_last_regenerate|i:1789361453;csrf_ospos_v4|s:32:\"e469285a5c969ae228da423e886613e3\";'),
('ospos_session:2305db2a30670784c86eae98caad0eca','127.0.0.1','2026-09-14 05:12:56','__ci_last_regenerate|i:1789362776;csrf_ospos_v4|s:32:\"f5f63f16c981511e779acadef247183c\";'),
('ospos_session:25deb87e552631922a960e977d6c3f31','127.0.0.1','2026-09-14 05:06:25','__ci_last_regenerate|i:1789362385;csrf_ospos_v4|s:32:\"e353d6f928594f721912960b47129d50\";'),
('ospos_session:26bb5cf31ff8da7edc1e852038ca589e','127.0.0.1','2026-09-14 14:00:14','__ci_last_regenerate|i:1789394414;csrf_ospos_v4|s:32:\"fe2bf50fd4f1a04b63f0b8bde3adbb68\";'),
('ospos_session:26e959eac325a77ad63d220f09639126','127.0.0.1','2026-09-14 11:58:34','__ci_last_regenerate|i:1789387114;csrf_ospos_v4|s:32:\"ba001d1af0bb57e295748cd88bcd14a6\";'),
('ospos_session:28b80b5c2e24d493c691b1699a37e6a8','127.0.0.1','2026-09-14 04:48:53','__ci_last_regenerate|i:1789361333;csrf_ospos_v4|s:32:\"8faf693bd66d2b47d264b0a332526cdd\";'),
('ospos_session:29bcfe26559184a2d0b7e5f6cf0c9e90','127.0.0.1','2026-09-14 11:44:01','__ci_last_regenerate|i:1789386241;csrf_ospos_v4|s:32:\"13afc35e918725e25d882e34a9baf8c9\";'),
('ospos_session:2b7d2d7528982bc51d06a05c3dd4ca37','127.0.0.1','2026-09-14 13:58:14','__ci_last_regenerate|i:1789394294;csrf_ospos_v4|s:32:\"68b3eb3f48f03fa08b0bb39c1c6ab235\";'),
('ospos_session:2d738a9b2bdd3ed21d4f87322a2c9c63','127.0.0.1','2026-09-14 05:10:55','__ci_last_regenerate|i:1789362655;csrf_ospos_v4|s:32:\"ad8e95d0240055077025f4d092adbd0f\";'),
('ospos_session:2d807424448ea8b99ded3592e608fb52','127.0.0.1','2026-09-14 04:43:52','__ci_last_regenerate|i:1789361032;csrf_ospos_v4|s:32:\"fd605c28e6a9e6923f1378855ac94d6f\";'),
('ospos_session:2f734fef502af73a2997c57eec600981','127.0.0.1','2026-09-14 11:55:03','__ci_last_regenerate|i:1789386903;csrf_ospos_v4|s:32:\"c3081a91850de96f1cb15f6fc62ffdb3\";'),
('ospos_session:30a6de0867b58039427694b07eacf411','127.0.0.1','2026-09-14 04:41:52','__ci_last_regenerate|i:1789360912;csrf_ospos_v4|s:32:\"b3df4858759328615f392b7660236117\";'),
('ospos_session:320c8a6380e5a6e6b6857bb203305e31','127.0.0.1','2026-09-14 05:10:25','__ci_last_regenerate|i:1789362625;csrf_ospos_v4|s:32:\"6ff7b43624e5fc7607f2f49389e36ef4\";'),
('ospos_session:34341be962bee59f57ae3da2006d417b','127.0.0.1','2026-09-15 10:23:52','__ci_last_regenerate|i:1789467832;csrf_ospos_v4|s:32:\"d0fb81a294967c5bd437f6ab73fe63fd\";'),
('ospos_session:349357a08f5e68152853919c393d7168','127.0.0.1','2026-09-14 05:06:55','__ci_last_regenerate|i:1789362415;csrf_ospos_v4|s:32:\"10e243e2f01d8c94f2c53c4d506fe5a2\";'),
('ospos_session:353e7d54e6c2ee802e05e73134520e0e','127.0.0.1','2026-09-14 05:32:28','__ci_last_regenerate|i:1789363948;csrf_ospos_v4|s:32:\"8aef1ee681b439829370c9d5bfc4d70c\";'),
('ospos_session:363c14d966f52aead646c6c8e4a74ea9','127.0.0.1','2026-09-14 11:45:02','__ci_last_regenerate|i:1789386302;csrf_ospos_v4|s:32:\"6a02b744ca3727223bca17c6afde510c\";'),
('ospos_session:36689bff08005e3af837c2b3511ab579','127.0.0.1','2026-09-14 11:42:31','__ci_last_regenerate|i:1789386151;csrf_ospos_v4|s:32:\"ffeb7aafe9e62cf6430b19b39a904c6e\";'),
('ospos_session:367041e407f3c8603f7c0994701e7d3c','127.0.0.1','2026-09-14 11:44:32','__ci_last_regenerate|i:1789386272;csrf_ospos_v4|s:32:\"b6f8afc771b3ffc9bfade74793f785fe\";'),
('ospos_session:36d18fd74340670d85480d42934fbce7','127.0.0.1','2026-09-14 05:31:28','__ci_last_regenerate|i:1789363888;csrf_ospos_v4|s:32:\"4f6171b15e6a6de22b25f3398a7d6ead\";'),
('ospos_session:385ff97cdfd09a92a231efc2ef65ffe3','127.0.0.1','2026-09-14 13:59:14','__ci_last_regenerate|i:1789394354;csrf_ospos_v4|s:32:\"2b48b5024fc8e40289fd6f621bc98896\";'),
('ospos_session:3acf9d4e2d86a6e06f2b5fe83c892c77','127.0.0.1','2026-09-14 05:22:27','__ci_last_regenerate|i:1789363347;csrf_ospos_v4|s:32:\"5a951633b0237020d3f38407c6a3f228\";'),
('ospos_session:3b4ae18d4e20ee81196ab6a17633ea8f','127.0.0.1','2026-09-14 05:34:29','__ci_last_regenerate|i:1789364069;csrf_ospos_v4|s:32:\"070e248c7979e2fad3fc4c3310c9875f\";'),
('ospos_session:3bb55f4f4f35c9aedd9e50b4b6f35088','127.0.0.1','2026-09-14 12:01:34','__ci_last_regenerate|i:1789387294;csrf_ospos_v4|s:32:\"1b396bc3e09eabe4bbc6ac50db9c6c41\";'),
('ospos_session:40046deb4c084e21be3739587ed171e7','127.0.0.1','2026-09-14 05:37:29','__ci_last_regenerate|i:1789364249;csrf_ospos_v4|s:32:\"70787b83dcf2e27cf703a0baa175bec0\";'),
('ospos_session:412da89352734d2425a4ea166624b68a','127.0.0.1','2026-09-14 04:47:52','__ci_last_regenerate|i:1789361272;csrf_ospos_v4|s:32:\"9d541bab9e2bda72b756c3ea3e394483\";'),
('ospos_session:4324286ad308149b0a3b70f740f6728c','127.0.0.1','2026-09-14 04:43:22','__ci_last_regenerate|i:1789361002;csrf_ospos_v4|s:32:\"7aec488430f33a988daa27ed1da58a86\";'),
('ospos_session:435d017287009d97723ec88258caab9a','127.0.0.1','2026-09-15 10:21:21','__ci_last_regenerate|i:1789467681;csrf_ospos_v4|s:32:\"afd296a874029da74e75a11659ee2957\";'),
('ospos_session:436a19fd46eec7f558b5057c945a18b9','127.0.0.1','2026-09-14 11:51:03','__ci_last_regenerate|i:1789386663;csrf_ospos_v4|s:32:\"144d8091c08df05c6b7678577f95ff05\";'),
('ospos_session:43e58550d455ded1fa543c3fa546f9d3','127.0.0.1','2026-09-14 05:24:57','__ci_last_regenerate|i:1789363497;csrf_ospos_v4|s:32:\"b2762299319e1853612e4551b6f3326f\";'),
('ospos_session:4532123806bec9fb9b9618fa5f795a0a','127.0.0.1','2026-09-14 05:32:58','__ci_last_regenerate|i:1789363978;csrf_ospos_v4|s:32:\"6e39c7e23df69225e5e99d58a2c434b8\";'),
('ospos_session:48dd059e20ddf4ea860e0b327572a587','127.0.0.1','2026-09-14 12:49:18','__ci_last_regenerate|i:1789390158;csrf_ospos_v4|s:32:\"6a95055253aea6cdbb0928e60cbd1f46\";'),
('ospos_session:4b4e86cf57d725976befc3aa8860e0c0','127.0.0.1','2026-09-14 11:49:32','__ci_last_regenerate|i:1789386572;csrf_ospos_v4|s:32:\"b1cf1d2d5389a0fc7438c7417a973823\";'),
('ospos_session:4c613075709fba810ada36ccab27e830','127.0.0.1','2026-09-14 12:53:18','__ci_last_regenerate|i:1789390398;csrf_ospos_v4|s:32:\"a40e3a77273c865d3a34ee925fee146e\";'),
('ospos_session:4dd07df4581044e6bec963aa737173fc','127.0.0.1','2026-09-15 10:21:51','__ci_last_regenerate|i:1789467711;csrf_ospos_v4|s:32:\"8b3d6900708122a511c323abcd1250da\";'),
('ospos_session:4ea31a0062edb12b0cfaedd48f290061','127.0.0.1','2026-09-14 05:07:25','__ci_last_regenerate|i:1789362445;csrf_ospos_v4|s:32:\"091824a39fb7c929a0b069899ab0ab5d\";'),
('ospos_session:51ae9272b28fde03220260a013c1be46','127.0.0.1','2026-09-14 11:50:33','__ci_last_regenerate|i:1789386633;csrf_ospos_v4|s:32:\"ac0fe604150be7991819fe0ec9f41d41\";'),
('ospos_session:53cfbd6bec91dd722fb9ed3276cb6cb6','127.0.0.1','2026-09-14 12:53:48','__ci_last_regenerate|i:1789390428;csrf_ospos_v4|s:32:\"163b56afc50098deef1828f25dff22eb\";'),
('ospos_session:53e8559a13716ff444da4a8feb696b44','127.0.0.1','2026-09-14 05:44:30','__ci_last_regenerate|i:1789364670;csrf_ospos_v4|s:32:\"8c12bf8fd52407896051b75a16c83bf4\";'),
('ospos_session:5455f4e44e6464336d01a16c6f93a0a5','127.0.0.1','2026-09-14 05:29:58','__ci_last_regenerate|i:1789363798;csrf_ospos_v4|s:32:\"5d0b77ac4b7f91907a1c74c9980be225\";'),
('ospos_session:54b4505a59de6a062bca4f7b579d4737','127.0.0.1','2026-09-14 05:40:59','__ci_last_regenerate|i:1789364459;csrf_ospos_v4|s:32:\"155af7c872d9ff2dc8850d44aa282628\";'),
('ospos_session:54c037e0cadb0a0e17fd92fb1a622271','127.0.0.1','2026-09-15 10:16:21','__ci_last_regenerate|i:1789467381;csrf_ospos_v4|s:32:\"1a2cae5a7786c110763b9510762958db\";'),
('ospos_session:579fd0d1ab7d27daf53fb812fded0e0d','127.0.0.1','2026-09-14 12:52:48','__ci_last_regenerate|i:1789390368;csrf_ospos_v4|s:32:\"7e9d3281adf3dee15472b27eefd32a57\";'),
('ospos_session:58a0dfcd727f54e6a1866c1935dbd89c','127.0.0.1','2026-09-14 11:51:33','__ci_last_regenerate|i:1789386693;csrf_ospos_v4|s:32:\"ab0afefaa1997855b330f8bc39f0f703\";'),
('ospos_session:5a042967623dfc9dfd3e360a86a137f3','127.0.0.1','2026-09-14 11:41:01','__ci_last_regenerate|i:1789386061;csrf_ospos_v4|s:32:\"be1d75990603046ad63feeaf295b2aa5\";'),
('ospos_session:5b08ce4f81a2e481b22586a2cde0ac08','127.0.0.1','2026-09-14 12:52:18','__ci_last_regenerate|i:1789390338;csrf_ospos_v4|s:32:\"35c804ff40cce59cfb5d0c99c5315f68\";'),
('ospos_session:5b0eda1082578a425592c281806f963e','127.0.0.1','2026-09-14 05:20:57','__ci_last_regenerate|i:1789363257;csrf_ospos_v4|s:32:\"94a44c12ccb41e78fb694a21a604252d\";'),
('ospos_session:5d4e6ce94ed54adeb22992806975cafa','172.20.0.2','2026-09-14 05:09:33','__ci_last_regenerate|i:1789362573;csrf_ospos_v4|s:32:\"d386e2a2b5f5bcba7113361ff39dbd19\";_ci_previous_url|s:29:\"https://ghazi-pos.local/login\";'),
('ospos_session:5f8e81194ed6390b06cdd782617ec375','127.0.0.1','2026-09-14 11:53:33','__ci_last_regenerate|i:1789386813;csrf_ospos_v4|s:32:\"a2ee5d85f55d75976f99176b9b5c8bc6\";'),
('ospos_session:5fe3b58bb9da183b29903aaacdd76e98','127.0.0.1','2026-09-14 11:47:32','__ci_last_regenerate|i:1789386452;csrf_ospos_v4|s:32:\"a324b4886234d8ede676124987a5ccb1\";'),
('ospos_session:60f5cb3bdec6e2efc31ccfd7a92347a0','127.0.0.1','2026-09-14 12:48:18','__ci_last_regenerate|i:1789390098;csrf_ospos_v4|s:32:\"1da202bbda3daaa1653e560744438510\";'),
('ospos_session:60fb6398e8ae1ab4d23d53d4af64daa5','127.0.0.1','2026-09-15 10:20:21','__ci_last_regenerate|i:1789467621;csrf_ospos_v4|s:32:\"ad9d6e7554f82bce595952d1f4986804\";'),
('ospos_session:61e4df364e9200e008ca97f754d72bdf','127.0.0.1','2026-09-14 05:15:56','__ci_last_regenerate|i:1789362956;csrf_ospos_v4|s:32:\"dfe9c658781b299613bac23997aff81c\";'),
('ospos_session:6392ab70fdacf6ad715b4e8130f24e02','127.0.0.1','2026-09-14 13:59:44','__ci_last_regenerate|i:1789394384;csrf_ospos_v4|s:32:\"9bc5d369c7b244065da4e7f9465baf27\";'),
('ospos_session:650814633a707c8fd8804ff889d72e03','127.0.0.1','2026-09-14 11:56:33','__ci_last_regenerate|i:1789386993;csrf_ospos_v4|s:32:\"ef46dbed6f8400386286ee3ae358dfec\";'),
('ospos_session:653c2e1bcd48118b87b42e6a7ebc1fe4','127.0.0.1','2026-09-14 11:46:32','__ci_last_regenerate|i:1789386392;csrf_ospos_v4|s:32:\"47b9d63a7ed5892c500b6992a89d2be0\";'),
('ospos_session:65d263bf066cf999482bc0c11c46ed0e','127.0.0.1','2026-09-14 05:17:26','__ci_last_regenerate|i:1789363046;csrf_ospos_v4|s:32:\"76eafe6219260a3e6e578dc9ba24772e\";'),
('ospos_session:6612711a41ae96dd14a685d93c3490b6','127.0.0.1','2026-09-14 12:05:35','__ci_last_regenerate|i:1789387535;csrf_ospos_v4|s:32:\"97454934a310d7acc6dc62aac20136af\";'),
('ospos_session:66729eb7300540e2ef2105757a85d578','127.0.0.1','2026-09-14 05:24:27','__ci_last_regenerate|i:1789363467;csrf_ospos_v4|s:32:\"5a70bd4e0cfcdc0246042d58b4f2bb5f\";'),
('ospos_session:6766725edfaf6831112e59188580504a','127.0.0.1','2026-09-15 10:17:51','__ci_last_regenerate|i:1789467471;csrf_ospos_v4|s:32:\"979c141ac833233963b75e2ba335121a\";'),
('ospos_session:6913b662d5372d728ac6469c507a7e5c','127.0.0.1','2026-09-14 04:44:22','__ci_last_regenerate|i:1789361062;csrf_ospos_v4|s:32:\"ee13cfbc206f57c703dec0acbe292105\";'),
('ospos_session:696f4d8c6f46e42fe39d56e8787b3597','127.0.0.1','2026-09-14 05:15:26','__ci_last_regenerate|i:1789362926;csrf_ospos_v4|s:32:\"b16f22f5c1570d1e1b295ab77eabe710\";'),
('ospos_session:698b0264ec74fde0bd5805bb5008503c','127.0.0.1','2026-09-14 11:41:31','__ci_last_regenerate|i:1789386091;csrf_ospos_v4|s:32:\"00536f09786c55a305952871633eb95e\";'),
('ospos_session:6aef10b6d459dfda3ceb05d5886469a6','127.0.0.1','2026-09-14 11:39:01','__ci_last_regenerate|i:1789385941;csrf_ospos_v4|s:32:\"eea932eb26479607571b613877fd98ec\";'),
('ospos_session:6f37eddb120750d8592993a4477c6bd4','127.0.0.1','2026-09-14 05:26:27','__ci_last_regenerate|i:1789363587;csrf_ospos_v4|s:32:\"324cc343c5e68d05bbd2733c917ef426\";'),
('ospos_session:6febaf0d02658881007a16ae250995cd','127.0.0.1','2026-09-14 04:52:23','__ci_last_regenerate|i:1789361543;csrf_ospos_v4|s:32:\"8358e9404eaa7f9ddfbfb2c7974f46c4\";'),
('ospos_session:71d29eb262a1eec1e13322d2595c71ca','127.0.0.1','2026-09-14 04:46:22','__ci_last_regenerate|i:1789361182;csrf_ospos_v4|s:32:\"f6fcfdb6e1bfccbb90530ea10a064d9f\";'),
('ospos_session:71e224a40a82a71712d064475ee8507a','127.0.0.1','2026-09-14 12:06:35','__ci_last_regenerate|i:1789387595;csrf_ospos_v4|s:32:\"6ac8a35c83516bef20afe97155ec1b23\";'),
('ospos_session:725ca98126fecda39ab7ecd967c2fea1','127.0.0.1','2026-09-15 10:24:52','__ci_last_regenerate|i:1789467892;csrf_ospos_v4|s:32:\"97dfd70665d20bad18e52ef9c94bf513\";'),
('ospos_session:7862c2af8d16b8f98a4b2e358ee90ca9','127.0.0.1','2026-09-14 04:51:53','__ci_last_regenerate|i:1789361513;csrf_ospos_v4|s:32:\"b421f68f488e5805d6a1deb7164ec90d\";'),
('ospos_session:7963d010c5a3a72c8c80d69836e51c00','127.0.0.1','2026-09-14 04:45:22','__ci_last_regenerate|i:1789361122;csrf_ospos_v4|s:32:\"8812a2d77b536819bcdeb68d9d59350f\";'),
('ospos_session:79d824e8e68e887c61af9c3081fa2127','127.0.0.1','2026-09-14 12:04:35','__ci_last_regenerate|i:1789387475;csrf_ospos_v4|s:32:\"755f52fd0512f8e4ab3acafaf38c54f4\";'),
('ospos_session:7b0a601b4cbea20b75939609a4f4d234','127.0.0.1','2026-09-15 10:18:51','__ci_last_regenerate|i:1789467531;csrf_ospos_v4|s:32:\"c4d5ffc2e2d177cbb2eff0d2dd2ee59b\";'),
('ospos_session:7b15fb4cf66f75fa6788547224af7905','127.0.0.1','2026-09-14 05:38:29','__ci_last_regenerate|i:1789364309;csrf_ospos_v4|s:32:\"8c02f0d6e699650bf7407108d34fc5fe\";'),
('ospos_session:7b323e10d2defcdf3ab32fef41a89d8d','127.0.0.1','2026-09-14 05:27:58','__ci_last_regenerate|i:1789363678;csrf_ospos_v4|s:32:\"5caa726b1c75459e520de1ad99248aed\";'),
('ospos_session:7c07c0d2bbc17a1284ae881a6e68bc8a','127.0.0.1','2026-09-14 05:25:57','__ci_last_regenerate|i:1789363557;csrf_ospos_v4|s:32:\"59170e729b44b09fc7e29e29d1071858\";'),
('ospos_session:7c8b87a111f8eabeae861dc6dc39f2b9','127.0.0.1','2026-09-14 05:01:54','__ci_last_regenerate|i:1789362114;csrf_ospos_v4|s:32:\"35985be0d7e7edcc9e9ff3fc65e1fe28\";'),
('ospos_session:7f39f3399d339172e3b45efcf9f2edb7','127.0.0.1','2026-09-14 05:04:55','__ci_last_regenerate|i:1789362295;csrf_ospos_v4|s:32:\"07d903d029956af0f4fe031435ab1f03\";'),
('ospos_session:80a8bc733481159bac1af1ef34eb45f5','127.0.0.1','2026-09-14 05:16:26','__ci_last_regenerate|i:1789362986;csrf_ospos_v4|s:32:\"82a365a1083b5ea5d8a98ee94643ac99\";'),
('ospos_session:80db3fdec5dc3ec208b6f6b590cf791c','127.0.0.1','2026-09-14 04:49:53','__ci_last_regenerate|i:1789361393;csrf_ospos_v4|s:32:\"2cd41528b019072007343a5cb55e4cec\";'),
('ospos_session:811919308ad456327df1d56fce6856ec','127.0.0.1','2026-09-14 12:00:04','__ci_last_regenerate|i:1789387204;csrf_ospos_v4|s:32:\"52239571d9c5db8020e8a1330f3462b0\";'),
('ospos_session:81fa2bc948612de6735e67b8df5d436b','127.0.0.1','2026-09-14 05:13:26','__ci_last_regenerate|i:1789362806;csrf_ospos_v4|s:32:\"07220c7b903b2f69cdaeccf4f58ea68d\";'),
('ospos_session:82ff3cf8bc754e65e9efa5a1422621b9','127.0.0.1','2026-09-15 10:22:22','__ci_last_regenerate|i:1789467742;csrf_ospos_v4|s:32:\"43fb8141e82b1581b86eb2a154584a21\";'),
('ospos_session:83be0bf43f6df2c3bb55ab8d0f823de9','127.0.0.1','2026-09-14 05:11:25','__ci_last_regenerate|i:1789362685;csrf_ospos_v4|s:32:\"47f59a0a8e32da9bb54d79f47b081bb0\";'),
('ospos_session:84209c3a7816aa552ca189f2e82b3fa3','127.0.0.1','2026-09-14 05:23:27','__ci_last_regenerate|i:1789363407;csrf_ospos_v4|s:32:\"1cf2ec0ef512e8eaad108d7e9824a9f9\";'),
('ospos_session:847bc94b15810cf37f7f3d323510f59f','127.0.0.1','2026-09-14 05:38:59','__ci_last_regenerate|i:1789364339;csrf_ospos_v4|s:32:\"05bfbad5c0c5fd93a154e640babe4bbc\";'),
('ospos_session:850a16c65d4e6dfb845785bca7e2e9f4','127.0.0.1','2026-09-14 05:39:59','__ci_last_regenerate|i:1789364399;csrf_ospos_v4|s:32:\"9c83bbdc5f189d2679a4895486ec6a67\";'),
('ospos_session:856a7971edbf03f9faac1dfa479c30b4','127.0.0.1','2026-09-14 05:30:58','__ci_last_regenerate|i:1789363858;csrf_ospos_v4|s:32:\"77d2ec0546f21bf3c4f7d51f61e2bc5f\";'),
('ospos_session:88682a6111968ad33d57535d14917265','127.0.0.1','2026-09-14 11:57:34','__ci_last_regenerate|i:1789387054;csrf_ospos_v4|s:32:\"f441b520481b74d6ade661e30db1012c\";'),
('ospos_session:894056d02008bb21fc47d7533334ddb5','127.0.0.1','2026-09-14 11:56:03','__ci_last_regenerate|i:1789386963;csrf_ospos_v4|s:32:\"f24f0ffd96f508ab3a2b5fddf4271948\";'),
('ospos_session:89514b3404317f01f55cf524d27b577e','127.0.0.1','2026-09-14 04:58:54','__ci_last_regenerate|i:1789361934;csrf_ospos_v4|s:32:\"fdd51464061b3ec139233e0bf2714268\";'),
('ospos_session:8ac99aea7f0fdabc4d54f72d437ae1e6','127.0.0.1','2026-09-14 05:18:56','__ci_last_regenerate|i:1789363136;csrf_ospos_v4|s:32:\"10257276e7d9b69d6c0e61692952b222\";'),
('ospos_session:8becbacb6588760471c2b52764190fb5','127.0.0.1','2026-09-14 11:54:03','__ci_last_regenerate|i:1789386843;csrf_ospos_v4|s:32:\"52650656c01a9583b6cd7a59ad148387\";'),
('ospos_session:8e38c6259ee94e8207100cf5da635147','127.0.0.1','2026-09-14 12:06:05','__ci_last_regenerate|i:1789387565;csrf_ospos_v4|s:32:\"db21b541e957d26d54878a0d3cea3a01\";'),
('ospos_session:91e432f8e123e481128e11b0d2875d05','127.0.0.1','2026-09-14 12:01:04','__ci_last_regenerate|i:1789387264;csrf_ospos_v4|s:32:\"194d51bdbef691d735dac86e5557cceb\";'),
('ospos_session:92a3ce3d82973ce4bffdc011f07cc3d4','127.0.0.1','2026-09-14 05:39:29','__ci_last_regenerate|i:1789364369;csrf_ospos_v4|s:32:\"99b6039bb64e3ebf4b329b2d09362804\";'),
('ospos_session:93c259cd41ca8bf323df2a8e71098d50','127.0.0.1','2026-09-14 05:02:54','__ci_last_regenerate|i:1789362174;csrf_ospos_v4|s:32:\"e0b167c7c0aa3bc6a2902fe39d8f0368\";'),
('ospos_session:952d64385cce9467fce4fe0e69b574f4','127.0.0.1','2026-09-14 05:01:24','__ci_last_regenerate|i:1789362084;csrf_ospos_v4|s:32:\"f9d3d28c2fa2464fbcdaf962451c7ae0\";'),
('ospos_session:9588c25eb42b9d119866b4f5ef40c007','127.0.0.1','2026-09-15 10:17:21','__ci_last_regenerate|i:1789467441;csrf_ospos_v4|s:32:\"ad1ec23602a07a6ba840c12af4f14126\";'),
('ospos_session:96e1574e6c0b0889935d0c4d479fad8d','127.0.0.1','2026-09-14 04:53:53','__ci_last_regenerate|i:1789361633;csrf_ospos_v4|s:32:\"4a07295389d3f4e2b1b160aee460c710\";'),
('ospos_session:96f5bfbae4068d2d16da617580ec143a','127.0.0.1','2026-09-14 04:42:52','__ci_last_regenerate|i:1789360972;csrf_ospos_v4|s:32:\"187d30501b004c1037c36e24aff5aaf6\";'),
('ospos_session:99f2e3d71f83b0ba3bf14ee65a629dd2','127.0.0.1','2026-09-14 04:59:24','__ci_last_regenerate|i:1789361964;csrf_ospos_v4|s:32:\"efb315def419e96fd65e991f7c2b379e\";'),
('ospos_session:9ad379a996a5b1b905f38392ed35c670','127.0.0.1','2026-09-14 04:57:24','__ci_last_regenerate|i:1789361844;csrf_ospos_v4|s:32:\"bcdc774b6a4a043c5d0cef9d1ba0203c\";'),
('ospos_session:9b1b16d85922937d14d4e50af530bf39','127.0.0.1','2026-09-14 04:54:23','__ci_last_regenerate|i:1789361663;csrf_ospos_v4|s:32:\"b81354f75f085fae70280d2203a1738c\";'),
('ospos_session:9b6bdf269830c91a6bedc12826bda63f','127.0.0.1','2026-09-14 04:46:52','__ci_last_regenerate|i:1789361212;csrf_ospos_v4|s:32:\"1a62ba6341a893e99265cfd81caf2ef7\";'),
('ospos_session:9b9c36e9a56f2b5c607170574e6c1264','127.0.0.1','2026-09-14 05:41:30','__ci_last_regenerate|i:1789364490;csrf_ospos_v4|s:32:\"5aee877513811af83601e925faa28662\";'),
('ospos_session:9d6f60db5c98b743a41f43c7f89c3556','127.0.0.1','2026-09-14 05:17:56','__ci_last_regenerate|i:1789363076;csrf_ospos_v4|s:32:\"b69fcccd18bb64575e0a91b4f32ce5ff\";'),
('ospos_session:9f789aaa99032166c6fab2197e464789','127.0.0.1','2026-09-14 12:47:48','__ci_last_regenerate|i:1789390068;csrf_ospos_v4|s:32:\"0e56d3fa520506c82c3442e55d78182b\";'),
('ospos_session:9fa9fcd1a955820d1ca8d8616698bfff','127.0.0.1','2026-09-14 04:49:23','__ci_last_regenerate|i:1789361363;csrf_ospos_v4|s:32:\"94c7a7090408c34988dfadc6d2562e62\";'),
('ospos_session:a066428502a964949e4a5fce35b3cc36','127.0.0.1','2026-09-14 05:36:59','__ci_last_regenerate|i:1789364219;csrf_ospos_v4|s:32:\"93ad62726eb4ed2bc7448bb2714f0cb0\";'),
('ospos_session:a27e5da1f5fbe34f272c37bdc100542f','127.0.0.1','2026-09-14 05:43:00','__ci_last_regenerate|i:1789364580;csrf_ospos_v4|s:32:\"e6bf1476c6de303e12f65e26cb10bdbe\";'),
('ospos_session:a370a4b416a9312b4d2ef5fd394fc211','127.0.0.1','2026-09-15 10:19:21','__ci_last_regenerate|i:1789467561;csrf_ospos_v4|s:32:\"f6daa46ad0f293d8cab2d023b37d93be\";'),
('ospos_session:a5a210b8d991d0c08ccc6c9a78a12b78','127.0.0.1','2026-09-14 11:49:02','__ci_last_regenerate|i:1789386542;csrf_ospos_v4|s:32:\"af88173972e4290e0e56804e811408da\";'),
('ospos_session:a62160214a125e0bce2a1d6c2919ef89','127.0.0.1','2026-09-14 05:09:55','__ci_last_regenerate|i:1789362595;csrf_ospos_v4|s:32:\"0ba4f724b0af08d8763677f8a7531991\";'),
('ospos_session:a7499374a9645f56fa0a9e15374f6c05','127.0.0.1','2026-09-14 05:02:24','__ci_last_regenerate|i:1789362144;csrf_ospos_v4|s:32:\"58b376032fa180afe32ac79d5c4bd2cf\";'),
('ospos_session:a9d1bf46ba8823d6c6a8815a08300e15','127.0.0.1','2026-09-14 12:50:48','__ci_last_regenerate|i:1789390248;csrf_ospos_v4|s:32:\"c4dcbe0b99b520cd9ee6f8d1a25b3891\";'),
('ospos_session:ab4cb2112ac698c1d975ef5b9949fada','127.0.0.1','2026-09-14 04:44:52','__ci_last_regenerate|i:1789361092;csrf_ospos_v4|s:32:\"7924163570a28a3afadaa1d05e8edc26\";'),
('ospos_session:ab541fb4cefbef0e0d8f0ae7a3cbdb20','127.0.0.1','2026-09-14 11:52:03','__ci_last_regenerate|i:1789386723;csrf_ospos_v4|s:32:\"cf29e3b334e254cac63952ee4fc17963\";'),
('ospos_session:ab63dc1c5e5fa801c9af505d85fb80fb','127.0.0.1','2026-09-14 11:43:31','__ci_last_regenerate|i:1789386211;csrf_ospos_v4|s:32:\"ef733ce3ab135b866f07ec2c8bcc6af8\";'),
('ospos_session:acf761849b102076895180cd8096859a','127.0.0.1','2026-09-14 04:56:24','__ci_last_regenerate|i:1789361784;csrf_ospos_v4|s:32:\"1cdd5a83eaaaa268e800c6db56126f5a\";'),
('ospos_session:b274ec6b65877ca9fad959d41024dee7','127.0.0.1','2026-09-14 05:12:26','__ci_last_regenerate|i:1789362746;csrf_ospos_v4|s:32:\"d6b07af112df39bda5075c59936032b7\";'),
('ospos_session:b401bafc77fbc6dfa94366baa67e9d36','127.0.0.1','2026-09-14 04:50:23','__ci_last_regenerate|i:1789361423;csrf_ospos_v4|s:32:\"dde320787e3dc3b01d505b64f3fe70e7\";'),
('ospos_session:b469baeac0fd8924714a726267d4da15','127.0.0.1','2026-09-14 05:19:26','__ci_last_regenerate|i:1789363166;csrf_ospos_v4|s:32:\"80bc65b9240750a874930c3446087064\";'),
('ospos_session:b4cc59a624cebcfa85b79d7cbcd9d998','127.0.0.1','2026-09-14 11:48:32','__ci_last_regenerate|i:1789386512;csrf_ospos_v4|s:32:\"276c29fd3402a981bb97cb8e918e896b\";'),
('ospos_session:b5723ce99f34e45586e71d42abd47827','127.0.0.1','2026-09-14 05:08:55','__ci_last_regenerate|i:1789362535;csrf_ospos_v4|s:32:\"14f7424fe3cd1967e85921b06881a6b3\";'),
('ospos_session:b65f799b85de22a1f849794c6ef661b5','127.0.0.1','2026-09-14 11:40:01','__ci_last_regenerate|i:1789386001;csrf_ospos_v4|s:32:\"7bea8765281a40a7b7cd3efed373ffb1\";'),
('ospos_session:b6fee2c78792b0f88db4e0043bf20558','127.0.0.1','2026-09-14 05:03:24','__ci_last_regenerate|i:1789362204;csrf_ospos_v4|s:32:\"235ead68fbeb57d1f80e5a59a9876e5c\";'),
('ospos_session:b729710e223073971714061d11478544','127.0.0.1','2026-09-15 10:16:51','__ci_last_regenerate|i:1789467411;csrf_ospos_v4|s:32:\"7a7d76457466911e00c4807c28583b34\";'),
('ospos_session:ba71191ca791acd9cf8842c0dcdbf45d','127.0.0.1','2026-09-14 11:38:31','__ci_last_regenerate|i:1789385911;csrf_ospos_v4|s:32:\"93c5781ab91d0d5d8afd085fe2e8168d\";'),
('ospos_session:bad9b99f430758b263917525c3fa9c92','127.0.0.1','2026-09-14 05:36:29','__ci_last_regenerate|i:1789364189;csrf_ospos_v4|s:32:\"b8e20e273b6ea02dc877fa337474da37\";'),
('ospos_session:bc10a66bc31827945da627cc549e6911','127.0.0.1','2026-09-14 12:50:18','__ci_last_regenerate|i:1789390218;csrf_ospos_v4|s:32:\"3dfb5b4411d79abdd042284b7629e58e\";'),
('ospos_session:bcbe6fb520a1f32ac7db23cbf6850837','127.0.0.1','2026-09-14 05:40:29','__ci_last_regenerate|i:1789364429;csrf_ospos_v4|s:32:\"a1e87db45294374ce782475ecc5604e5\";'),
('ospos_session:bd48da3da3e86a8a0ef80898f793f391','127.0.0.1','2026-09-15 10:18:21','__ci_last_regenerate|i:1789467501;csrf_ospos_v4|s:32:\"ec31235d04157721150e08b0305120d8\";'),
('ospos_session:bed0d9f26035449a16a3af70ea74e9b2','127.0.0.1','2026-09-14 05:33:58','__ci_last_regenerate|i:1789364038;csrf_ospos_v4|s:32:\"699c4569449f751bc3df0c1bf5610561\";'),
('ospos_session:bf52b4de67faff0d0df2d66998ec42e9','127.0.0.1','2026-09-14 04:42:22','__ci_last_regenerate|i:1789360942;csrf_ospos_v4|s:32:\"3987d4db1124af7caa7884d18d77b09e\";'),
('ospos_session:bfe4f35fcd207605d37c331373240221','127.0.0.1','2026-09-14 05:42:30','__ci_last_regenerate|i:1789364550;csrf_ospos_v4|s:32:\"bcf3134d17de588cfa79b63b3a8658ab\";'),
('ospos_session:c151f39ba6a9c0417d2188d43e5e00e4','127.0.0.1','2026-09-14 05:00:54','__ci_last_regenerate|i:1789362054;csrf_ospos_v4|s:32:\"27585fd93ac1c01efac5e63087aa404d\";'),
('ospos_session:c15fa3fbe27205c35747193866f35447','127.0.0.1','2026-09-14 13:58:44','__ci_last_regenerate|i:1789394324;csrf_ospos_v4|s:32:\"636a22287ba6b4dafe923ef8b41108b2\";'),
('ospos_session:c23f6a40930620fba1e70472e456daf3','127.0.0.1','2026-09-14 05:37:59','__ci_last_regenerate|i:1789364279;csrf_ospos_v4|s:32:\"8f7f993c5cc671d335de320906e3d1e2\";'),
('ospos_session:c28d5628830b6e6581b7ed964db11230','127.0.0.1','2026-09-15 10:19:51','__ci_last_regenerate|i:1789467591;csrf_ospos_v4|s:32:\"2b36891ef0714251595d8ef830b106e3\";'),
('ospos_session:c356295868e2c5d870ba1b94b34988fa','127.0.0.1','2026-09-14 04:51:23','__ci_last_regenerate|i:1789361483;csrf_ospos_v4|s:32:\"9106939c1bc3d5960c3eea62b4f2e3e2\";'),
('ospos_session:c487c710ffc4fb7e39f6e5b3bcf8abe3','127.0.0.1','2026-09-14 11:38:01','__ci_last_regenerate|i:1789385881;csrf_ospos_v4|s:32:\"16145a7e0f31f0a9b3d91b77b233b622\";'),
('ospos_session:c4fd3960e2a0726d6d860132691390cc','127.0.0.1','2026-09-14 11:50:02','__ci_last_regenerate|i:1789386602;csrf_ospos_v4|s:32:\"de282146def0519e2bb543dd59976f75\";'),
('ospos_session:c5dcbb640123da9dd25f6fbf5388f1cb','127.0.0.1','2026-09-14 05:35:59','__ci_last_regenerate|i:1789364159;csrf_ospos_v4|s:32:\"7c55bb5794daf073ed114c31570a6bc5\";'),
('ospos_session:c62c3c2986a4c34df7bf877a07bed428','127.0.0.1','2026-09-14 04:45:52','__ci_last_regenerate|i:1789361152;csrf_ospos_v4|s:32:\"fd07ee9aeb7ec5d51ab4409b56a1fa27\";'),
('ospos_session:c9d038a2e14a7e7e61cc13b519967d2e','127.0.0.1','2026-09-14 05:07:55','__ci_last_regenerate|i:1789362475;csrf_ospos_v4|s:32:\"e736f10465baf48b3c65b838a476df93\";'),
('ospos_session:cb330adf717793a45cfdec052d86e8d7','127.0.0.1','2026-09-14 12:49:48','__ci_last_regenerate|i:1789390188;csrf_ospos_v4|s:32:\"709ac89c3117b423f89e1d2f59df7934\";'),
('ospos_session:cc86e569c942ee359397d87331f6f837','127.0.0.1','2026-09-14 05:26:57','__ci_last_regenerate|i:1789363617;csrf_ospos_v4|s:32:\"859a5eb3592b3661f85bac08ce772865\";'),
('ospos_session:cc95f23004ba847c1733b70c386fd154','127.0.0.1','2026-09-14 05:09:25','__ci_last_regenerate|i:1789362565;csrf_ospos_v4|s:32:\"9fbe9a63519c9d541f5553de02b19b26\";'),
('ospos_session:ce9d94027e86a6cbe93ecc753e728e17','127.0.0.1','2026-09-14 05:05:25','__ci_last_regenerate|i:1789362325;csrf_ospos_v4|s:32:\"c732ff00dd4b759d5c912b7ba8e5edf5\";'),
('ospos_session:cebb53c18b54765036a2d1a81815cba8','127.0.0.1','2026-09-14 04:57:54','__ci_last_regenerate|i:1789361874;csrf_ospos_v4|s:32:\"b503e17cc618e3a282d9739f486305a9\";'),
('ospos_session:ceda6cd8af4c85b0d9531e6e3c9b927f','127.0.0.1','2026-09-14 05:03:54','__ci_last_regenerate|i:1789362234;csrf_ospos_v4|s:32:\"585302333f38700dd864d6afb6c4b29f\";'),
('ospos_session:d35d742554f8bdbcc4c9ddb80d26b5f8','127.0.0.1','2026-09-14 05:18:26','__ci_last_regenerate|i:1789363106;csrf_ospos_v4|s:32:\"c071d0d509a4898b97e893388713f3a3\";'),
('ospos_session:d5737ff46b5c699445d42c8ba1f684c8','127.0.0.1','2026-09-14 05:35:29','__ci_last_regenerate|i:1789364129;csrf_ospos_v4|s:32:\"43a436756818b3db4aad494f64832514\";'),
('ospos_session:d7bf5e490f1cc2c92094abedaa4f53a4','127.0.0.1','2026-09-14 12:00:34','__ci_last_regenerate|i:1789387234;csrf_ospos_v4|s:32:\"eae334fda82860acd68c12ac72e6a673\";'),
('ospos_session:d97f26b74e46c59b9fea4af868ea887a','127.0.0.1','2026-09-14 12:46:47','__ci_last_regenerate|i:1789390007;csrf_ospos_v4|s:32:\"d4520db48ba69a5603dc8717672821ce\";'),
('ospos_session:dc76edfaad10426ef3fe3579de6f5dff','172.20.0.3','2026-09-14 14:01:25','__ci_last_regenerate|i:1789394234;csrf_ospos_v4|s:32:\"4e31f2e312e768f57a4a44244ec27343\";_ci_previous_url|s:29:\"https://ghazi-pos.local/items\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:0;item_location|s:1:\"1\";recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_supplier|i:-1;sale_id|i:-1;sales_location|i:1;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:0:{}sales_customer|i:-1;sales_mode|s:4:\"sale\";sales_payments|a:0:{}'),
('ospos_session:dcc599772c6fa04844fb9c5ca0ba166a','127.0.0.1','2026-09-14 14:01:14','__ci_last_regenerate|i:1789394474;csrf_ospos_v4|s:32:\"cd87434a6c14e5ff1a84cd19e881fa34\";'),
('ospos_session:de4747d3e4f8c902a11bc9a59c3c8a50','127.0.0.1','2026-09-14 12:47:18','__ci_last_regenerate|i:1789390038;csrf_ospos_v4|s:32:\"9c1dc9e2a0daf6ae800ffc098faaf396\";'),
('ospos_session:df2f2ec2efe369d1c8c4e87e7799faf5','127.0.0.1','2026-09-14 05:05:55','__ci_last_regenerate|i:1789362355;csrf_ospos_v4|s:32:\"5f75d2794112a00d3e490d4abb410e2b\";'),
('ospos_session:dfa573fedea41d8cda286c80fc97ad69','127.0.0.1','2026-09-14 05:00:24','__ci_last_regenerate|i:1789362024;csrf_ospos_v4|s:32:\"647dfd2967ce78529aaa851daa3778c2\";'),
('ospos_session:e0c05ba42d1a22e12559b53c27dfb68f','127.0.0.1','2026-09-14 05:14:26','__ci_last_regenerate|i:1789362866;csrf_ospos_v4|s:32:\"7ad1df6494ea424957a49b4a9bb64da2\";'),
('ospos_session:e19881ea14f5ea77e3b7b1943a3cb5fd','127.0.0.1','2026-09-14 05:30:28','__ci_last_regenerate|i:1789363828;csrf_ospos_v4|s:32:\"f15b38d4c6269d62d24c33e51ad02694\";'),
('ospos_session:e1ebda7e9419fdb5c616a76afe3b6fb8','127.0.0.1','2026-09-14 04:48:22','__ci_last_regenerate|i:1789361302;csrf_ospos_v4|s:32:\"d7e34e5d62a837332eeedcd3e8ac1ca5\";'),
('ospos_session:e3357dbf22f06fa14fa112bed370b874','127.0.0.1','2026-09-14 04:56:54','__ci_last_regenerate|i:1789361814;csrf_ospos_v4|s:32:\"7efb9ddb5320adff580e1769988187a6\";'),
('ospos_session:e41a8b80d6f76057872ba94c3d324646','127.0.0.1','2026-09-14 04:55:23','__ci_last_regenerate|i:1789361723;csrf_ospos_v4|s:32:\"f51b238453cd7a5e0dc27e423a9babd8\";'),
('ospos_session:e47922f6bcd7444580c0b394669e0e82','127.0.0.1','2026-09-14 12:51:48','__ci_last_regenerate|i:1789390308;csrf_ospos_v4|s:32:\"1324233834983a7a8ccbf2cc4d39f215\";'),
('ospos_session:e4b6540940807d19e6813a7d6b4bfa25','127.0.0.1','2026-09-14 11:59:34','__ci_last_regenerate|i:1789387174;csrf_ospos_v4|s:32:\"6fe5ad31570a959db42339632db2b0fc\";'),
('ospos_session:e5d178987c60a46e882ec239abade118','127.0.0.1','2026-09-15 10:24:22','__ci_last_regenerate|i:1789467862;csrf_ospos_v4|s:32:\"ee01ade7c115d4d0e6a391440691ad0f\";'),
('ospos_session:e6b4c7f16f9499981f06c2d50bd52eb4','127.0.0.1','2026-09-14 05:42:00','__ci_last_regenerate|i:1789364520;csrf_ospos_v4|s:32:\"71d06bf257410d4dc6cc02b47d2ffbb6\";'),
('ospos_session:e8869b04d16abd25a8baf0e521665c0c','127.0.0.1','2026-09-14 05:04:24','__ci_last_regenerate|i:1789362264;csrf_ospos_v4|s:32:\"9b2aa8839ddf7775f00f1ba3f383110a\";'),
('ospos_session:e95e45761a13960f3a172dc236f445b8','127.0.0.1','2026-09-14 11:59:04','__ci_last_regenerate|i:1789387144;csrf_ospos_v4|s:32:\"371463c63b11200a0ebd71c23f0c2145\";'),
('ospos_session:e97ad75f37108481f16dc3a2eef0f13c','127.0.0.1','2026-09-14 11:52:33','__ci_last_regenerate|i:1789386753;csrf_ospos_v4|s:32:\"4e92acc35c426845abaed7c039e8975b\";'),
('ospos_session:e995ed4a6e84f1782165ba99d05b1241','127.0.0.1','2026-09-14 05:19:56','__ci_last_regenerate|i:1789363196;csrf_ospos_v4|s:32:\"1aa458cd1a6d6e6e740d84999273ceb2\";'),
('ospos_session:ea831605836c531bfe519e732a3827af','127.0.0.1','2026-09-14 11:54:33','__ci_last_regenerate|i:1789386873;csrf_ospos_v4|s:32:\"572171e75fcf47a9bb74b9ee0ce2a88d\";'),
('ospos_session:eb284865a0ee6f3d201a0a515c13203b','127.0.0.1','2026-09-14 04:54:53','__ci_last_regenerate|i:1789361693;csrf_ospos_v4|s:32:\"a523b2dcbe24f473d69177a76fb532df\";'),
('ospos_session:ec53c3312ae777e3f9a2266f4edb6e45','127.0.0.1','2026-09-14 12:51:18','__ci_last_regenerate|i:1789390278;csrf_ospos_v4|s:32:\"d59e15e73214074cf62cda608924f19c\";'),
('ospos_session:ed1bf03d629af81f550aae95b07b6a99','127.0.0.1','2026-09-14 05:11:55','__ci_last_regenerate|i:1789362715;csrf_ospos_v4|s:32:\"66156563d123bd75c10fcf11774cbfa5\";'),
('ospos_session:ed34b12efe52a362279d0b4d1dcff3e3','127.0.0.1','2026-09-14 05:31:58','__ci_last_regenerate|i:1789363918;csrf_ospos_v4|s:32:\"f21ae371be82fa096267667249228efe\";'),
('ospos_session:ee0970405eeeb2208e4a6cd421642f85','127.0.0.1','2026-09-14 05:21:57','__ci_last_regenerate|i:1789363317;csrf_ospos_v4|s:32:\"c8e26bfdc603eaa065a3eb8b1c244b77\";'),
('ospos_session:ee3b5507df637e4ad5f6fe74a89b1d73','127.0.0.1','2026-09-14 11:39:31','__ci_last_regenerate|i:1789385971;csrf_ospos_v4|s:32:\"3960a1e25f569415c533a26549021146\";'),
('ospos_session:eed3ed2d861ac37f57df806103823efb','127.0.0.1','2026-09-14 05:14:56','__ci_last_regenerate|i:1789362896;csrf_ospos_v4|s:32:\"96c1eee462347005decce8318a0168dd\";'),
('ospos_session:f1ce4b96ed5926a3af41e32991ebd03c','127.0.0.1','2026-09-14 14:00:44','__ci_last_regenerate|i:1789394444;csrf_ospos_v4|s:32:\"0fc253a0932d3e73081f660988dfb746\";'),
('ospos_session:f1ec9be7be4237f73fdb3c5f47ea31f6','127.0.0.1','2026-09-14 11:45:32','__ci_last_regenerate|i:1789386332;csrf_ospos_v4|s:32:\"cfede864f843378eb3a1d7bf09c29223\";'),
('ospos_session:f23d831654daf51108d4e922d31f3410','127.0.0.1','2026-09-14 11:47:02','__ci_last_regenerate|i:1789386422;csrf_ospos_v4|s:32:\"2a20f38542e1ec7b100fc5b02009db7f\";'),
('ospos_session:f3f375fb2da96d5eaa84181c56f49f71','127.0.0.1','2026-09-15 10:22:52','__ci_last_regenerate|i:1789467772;csrf_ospos_v4|s:32:\"c0f6914fd3b3c2482373297a0e775fe5\";'),
('ospos_session:f54fc220ca02eb3f489063f72f4e21c2','127.0.0.1','2026-09-14 11:48:02','__ci_last_regenerate|i:1789386482;csrf_ospos_v4|s:32:\"61eed38ba55798393831fb6692eedea0\";'),
('ospos_session:f654ec10215af7aee942999ec240c5d5','127.0.0.1','2026-09-14 12:05:05','__ci_last_regenerate|i:1789387505;csrf_ospos_v4|s:32:\"d77caca63e11d87ae37ac141acecb6d8\";'),
('ospos_session:f7521dcf435735c87e40115b13a41e39','127.0.0.1','2026-09-14 04:59:54','__ci_last_regenerate|i:1789361994;csrf_ospos_v4|s:32:\"f9f9d659beb1cf02962a5662861a45bf\";'),
('ospos_session:f77a616e1a4dd0fd2d1c347582afbb7f','127.0.0.1','2026-09-14 04:55:54','__ci_last_regenerate|i:1789361754;csrf_ospos_v4|s:32:\"c29c8d882791f7520a49fbbe130d9d65\";'),
('ospos_session:fab9e695876fd2e96103e6df8597107a','127.0.0.1','2026-09-14 05:29:28','__ci_last_regenerate|i:1789363768;csrf_ospos_v4|s:32:\"901601b5e261a01c52ba2c088e14fd3d\";'),
('ospos_session:fb170fe7020e2b4aca7d6b3d4fa4a283','127.0.0.1','2026-09-14 11:57:03','__ci_last_regenerate|i:1789387023;csrf_ospos_v4|s:32:\"aa91878bfaca4eb65f708b570e083803\";'),
('ospos_session:fc1ca6a0f654797690076ac8ee04d7f4','127.0.0.1','2026-09-14 05:28:58','__ci_last_regenerate|i:1789363738;csrf_ospos_v4|s:32:\"c6e1d052bded01defc0d69378cb556c6\";'),
('ospos_session:fca636b2449e71ea403593cafbbabc03','127.0.0.1','2026-09-14 12:03:04','__ci_last_regenerate|i:1789387384;csrf_ospos_v4|s:32:\"cce6d1572f779fc8accca7703e0203d5\";'),
('ospos_session:fcadc0b9f589f5c0158ab00981834cbc','127.0.0.1','2026-09-14 04:58:24','__ci_last_regenerate|i:1789361904;csrf_ospos_v4|s:32:\"045e4d606a2119462cf1b18b46b4528c\";'),
('ospos_session:fd069303fdccf72cd11fa50a232275b9','127.0.0.1','2026-09-14 11:40:31','__ci_last_regenerate|i:1789386031;csrf_ospos_v4|s:32:\"78ddae0fb4f2f9a5c5d05de3d23e3c9a\";'),
('ospos_session:febe05eeb15d459a947dedab299c07a1','127.0.0.1','2026-09-14 05:43:30','__ci_last_regenerate|i:1789364610;csrf_ospos_v4|s:32:\"db8aa3841e03e51856a6e7a85f73941e\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'stock',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(5,'PakLight','',NULL,'',0,0),
(6,'KM','',NULL,'',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-15 10:25:07
