/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','number'),
('barcode_first_row','name'),
('barcode_font','fontawesome-webfont.ttf'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','1'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C128'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','0'),
('category_dropdown','0'),
('company','Ghazi Trader'),
('company_logo','pngegg.png'),
('country_codes','pk'),
('currency_code','PKR'),
('currency_decimals','2'),
('currency_symbol','Rs'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format',''),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category','Standard'),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','1'),
('dinner_table_enable','0'),
('email','usman@gmail.com'),
('email_receipt_check_behaviour','never'),
('enforce_privacy','0'),
('fax',''),
('financial_year','1'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','jpg,gif,png'),
('image_max_height','480'),
('image_max_size','128'),
('image_max_width','640'),
('include_hsn','0'),
('invoice_default_comments','This is a default comment'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','0'),
('last_used_quote_number','1'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form','floating_labels'),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('phone','+923015804375'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','never'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','10'),
('receipt_show_company_name','1'),
('receipt_show_description','0'),
('receipt_show_serialnumber','0'),
('receipt_show_taxes','0'),
('receipt_show_tax_ind','0'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_short'),
('receiving_calculate_average_price','0'),
('recv_invoice_format','{CO}'),
('return_policy','Items can be exchange only after 7 days in unworn codition'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id',''),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','Asia/Karachi'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Company','DROPDOWN',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,NULL,NULL,NULL,NULL),
(2,1,NULL,NULL,NULL,NULL),
(2,1,3,NULL,1,NULL),
(2,1,3,8,NULL,NULL),
(1,1,1,8,NULL,NULL),
(2,1,3,9,NULL,NULL),
(1,1,1,9,NULL,NULL),
(2,1,3,10,NULL,NULL),
(1,1,1,10,NULL,NULL),
(2,1,3,11,NULL,NULL),
(1,1,1,11,NULL,NULL),
(1,1,1,12,NULL,NULL),
(2,1,3,12,NULL,NULL),
(1,1,1,13,NULL,NULL),
(1,1,1,14,NULL,NULL),
(1,1,1,15,NULL,NULL),
(1,1,1,16,NULL,NULL),
(1,1,1,17,NULL,NULL),
(2,1,3,NULL,NULL,'1-3'),
(1,1,1,18,NULL,NULL),
(1,1,1,NULL,NULL,'1-1');
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,'FFC',NULL,NULL),
(2,'FFC2',NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-08-28 17:53:43','2026-08-28 17:53:43',12000.00,2000.00,1,10000.00,3000.00,0.00,0.00,'',1,1,0,1000.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(3,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-02 14:38:53',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('usman','$2y$10$7pp9sA73yJ0vDkH2JSBYL.VyOcJNgjdOT7AkAlzmdUtatts/EVbZa',1,0,2,'','');
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
INSERT INTO `ospos_expense_categories` VALUES
(1,'FFC','New Expens',0);
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
INSERT INTO `ospos_giftcards` VALUES
('2026-09-02 14:42:34',1,'455413123121312',50.00,0,3);
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_Shop',1,'--'),
('items_Warehouse',1,'--'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_Shop',1,'--'),
('receivings_Warehouse',1,'--'),
('reports',1,'home'),
('reports_categories',1,'--'),
('reports_customers',1,'--'),
('reports_discounts',1,'--'),
('reports_employees',1,'--'),
('reports_expenses_categories',1,'--'),
('reports_inventory',1,'--'),
('reports_items',1,'--'),
('reports_payments',1,'--'),
('reports_receivings',1,'--'),
('reports_sales',1,'--'),
('reports_sales_taxes',1,'--'),
('reports_suppliers',1,'--'),
('reports_taxes',1,'--'),
('sales',1,'home'),
('sales_change_price',1,'--'),
('sales_delete',1,'--'),
('sales_Shop',1,'--'),
('sales_Warehouse',1,'--'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',1,20.000),
(2,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',2,10.000),
(3,1,1,'2026-08-28 16:47:27','POS 1',1,-1.000),
(4,1,1,'2026-08-28 16:50:56','Manual Edit of Quantity',2,-10.000),
(5,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',1,80.000),
(6,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',2,0.000),
(7,1,1,'2026-08-28 16:54:53','POS 2',1,-1.000),
(8,1,1,'2026-08-28 16:57:10','POS 3',1,-1.000),
(9,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',1,100.000),
(10,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',2,0.000),
(11,3,1,'2026-08-28 17:57:35','RECV 1',1,6000.000),
(12,3,1,'2026-08-30 10:48:38','Manual Edit of Quantity',2,40.000),
(13,2,1,'2026-08-30 10:49:11','Manual Edit of Quantity',2,20.000),
(14,1,1,'2026-08-30 10:50:47','Manual Edit of Quantity',2,12.000),
(15,3,1,'2026-08-30 10:51:09','Manual Edit of Quantity',1,-5500.000),
(16,1,1,'2026-09-02 14:39:45','POS 4',2,-10.000),
(17,1,1,'2026-09-02 14:41:47','POS 5',1,5.000),
(18,1,1,'2026-09-02 14:44:04','POS 6',1,-5.000),
(19,2,1,'2026-09-02 15:42:27','POS 7',1,-1.000),
(20,1,1,'2026-09-03 10:29:18','',1,-10.000),
(21,1,1,'2026-09-03 10:29:28','Manual Edit of Quantity',1,-7.000),
(22,1,1,'2026-09-03 10:30:51','Manual Edit of Quantity',1,20.000),
(23,3,1,'2026-09-03 10:43:16','POS 8',1,-4.000),
(24,1,1,'2026-09-03 10:43:16','POS 8',1,-2.000),
(25,3,1,'2026-09-03 10:52:30','POS 9',1,-4.000),
(26,1,1,'2026-09-03 10:52:30','POS 9',1,-2.000),
(27,3,1,'2026-09-03 10:53:11','POS 10',1,-4.000),
(28,1,1,'2026-09-03 10:53:11','POS 10',1,-2.000),
(29,3,1,'2026-09-03 10:55:28','POS 11',1,-4.000),
(30,1,1,'2026-09-03 10:55:28','POS 11',1,-2.000),
(31,1,1,'2026-09-03 10:59:48','POS 12',1,-2.000),
(32,3,1,'2026-09-03 10:59:48','POS 12',1,-4.000),
(33,1,1,'2026-09-03 11:02:35','POS 13',1,-4.000),
(34,1,1,'2026-09-03 11:11:17','POS 14',2,-4.000),
(35,1,1,'2026-09-03 11:17:09','POS 15',1,-4.000),
(36,1,1,'2026-09-03 11:20:59','POS 16',1,-4.000),
(37,1,1,'2026-09-03 18:11:54','Manual Edit of Quantity',1,14.000),
(38,1,1,'2026-09-03 18:11:54','Manual Edit of Quantity',2,14.000),
(39,1,1,'2026-09-03 18:18:07','POS 17',1,-8.000),
(40,2,1,'2026-09-03 18:18:07','POS 17',1,-6.000),
(41,1,1,'2026-09-03 18:20:44','Manual Edit of Quantity',1,396.000),
(42,1,1,'2026-09-03 18:20:44','Manual Edit of Quantity',2,108.000),
(43,2,1,'2026-09-03 18:20:56','Manual Edit of Quantity',1,657.000),
(44,2,1,'2026-09-03 18:20:56','Manual Edit of Quantity',2,180.000),
(45,3,1,'2026-09-03 18:21:04','Manual Edit of Quantity',2,360.000),
(46,2,1,'2026-09-03 19:05:38','POS 18',1,-1.000),
(47,1,1,'2026-09-03 19:05:38','POS 18',1,-4.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
INSERT INTO `ospos_item_kit_items` VALUES
(3,1,8.000,0),
(3,2,1.000,0);
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
INSERT INTO `ospos_item_kits` VALUES
(3,'SKU-12312312','Ramzan Offer','Buy 1 1/4L Pet Get 1L Free',0,10.00,0,1,0);
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,396.000),
(1,2,120.000),
(2,1,729.000),
(2,2,200.000),
(3,1,580.000),
(3,2,400.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Cock Half Leter','Beverage',2,'123','',20.00,20.00,1.000,200.000,1,NULL,1,1,0,0,0,NULL,1.000,'Each',1,''),
('Cock Leter','Beverage',2,'1234','',80.00,96.00,1.000,4000.000,2,NULL,1,0,0,0,0,NULL,1.000,'Each',2,''),
('Sprite','Beverage',2,'12312-123123','',500.00,600.00,1.000,50.000,3,NULL,1,0,0,0,0,NULL,1.000,'Each',3,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1787915084,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1787915084,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1787915084,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1787915084,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1787915084,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1787915084,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1787915084,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1787915084,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1787915084,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1787915084,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1787915084,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1787915084,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1787915084,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1787915084,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1787915084,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1787915084,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1787915084,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1787915084,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1787915084,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1787915084,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1787915084,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1787915084,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1787915084,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1787915084,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1787915084,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1787915084,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1787915084,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1787915085,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1787915085,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1787915085,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1787915085,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1787915085,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1787915085,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1787915085,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1787915085,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1787915085,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1787915085,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1787915085,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1787915085,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1787915085,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1787915085,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1787915085,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1787915085,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1787915085,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1787915085,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('Usman','IlamDin',1,'+923014567595','usman65@gmail.com','Address 1','','','','','','',1),
('Alex','Alex',1,'','','','','','','','','',2),
('WalkIN','WalkIN',NULL,'','','','','','','','','',3);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_Shop','items',2),
('items_Warehouse','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_Shop','receivings',2),
('receivings_Warehouse','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_Shop','sales',2),
('sales_Warehouse','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
INSERT INTO `ospos_receivings` VALUES
('2026-08-28 17:57:35',2,1,'',1,'Cash','123123123');
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
INSERT INTO `ospos_receivings_items` VALUES
(1,3,'','',1,120.000,500.00,500.00,0.00,0,1,50.000);
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-08-28 16:47:27',NULL,1,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-08-28 16:54:53',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-08-28 16:57:10',NULL,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-02 14:39:45',3,1,'This is the final sale of the person\n\n','0',NULL,4,'Q26000001',0,NULL,1),
('2026-09-02 14:41:47',NULL,1,'',NULL,NULL,5,NULL,0,NULL,4),
('2026-09-02 14:44:04',3,1,'',NULL,NULL,6,NULL,0,NULL,0),
('2026-09-02 15:42:27',NULL,1,'',NULL,NULL,7,NULL,0,NULL,0),
('2026-09-03 10:43:16',NULL,1,'',NULL,NULL,8,NULL,0,NULL,0),
('2026-09-03 10:52:30',NULL,1,'',NULL,NULL,9,NULL,0,NULL,0),
('2026-09-03 10:53:11',NULL,1,'',NULL,NULL,10,NULL,0,NULL,0),
('2026-09-03 10:55:28',NULL,1,'',NULL,NULL,11,NULL,0,NULL,0),
('2026-09-03 10:59:48',NULL,1,'',NULL,NULL,12,NULL,0,NULL,0),
('2026-09-03 11:02:35',NULL,1,'',NULL,NULL,13,NULL,0,NULL,4),
('2026-09-03 11:11:17',NULL,1,'',NULL,NULL,14,NULL,0,NULL,0),
('2026-09-03 11:17:09',NULL,1,'',NULL,NULL,15,NULL,0,NULL,0),
('2026-09-03 11:20:59',NULL,1,'',NULL,NULL,16,NULL,0,NULL,0),
('2026-09-03 18:18:07',NULL,1,'',NULL,NULL,17,NULL,0,NULL,0),
('2026-09-03 19:05:38',NULL,1,'',NULL,NULL,18,NULL,0,NULL,0);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,1.000,0.00,0.00,0.00,0,1,0),
(2,1,'','',1,1.000,20.00,20.00,0.00,0,1,0),
(3,1,'','',2,1.000,20.00,20.00,0.00,0,1,0),
(4,1,'','',1,10.000,20.00,567.00,0.00,0,2,0),
(5,1,'','',1,-5.000,20.00,20.00,0.00,0,1,0),
(6,1,'','',1,5.000,20.00,10.00,0.00,0,1,0),
(7,2,'','',1,1.000,80.00,100.00,0.00,0,1,0),
(8,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(8,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(9,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(9,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(10,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(10,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(11,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(11,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(12,1,'','',1,2.000,20.00,20.00,10.00,0,1,0),
(12,3,'','',2,4.000,500.00,600.00,10.00,0,1,0),
(13,1,'','12321',1,4.000,20.00,20.00,10.00,0,1,0),
(14,1,'','',1,4.000,20.00,20.00,10.00,0,2,0),
(15,1,'This is the descriotion field','12321',1,4.000,20.00,20.00,0.00,0,1,0),
(16,1,'','',1,4.000,20.00,20.00,0.00,0,1,0),
(17,1,'','',1,8.000,20.00,20.00,0.00,0,1,0),
(17,2,'','',2,6.000,80.00,96.00,0.00,0,1,0),
(18,1,'','',2,4.000,20.00,20.00,10.00,0,1,0),
(18,2,'','',1,1.000,80.00,96.00,10.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,2,'Cash',20.00,0.00,0,1,'2026-08-28 11:54:53',''),
(2,3,'Cash',100.00,80.00,0,1,'2026-08-28 11:57:10',''),
(4,5,'Cash',-100.00,0.00,0,1,'2026-09-02 09:41:47',''),
(5,6,'Cash',50.00,0.00,0,1,'2026-09-02 09:44:04',''),
(6,7,'Cash',100.00,0.00,0,1,'2026-09-02 10:42:27',''),
(7,8,'Cash',2196.00,0.00,0,1,'2026-09-03 05:43:16',''),
(8,9,'Cash',2196.00,0.00,0,1,'2026-09-03 05:52:30',''),
(9,10,'Cash',2196.00,0.00,0,1,'2026-09-03 05:53:11',''),
(10,11,'Cash',2500.00,304.00,0,1,'2026-09-03 05:55:28',''),
(11,12,'Cash',2196.00,0.00,0,1,'2026-09-03 05:59:48',''),
(12,14,'Cash',72.00,0.00,0,1,'2026-09-03 06:11:17',''),
(13,15,'Cash',80.00,0.00,0,1,'2026-09-03 06:17:09',''),
(14,16,'Cash',80.00,0.00,0,1,'2026-09-03 06:20:59',''),
(15,17,'Cash',736.00,0.00,0,1,'2026-09-03 13:18:07',''),
(16,18,'Cash',158.40,0.00,0,1,'2026-09-03 14:05:38','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:0291faa804fa75807e72472825191e72','127.0.0.1','2026-09-04 06:18:06','__ci_last_regenerate|i:1788502686;csrf_ospos_v4|s:32:\"6941ada52275d6e481f8a5e4c533f8e6\";'),
('ospos_session:04dbcad20222b4850c7e1c4d0da432d7','127.0.0.1','2026-09-04 06:19:06','__ci_last_regenerate|i:1788502746;csrf_ospos_v4|s:32:\"2a2e4e0e465b323485e35b956a7c8f12\";'),
('ospos_session:0592ebd7fae0d2b1311e722470165d36','127.0.0.1','2026-09-04 05:49:32','__ci_last_regenerate|i:1788500972;csrf_ospos_v4|s:32:\"9996021967da7a001fddfd01f4e662fd\";'),
('ospos_session:0704a9b890090b3fbe552c8eb924f2c9','127.0.0.1','2026-09-04 06:22:36','__ci_last_regenerate|i:1788502956;csrf_ospos_v4|s:32:\"6c45e131ca4daed9984490f038d56859\";'),
('ospos_session:0dc606dad1f0cb5643cd411b4e84f606','127.0.0.1','2026-09-04 06:16:05','__ci_last_regenerate|i:1788502565;csrf_ospos_v4|s:32:\"b4fc9ab414865a1484f4a71d2c78e117\";'),
('ospos_session:0dd60c07beb7f90b459ec16c8f0397b7','127.0.0.1','2026-09-04 06:07:04','__ci_last_regenerate|i:1788502024;csrf_ospos_v4|s:32:\"fe1156db713b24e0ed09242f074d7a36\";'),
('ospos_session:0de09a9fca84aa67d571817e3f87856b','127.0.0.1','2026-09-04 06:23:36','__ci_last_regenerate|i:1788503016;csrf_ospos_v4|s:32:\"65c193e99108d30303f13d1d71cd0317\";'),
('ospos_session:1626e3aa5a4c969aa81a16cbdb83fd1f','127.0.0.1','2026-09-04 06:13:35','__ci_last_regenerate|i:1788502415;csrf_ospos_v4|s:32:\"93788e77ece4766e7bf568311c2cf34f\";'),
('ospos_session:16876ceb729e37401abacd0f25d7f7ce','127.0.0.1','2026-09-04 06:11:35','__ci_last_regenerate|i:1788502295;csrf_ospos_v4|s:32:\"47c689a28e2bfadf51926350f37ab42c\";'),
('ospos_session:16a0eb5c21e8fa7cfacdd24646b16d4e','127.0.0.1','2026-09-04 05:50:32','__ci_last_regenerate|i:1788501032;csrf_ospos_v4|s:32:\"59ccc163bff28b6b37e8083443e7fd13\";'),
('ospos_session:170b40b72b7a2bba7b2092abd1ada52d','127.0.0.1','2026-09-04 06:19:36','__ci_last_regenerate|i:1788502776;csrf_ospos_v4|s:32:\"3812fad82ccccabf2dab80337f4dbc69\";'),
('ospos_session:1cdcf81e1b728377d65e757bfb888965','127.0.0.1','2026-09-04 06:00:03','__ci_last_regenerate|i:1788501603;csrf_ospos_v4|s:32:\"2a5824456365499f94534bf8b4081d7b\";'),
('ospos_session:202daadb38b0b7be4f0181f37886b25a','127.0.0.1','2026-09-04 05:48:02','__ci_last_regenerate|i:1788500882;csrf_ospos_v4|s:32:\"9606339cce543c56839d4aa98e8298c3\";'),
('ospos_session:270165afa14b4df8456287a33ad13905','127.0.0.1','2026-09-04 06:17:05','__ci_last_regenerate|i:1788502625;csrf_ospos_v4|s:32:\"85da86902471c153633e9df5eae764e1\";'),
('ospos_session:2d7f0202e87bac68976dcfd83580ab92','127.0.0.1','2026-09-04 06:15:35','__ci_last_regenerate|i:1788502535;csrf_ospos_v4|s:32:\"d2de8adcd9a4d7ef763af6459ba5597b\";'),
('ospos_session:2f8bd409d265f731c7d3f5675ec5be01','127.0.0.1','2026-09-04 06:08:34','__ci_last_regenerate|i:1788502114;csrf_ospos_v4|s:32:\"fc49a5b3b3d0b1b2015c7903acac28f6\";'),
('ospos_session:3392ca6ca9ed2d2cfa9e695c40488f9d','127.0.0.1','2026-09-04 06:22:06','__ci_last_regenerate|i:1788502926;csrf_ospos_v4|s:32:\"0f5dc0ee313d1db48a43b682acd3a830\";'),
('ospos_session:373ab222b07acf368c12c17f9d7759d3','127.0.0.1','2026-09-04 05:56:03','__ci_last_regenerate|i:1788501363;csrf_ospos_v4|s:32:\"1b923750b1bf777eaaebb46b418afd34\";'),
('ospos_session:3bbebc59c8749b293c89d34d5d208dd4','127.0.0.1','2026-09-04 06:02:04','__ci_last_regenerate|i:1788501724;csrf_ospos_v4|s:32:\"b42056809f72f1db2076896acb281925\";'),
('ospos_session:4ad9327dc466c541616ffa4bfb6ade3b','172.22.0.2','2026-09-04 06:12:41','__ci_last_regenerate|i:1788502345;csrf_ospos_v4|s:32:\"14288867eb80935ba5d7ce94bcd8b5e5\";_ci_previous_url|s:28:\"https://ghazi-pos.local/home\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:1;item_location|s:1:\"1\";sale_id|i:-1;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:2:{i:1;a:25:{s:7:\"item_id\";s:1:\"1\";s:13:\"item_location\";i:1;s:10:\"stock_name\";s:9:\"Warehouse\";s:4:\"line\";i:1;s:4:\"name\";s:15:\"Cock Half Leter\";s:11:\"item_number\";s:3:\"123\";s:16:\"attribute_values\";s:3:\"FFC\";s:18:\"attribute_dtvalues\";N;s:11:\"description\";s:0:\"\";s:12:\"serialnumber\";s:0:\"\";s:21:\"allow_alt_description\";s:1:\"1\";s:13:\"is_serialized\";s:1:\"1\";s:8:\"quantity\";s:1:\"8\";s:8:\"discount\";s:4:\"0.00\";s:13:\"discount_type\";i:0;s:8:\"in_stock\";s:7:\"396.000\";s:5:\"price\";s:4:\"0.00\";s:10:\"cost_price\";s:5:\"20.00\";s:5:\"total\";s:6:\"0.0000\";s:16:\"discounted_total\";s:6:\"0.0000\";s:12:\"print_option\";i:0;s:10:\"stock_type\";s:1:\"0\";s:9:\"item_type\";s:1:\"0\";s:8:\"hsn_code\";s:0:\"\";s:15:\"tax_category_id\";N;}i:2;a:25:{s:7:\"item_id\";s:1:\"2\";s:13:\"item_location\";i:1;s:10:\"stock_name\";s:9:\"Warehouse\";s:4:\"line\";i:2;s:4:\"name\";s:10:\"Cock Leter\";s:11:\"item_number\";s:4:\"1234\";s:16:\"attribute_values\";N;s:18:\"attribute_dtvalues\";N;s:11:\"description\";s:0:\"\";s:12:\"serialnumber\";s:0:\"\";s:21:\"allow_alt_description\";s:1:\"1\";s:13:\"is_serialized\";s:1:\"0\";s:8:\"quantity\";s:1:\"1\";s:8:\"discount\";s:4:\"0.00\";s:13:\"discount_type\";i:0;s:8:\"in_stock\";s:7:\"729.000\";s:5:\"price\";s:4:\"0.00\";s:10:\"cost_price\";s:5:\"80.00\";s:5:\"total\";s:6:\"0.0000\";s:16:\"discounted_total\";s:6:\"0.0000\";s:12:\"print_option\";i:0;s:10:\"stock_type\";s:1:\"0\";s:9:\"item_type\";s:1:\"0\";s:8:\"hsn_code\";s:0:\"\";s:15:\"tax_category_id\";N;}}sales_customer|i:-1;sales_mode|s:4:\"sale\";sales_location|i:1;sales_payments|a:0:{}'),
('ospos_session:4b946868e971263ac621e8032e0606c6','127.0.0.1','2026-09-04 06:16:35','__ci_last_regenerate|i:1788502595;csrf_ospos_v4|s:32:\"22f8f04391ce0735df564ca597816fd5\";'),
('ospos_session:4f0102a9664cc21e84aee7a25407b3a0','127.0.0.1','2026-09-04 06:21:36','__ci_last_regenerate|i:1788502896;csrf_ospos_v4|s:32:\"ded7a6c4b052c2033a9895faac8eb5b4\";'),
('ospos_session:4fa344e8c4478177c24168c02b2f8597','127.0.0.1','2026-09-04 06:05:04','__ci_last_regenerate|i:1788501904;csrf_ospos_v4|s:32:\"32bd67d3e009e5b982ccfeec480dae0b\";'),
('ospos_session:5ce0c94bd5a0cbe2f8cbce45e57a9791','127.0.0.1','2026-09-04 06:24:37','__ci_last_regenerate|i:1788503077;csrf_ospos_v4|s:32:\"45e6e6522f02e3915a408d9cef35e195\";'),
('ospos_session:5d8ab2b77dc58650d163ed2cee345e79','127.0.0.1','2026-09-04 06:09:34','__ci_last_regenerate|i:1788502174;csrf_ospos_v4|s:32:\"dda589dfcfdfc0e616eb51ab454e7cf5\";'),
('ospos_session:5dbd9246921cb8d82110ac21ceeaea53','127.0.0.1','2026-09-04 06:12:05','__ci_last_regenerate|i:1788502325;csrf_ospos_v4|s:32:\"f2cb9f2ea64301b836506a11f80ece4d\";'),
('ospos_session:602cd03d5224d94f219e37915e5df624','127.0.0.1','2026-09-04 05:54:02','__ci_last_regenerate|i:1788501242;csrf_ospos_v4|s:32:\"f5c78cdb6b88649c61dc473b089ae4b6\";'),
('ospos_session:6167f13f776eca8af596cde4a183d7be','127.0.0.1','2026-09-04 06:11:05','__ci_last_regenerate|i:1788502265;csrf_ospos_v4|s:32:\"7fc016829de391c896344dbde22d522c\";'),
('ospos_session:63d305d19e1fc9e3ddee55f47bbbbd92','127.0.0.1','2026-09-04 05:47:31','__ci_last_regenerate|i:1788500851;csrf_ospos_v4|s:32:\"fb0a9e669a79debd7520c0d98e66fd2a\";'),
('ospos_session:65d6b2db8154011be35eaf7a031d912d','127.0.0.1','2026-09-04 05:47:01','__ci_last_regenerate|i:1788500821;csrf_ospos_v4|s:32:\"53b99dee4565da852d6dae19f0c4d525\";'),
('ospos_session:662ac0b93c757b60b7bf56332f7ada60','127.0.0.1','2026-09-04 06:12:35','__ci_last_regenerate|i:1788502355;csrf_ospos_v4|s:32:\"99a35dcb4110684ab110aafcc7c49b03\";'),
('ospos_session:687f7a162dc9292ee3de81e3a4317bd4','127.0.0.1','2026-09-04 06:13:05','__ci_last_regenerate|i:1788502385;csrf_ospos_v4|s:32:\"aea228cc80b9f353ddacd81fca720f86\";'),
('ospos_session:69e3274fa97ba73f808a56b574a3b916','127.0.0.1','2026-09-04 05:57:03','__ci_last_regenerate|i:1788501423;csrf_ospos_v4|s:32:\"c6612f87628c5ddac38bb81fb874f397\";'),
('ospos_session:6e2525917009124e04b1e6e0d07ce858','127.0.0.1','2026-09-04 06:17:36','__ci_last_regenerate|i:1788502656;csrf_ospos_v4|s:32:\"303ae54b355a0e09393c3508ac576a57\";'),
('ospos_session:6fdb5622322b1eda63381053aa522552','127.0.0.1','2026-09-04 06:10:05','__ci_last_regenerate|i:1788502205;csrf_ospos_v4|s:32:\"036e3e7008da6ef95218bb2e977452c5\";'),
('ospos_session:766ecc31a557f683925ea8a0bb22e427','127.0.0.1','2026-09-04 06:10:35','__ci_last_regenerate|i:1788502235;csrf_ospos_v4|s:32:\"a72ed7664e1969e3b98ffa6cc410318b\";'),
('ospos_session:78ed384a1b18e031337ddfa8fe9e3f99','127.0.0.1','2026-09-04 05:45:31','__ci_last_regenerate|i:1788500731;csrf_ospos_v4|s:32:\"3c75ce9eec55ce89d1a8cc4fdeb39625\";'),
('ospos_session:7b2474501a15bf0575aabc6f0d42e61c','127.0.0.1','2026-09-04 05:55:33','__ci_last_regenerate|i:1788501333;csrf_ospos_v4|s:32:\"75f907426ed50bb7d5ac1200cabcf904\";'),
('ospos_session:7bd618509827776de620cc70e5cb1d86','127.0.0.1','2026-09-04 06:06:04','__ci_last_regenerate|i:1788501964;csrf_ospos_v4|s:32:\"a7bfc112ec3d888f6d1beb008a8a825f\";'),
('ospos_session:7c4a44f2d9a030ff319bfef4d0149466','127.0.0.1','2026-09-04 05:51:32','__ci_last_regenerate|i:1788501092;csrf_ospos_v4|s:32:\"5302f42d5a623ced3a8f163a727d44c4\";'),
('ospos_session:7c84440fdac97b20952a252aef0f36c0','127.0.0.1','2026-09-04 06:14:35','__ci_last_regenerate|i:1788502475;csrf_ospos_v4|s:32:\"75f9ee88621d665b993c382077a8a6d6\";'),
('ospos_session:7f3c626acea1fd5be866ff249ba43e3a','127.0.0.1','2026-09-04 06:04:34','__ci_last_regenerate|i:1788501874;csrf_ospos_v4|s:32:\"71eb2bd95caf6a77efb31451f0ed2b85\";'),
('ospos_session:7f714a2fb192f0dd24130a56b0f07694','127.0.0.1','2026-09-04 05:54:33','__ci_last_regenerate|i:1788501273;csrf_ospos_v4|s:32:\"332093def0eed0bdc065193323c55a8c\";'),
('ospos_session:816c350844183061f80a0f19fd4800a9','127.0.0.1','2026-09-04 06:23:06','__ci_last_regenerate|i:1788502986;csrf_ospos_v4|s:32:\"24e33ec514eee7550ead6ede326f900d\";'),
('ospos_session:8213f4dc05249c01b6db1a412a446bff','127.0.0.1','2026-09-04 06:00:33','__ci_last_regenerate|i:1788501633;csrf_ospos_v4|s:32:\"7e85a87b734721e6f78d2452b29bfd1b\";'),
('ospos_session:93ededc09e93a48f9ce029a610d7778e','127.0.0.1','2026-09-04 05:51:02','__ci_last_regenerate|i:1788501062;csrf_ospos_v4|s:32:\"ba79dea7cf3daa158c7de01e04f635a9\";'),
('ospos_session:94983960482f8ff12397ac8cc83fd052','127.0.0.1','2026-09-04 06:18:36','__ci_last_regenerate|i:1788502716;csrf_ospos_v4|s:32:\"513294e45184a0178e40cac2a7eb1a59\";'),
('ospos_session:98385ce70674b2b6fb2b685ef212b68c','127.0.0.1','2026-09-04 05:59:33','__ci_last_regenerate|i:1788501573;csrf_ospos_v4|s:32:\"0272db0b547a84419e32f08a2e609a61\";'),
('ospos_session:a4db9ceaa1a291a2cdbc7b7c4bd1ea3b','127.0.0.1','2026-09-04 06:20:36','__ci_last_regenerate|i:1788502836;csrf_ospos_v4|s:32:\"31ab5af69a7f6bec7b7acae4e128d4cc\";'),
('ospos_session:a9a349f19c166c830923590d89bd134d','127.0.0.1','2026-09-04 06:24:06','__ci_last_regenerate|i:1788503046;csrf_ospos_v4|s:32:\"7927a67abcd88284f6713003dd18e6c1\";'),
('ospos_session:ab710c37d69d9e32d1db3daddd5661ae','127.0.0.1','2026-09-04 06:02:34','__ci_last_regenerate|i:1788501754;csrf_ospos_v4|s:32:\"2a79dc8b3c7a7d0f8ae1edee89cb08d3\";'),
('ospos_session:ad3ccaf99760ee1c5b8d08b7318731aa','127.0.0.1','2026-09-04 05:58:03','__ci_last_regenerate|i:1788501483;csrf_ospos_v4|s:32:\"d68dab1483565949482d50f78e284c59\";'),
('ospos_session:adacb4e82b527615e299b17f4efd8408','127.0.0.1','2026-09-04 06:21:06','__ci_last_regenerate|i:1788502866;csrf_ospos_v4|s:32:\"7eb966f798744fa877f3efe49d411707\";'),
('ospos_session:aea888587aa96c41445a1c58c4ee68fa','127.0.0.1','2026-09-04 05:58:33','__ci_last_regenerate|i:1788501513;csrf_ospos_v4|s:32:\"4f9e49cb39e3d1ec9340a8ea06bd091c\";'),
('ospos_session:af4923fb91b7288879ad881a2603ff74','127.0.0.1','2026-09-04 06:20:06','__ci_last_regenerate|i:1788502806;csrf_ospos_v4|s:32:\"092b12310e48a269004bbe669dd96dd5\";'),
('ospos_session:b16cf15dc81912c0f1b6da308285d487','127.0.0.1','2026-09-04 05:59:03','__ci_last_regenerate|i:1788501543;csrf_ospos_v4|s:32:\"c4983fb37d4ccec96bc59ba6c51fae95\";'),
('ospos_session:b8cf0d09bd20030b45069506ce82bb8b','127.0.0.1','2026-09-04 05:56:33','__ci_last_regenerate|i:1788501393;csrf_ospos_v4|s:32:\"53e548da5cb41f63c63349aefd92ea61\";'),
('ospos_session:b98b460ecb589d742af75af4be3d6fe4','127.0.0.1','2026-09-04 06:09:04','__ci_last_regenerate|i:1788502144;csrf_ospos_v4|s:32:\"9b0c8eb14441692b73d5f6581d06487a\";'),
('ospos_session:b9bf95e47f780c0edeb037c39900ea66','127.0.0.1','2026-09-04 06:01:33','__ci_last_regenerate|i:1788501693;csrf_ospos_v4|s:32:\"1b5ae4010c72d4252f56788b278823bd\";'),
('ospos_session:ba0fff87285feea0adca56c6525bb56c','127.0.0.1','2026-09-04 05:52:02','__ci_last_regenerate|i:1788501122;csrf_ospos_v4|s:32:\"52d7c1998d6b45278b9702f44c4729ed\";'),
('ospos_session:ba207d59958873b04331d6f7cb4e35d4','127.0.0.1','2026-09-04 06:06:34','__ci_last_regenerate|i:1788501994;csrf_ospos_v4|s:32:\"d73d08e0485b9c4c5dbf059aa123ae20\";'),
('ospos_session:bd39aa16cb021a808e3c15e33b7a2e29','127.0.0.1','2026-09-04 05:49:02','__ci_last_regenerate|i:1788500942;csrf_ospos_v4|s:32:\"e47a2f2b1e8371f5c50ccb6b1e028c7c\";'),
('ospos_session:cb02e23423357368089f2ae4acfdfc1d','127.0.0.1','2026-09-04 05:55:03','__ci_last_regenerate|i:1788501303;csrf_ospos_v4|s:32:\"421271f17957d19bf3c020e2df4ebaac\";'),
('ospos_session:d1a6150fb767a8f72b4fee7409ae4fce','127.0.0.1','2026-09-04 05:53:02','__ci_last_regenerate|i:1788501182;csrf_ospos_v4|s:32:\"0dd8a72fce196cc07878c0d6a42a1ddf\";'),
('ospos_session:d1a90a5848a4f51d282e19646464d8d0','127.0.0.1','2026-09-04 06:03:34','__ci_last_regenerate|i:1788501814;csrf_ospos_v4|s:32:\"a88c7ea38c9335f9e47b9638bca409c5\";'),
('ospos_session:d2673a034a423832dff7f20ecdeb8feb','127.0.0.1','2026-09-04 05:57:33','__ci_last_regenerate|i:1788501453;csrf_ospos_v4|s:32:\"cf19b0f8e34d9450393ebccb4632c27d\";'),
('ospos_session:d60d3df35c99c0f6871e279b9ddb7254','127.0.0.1','2026-09-04 05:53:32','__ci_last_regenerate|i:1788501212;csrf_ospos_v4|s:32:\"2e70ea9473de1935aff8ad889b33e2f9\";'),
('ospos_session:d637c3f7aec887c38d460c806ae6f398','127.0.0.1','2026-09-04 05:46:01','__ci_last_regenerate|i:1788500761;csrf_ospos_v4|s:32:\"e77c72f446ed2187351556fbba9165c3\";'),
('ospos_session:d7463b7eb595c39700a154b25d74585a','127.0.0.1','2026-09-04 06:14:05','__ci_last_regenerate|i:1788502445;csrf_ospos_v4|s:32:\"1fae017bd0c5c986b777ec4ab7b03f4d\";'),
('ospos_session:d852cbbc1982e3b418ab42a975b62548','127.0.0.1','2026-09-04 05:48:32','__ci_last_regenerate|i:1788500912;csrf_ospos_v4|s:32:\"3a2f5eada370fcf73e9420a4039a3c24\";'),
('ospos_session:d954963c33dffc39274c481c554fad60','127.0.0.1','2026-09-04 05:52:32','__ci_last_regenerate|i:1788501152;csrf_ospos_v4|s:32:\"42cf4236c68e0f3adefc78c7258fd457\";'),
('ospos_session:e0a0bf7652051013b187170bd12f1861','127.0.0.1','2026-09-04 05:46:31','__ci_last_regenerate|i:1788500791;csrf_ospos_v4|s:32:\"08352b182334393d6289da708a102c3a\";'),
('ospos_session:e36267e18f83db3a822e6a16efddbc71','127.0.0.1','2026-09-04 06:08:04','__ci_last_regenerate|i:1788502084;csrf_ospos_v4|s:32:\"5cb3083bfa50660c9daaf86b653969f0\";'),
('ospos_session:e3cfc371869872b7fcd81e5d6ca7124e','127.0.0.1','2026-09-04 06:15:05','__ci_last_regenerate|i:1788502505;csrf_ospos_v4|s:32:\"cd3f1b58e1b6c5b9db6f464b58044043\";'),
('ospos_session:e41f0c7ccf4dfe6bc84e750f8311c277','127.0.0.1','2026-09-04 06:03:04','__ci_last_regenerate|i:1788501784;csrf_ospos_v4|s:32:\"7943ceaa5ec88cb3118d65978e5fe163\";'),
('ospos_session:e6960ed30128b3633c7d72d7a944230b','127.0.0.1','2026-09-04 06:05:34','__ci_last_regenerate|i:1788501934;csrf_ospos_v4|s:32:\"cb38287308be19bbe23cc3a563d897b5\";'),
('ospos_session:e8b446544dbb6c50555743ac99b7a9d2','127.0.0.1','2026-09-04 06:07:34','__ci_last_regenerate|i:1788502054;csrf_ospos_v4|s:32:\"2573660c0d40699051da8a1e9cd91895\";'),
('ospos_session:eb468659f1562518e8fb56a4028f23d0','127.0.0.1','2026-09-04 06:01:03','__ci_last_regenerate|i:1788501663;csrf_ospos_v4|s:32:\"ae0996cd7151cae8d6dd863387bc5d1b\";'),
('ospos_session:f03016181ce6bd3a6ea62d1199201018','127.0.0.1','2026-09-04 05:50:02','__ci_last_regenerate|i:1788501002;csrf_ospos_v4|s:32:\"77bd5c4b7d3206d7e64e8b9ab907fada\";'),
('ospos_session:f21abf62ed96be6986c3d7d5d8df5c20','127.0.0.1','2026-09-04 06:04:04','__ci_last_regenerate|i:1788501844;csrf_ospos_v4|s:32:\"2ddb19294d05947c66ca2225b2cfb977\";'),
('ospos_session:f2e50cf78f0eb48d1096a2cd6ab8a856','127.0.0.1','2026-09-04 06:25:07','__ci_last_regenerate|i:1788503107;csrf_ospos_v4|s:32:\"cbf0704f32427fa3df709add84e1cdb6\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'Warehouse',0),
(2,'Shop',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(2,'FFC','FFC',NULL,'',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-04  6:45:58
