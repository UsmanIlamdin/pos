/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','id'),
('barcode_first_row','name'),
('barcode_font','0'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','0'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C128'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','1'),
('category_dropdown','0'),
('clcdesq_api_key',''),
('clcdesq_api_url',''),
('company','CortexFlow Point of Sale'),
('company_logo','Test2.png'),
('country_codes','us'),
('currency_code','PKR'),
('currency_decimals','2'),
('currency_symbol','Rs'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format','0'),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category','Standard'),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','0'),
('dinner_table_enable','0'),
('email','changeme@example.com'),
('email_receipt_check_behaviour','never'),
('enforce_privacy','0'),
('fax',''),
('financial_year','9'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','jpg,gif,png'),
('image_max_height','640'),
('image_max_size','1024'),
('image_max_width','821'),
('include_hsn','0'),
('invoice_default_comments','Thanks'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','12003'),
('last_used_quote_number','200'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form','floating_labels'),
('mailchimp_api_key',''),
('mailchimp_list_id',''),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('payment_reference_code_max','40'),
('payment_reference_code_min','3'),
('phone','555-555-5555'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','never'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','12'),
('receipt_show_company_name','1'),
('receipt_show_description','0'),
('receipt_show_serialnumber','1'),
('receipt_show_taxes','1'),
('receipt_show_tax_ind','1'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_default'),
('receiving_calculate_average_price','0'),
('recv_invoice_format','{CO}'),
('return_policy','Test'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id',''),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','Asia/Karachi'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Expiry Date','DATE',NULL,7,NULL,0),
(2,'New','DROPDOWN',NULL,7,NULL,0),
(3,'Is Shelf Life','CHECKBOX',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,1,NULL,NULL,'1-1'),
(2,2,NULL,NULL,NULL,NULL),
(3,2,NULL,NULL,NULL,NULL),
(2,2,1,NULL,NULL,'2-1'),
(4,3,1,NULL,NULL,'3-1'),
(1,1,1,4,NULL,NULL),
(2,2,1,4,NULL,NULL),
(4,3,1,4,NULL,NULL),
(5,1,2,NULL,NULL,'1-2'),
(1,1,1,7,NULL,NULL),
(2,2,1,7,NULL,NULL),
(4,3,1,7,NULL,NULL),
(5,1,2,7,NULL,NULL),
(1,1,1,8,NULL,NULL),
(2,2,1,8,NULL,NULL),
(4,3,1,8,NULL,NULL),
(5,1,2,8,NULL,NULL),
(5,1,2,9,NULL,NULL),
(1,1,1,10,NULL,NULL),
(2,2,1,10,NULL,NULL),
(4,3,1,10,NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,NULL,'2026-09-20',NULL),
(2,'A',NULL,NULL),
(3,'B',NULL,NULL),
(4,'1',NULL,NULL),
(5,NULL,'2026-09-24',NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-09-13 13:13:33','2026-09-13 13:13:33',0.00,0.00,0,0.00,0.00,0.00,0.00,'',2,2,0,0.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(3,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-13 13:17:23',1,1),
(4,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-13 13:22:53',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('admin','$2y$10$vJBSMlD02EC7ENSrKfVQXuvq9tNRHMtcOA8MSK2NYS748HHWm.gcG',1,0,2,NULL,NULL),
('admin1','$2y$10$57DDuHE6hTzSpfV8ftRU5OfpVbnsiGOAj38dfXg58mwpfpzYOYhoe',2,0,2,'','');
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('cashups',2,'office'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_stock',1,'home'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_stock',1,'home'),
('reports',1,'home'),
('reports_categories',1,'home'),
('reports_customers',1,'home'),
('reports_discounts',1,'home'),
('reports_employees',1,'home'),
('reports_expenses_categories',1,'home'),
('reports_inventory',1,'home'),
('reports_items',1,'home'),
('reports_payments',1,'home'),
('reports_receivings',1,'home'),
('reports_sales',1,'home'),
('reports_sales_taxes',1,'home'),
('reports_suppliers',1,'home'),
('reports_taxes',1,'home'),
('sales',1,'home'),
('sales',2,'both'),
('sales_change_price',1,'--'),
('sales_change_price',2,'--'),
('sales_delete',1,'--'),
('sales_delete',2,'--'),
('sales_stock',1,'home'),
('sales_stock',2,'--'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-09-13 12:47:09','Manual Edit of Quantity',1,0.000),
(2,1,2,'2026-09-13 13:12:28','POS 1',1,-90.000),
(3,1,1,'2026-09-13 13:15:55','Manual Edit of Quantity',1,20090.000),
(4,1,1,'2026-09-13 13:20:53','POS 2',1,-11.000),
(5,1,1,'2026-09-13 13:23:09','POS 3',1,-1.000),
(6,2,1,'2026-09-13 13:53:16','Manual Edit of Quantity',1,0.000),
(7,1,1,'2026-09-14 07:38:50','POS 4',1,-2.000),
(8,2,1,'2026-09-15 08:45:52','Manual Edit of Quantity',1,200.000),
(9,3,1,'2026-09-15 10:00:06','Manual Edit of Quantity',1,0.000),
(10,4,1,'2026-09-15 10:00:11','Manual Edit of Quantity',1,0.000),
(11,5,1,'2026-09-15 10:00:19','Manual Edit of Quantity',1,0.000),
(12,6,1,'2026-09-15 10:00:25','Manual Edit of Quantity',1,0.000),
(13,7,1,'2026-09-15 10:00:33','Manual Edit of Quantity',1,0.000),
(14,8,1,'2026-09-15 10:00:40','Manual Edit of Quantity',1,0.000),
(15,9,1,'2026-09-15 10:00:47','Manual Edit of Quantity',1,0.000),
(16,10,1,'2026-09-15 10:00:55','Manual Edit of Quantity',1,0.000),
(17,11,1,'2026-09-15 10:01:00','Manual Edit of Quantity',1,0.000),
(18,12,1,'2026-09-15 10:01:08','Manual Edit of Quantity',1,0.000),
(19,13,1,'2026-09-15 10:01:13','Manual Edit of Quantity',1,0.000),
(20,14,1,'2026-09-15 10:01:23','Manual Edit of Quantity',1,0.000),
(21,15,1,'2026-09-15 10:01:29','Manual Edit of Quantity',1,0.000),
(22,16,1,'2026-09-15 10:01:35','Manual Edit of Quantity',1,0.000),
(23,17,1,'2026-09-15 10:01:42','Manual Edit of Quantity',1,0.000),
(24,18,1,'2026-09-15 10:01:54','Manual Edit of Quantity',1,0.000),
(25,19,1,'2026-09-15 10:02:00','Manual Edit of Quantity',1,0.000),
(26,20,1,'2026-09-15 10:02:06','Manual Edit of Quantity',1,0.000),
(27,21,1,'2026-09-15 10:02:12','Manual Edit of Quantity',1,0.000),
(28,22,1,'2026-09-15 10:02:18','Manual Edit of Quantity',1,0.000),
(29,23,1,'2026-09-15 10:02:23','Manual Edit of Quantity',1,0.000),
(30,24,1,'2026-09-15 10:02:28','Manual Edit of Quantity',1,0.000),
(31,3,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(32,12,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(33,13,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(34,11,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(35,10,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(36,9,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(37,24,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(38,18,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(39,20,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(40,4,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(41,22,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(42,23,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(43,17,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(44,16,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(45,3,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(46,4,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(47,5,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(48,6,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(49,7,1,'2026-09-15 10:09:00','POS 6',1,-2.000),
(50,8,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(51,9,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(52,1,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(53,2,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(54,3,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(55,4,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(56,5,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(57,7,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(58,8,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(59,9,1,'2026-09-17 18:53:01','POS 7',1,-1.000),
(60,1,1,'2026-09-17 18:54:37','POS 8',1,-1.000),
(61,2,1,'2026-09-17 18:54:37','POS 8',1,-1.000),
(62,2,1,'2026-09-17 19:04:05','POS 9',1,-1.000),
(63,1,1,'2026-09-17 19:06:20','POS 10',1,-10.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,19974.000),
(2,1,197.000),
(3,1,-4.000),
(4,1,-3.000),
(5,1,-2.000),
(6,1,-1.000),
(7,1,-3.000),
(8,1,-2.000),
(9,1,-3.000),
(10,1,-1.000),
(11,1,-2.000),
(12,1,-2.000),
(13,1,-1.000),
(14,1,0.000),
(15,1,0.000),
(16,1,-1.000),
(17,1,-1.000),
(18,1,-2.000),
(19,1,0.000),
(20,1,-1.000),
(21,1,0.000),
(22,1,-1.000),
(23,1,-2.000),
(24,1,-2.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Coca Cola 1.5L','Beverage',NULL,'Coca Cola 1.5L','',200.00,220.00,10.000,20000.000,1,NULL,0,0,0,0,0,NULL,1.000,'Each',1,''),
('Coca Cola 1L','Beverage',NULL,'011235698702','',200.00,220.00,10.000,10.000,2,NULL,0,0,0,0,0,NULL,1.000,'Each',2,''),
('Test 1','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,3,NULL,0,0,0,0,0,NULL,1.000,'Each',3,''),
('Test 2','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,4,NULL,0,0,0,0,0,NULL,1.000,'Each',4,''),
('Test 3','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,5,NULL,0,0,0,0,0,NULL,1.000,'Each',5,''),
('Test 4','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,6,NULL,0,0,0,0,0,NULL,1.000,'Each',6,''),
('Test 5','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,7,NULL,0,0,0,0,0,NULL,1.000,'Each',7,''),
('Test 6','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,8,NULL,0,0,0,0,0,NULL,1.000,'Each',8,''),
('Test 7','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,9,NULL,0,0,0,0,0,NULL,1.000,'Each',9,''),
('Test 8','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,10,NULL,0,0,0,0,0,NULL,1.000,'Each',10,''),
('Test 9','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,11,NULL,0,0,0,0,0,NULL,1.000,'Each',11,''),
('Test 10','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,12,NULL,0,0,0,0,0,NULL,1.000,'Each',12,''),
('Test 11','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,13,NULL,0,0,0,0,0,NULL,1.000,'Each',13,''),
('Test 12','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,14,NULL,0,0,0,0,0,NULL,1.000,'Each',14,''),
('Test 13','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,15,NULL,0,0,0,0,0,NULL,1.000,'Each',15,''),
('Test 14','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,16,NULL,0,0,0,0,0,NULL,1.000,'Each',16,''),
('Test 15','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,17,NULL,0,0,0,0,0,NULL,1.000,'Each',17,''),
('Test 16','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,18,NULL,0,0,0,0,0,NULL,1.000,'Each',18,''),
('Test 17','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,19,NULL,0,0,0,0,0,NULL,1.000,'Each',19,''),
('Test 18','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,20,NULL,0,0,0,0,0,NULL,1.000,'Each',20,''),
('Test 19','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,21,NULL,0,0,0,0,0,NULL,1.000,'Each',21,''),
('Test 20','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,22,NULL,0,0,0,0,0,NULL,1.000,'Each',22,''),
('Test 21','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,23,NULL,0,0,0,0,0,NULL,1.000,'Each',23,''),
('Test 22','Beverage',NULL,NULL,'',200.00,220.00,1.000,1.000,24,NULL,0,0,0,0,0,NULL,1.000,'Each',24,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1789267453,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1789267453,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1789267453,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1789267453,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1789267453,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1789267453,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1789267453,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1789267454,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1789267454,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1789267454,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1789267454,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1789267454,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1789267454,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1789267454,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1789267454,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1789267454,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1789267454,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1789267454,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1789267454,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1789267454,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1789267454,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1789267454,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1789267454,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1789267454,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1789267454,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1789267454,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1789267454,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1789267454,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1789267454,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1789267454,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1789267454,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1789267454,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1789267454,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1789267454,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1789267454,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1789267454,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1789267454,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1789267454,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1789267454,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1789267454,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1789267454,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1789267454,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1789267454,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1789267454,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1789267454,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('John','Doe',NULL,'555-555-5555','changeme@example.com','Address 1','','','','','','',1),
('Admin','Admin',1,'','admin@gmail.com','','','','','','','',2),
('Zahidul','Islam',1,'+9230158043754','changeme@example.com','Street # 4, Makkah Town, Khudian, Kasur','','Kasur','','','Pakistan','',3),
('Alex','Alex',NULL,'','','','','','','','','',4),
('Umair','Umair',1,'','','','','','','','','',5),
('Usman','Usman',NULL,'','','','','','','','','',6);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_stock','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_stock','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_stock','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-09-13 13:12:28',NULL,2,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-09-13 13:20:53',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-09-13 13:23:09',4,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-14 07:38:50',NULL,1,'',NULL,NULL,4,NULL,0,NULL,0),
('2026-09-15 10:03:34',NULL,1,'','5',NULL,5,NULL,0,NULL,0),
('2026-09-15 10:09:00',4,1,'','1',NULL,6,NULL,0,NULL,1),
('2026-09-17 18:53:01',NULL,1,'',NULL,NULL,7,NULL,0,NULL,0),
('2026-09-17 18:54:37',NULL,1,'',NULL,NULL,8,NULL,0,NULL,0),
('2026-09-17 19:04:05',4,1,'THis is the Invoice of the Receipt','2',NULL,9,NULL,0,NULL,1),
('2026-09-17 19:06:20',4,1,'','889756466',NULL,10,NULL,0,NULL,1);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,90.000,0.00,0.00,0.00,0,1,0),
(2,1,'','',1,11.000,0.00,0.00,0.00,0,1,0),
(3,1,'','',1,1.000,190.00,200.00,0.00,0,1,0),
(4,1,'','',1,2.000,190.00,200.00,0.00,0,1,0),
(5,3,'','',1,2.000,0.00,0.00,0.00,0,1,0),
(5,4,'','',10,1.000,0.00,0.00,0.00,0,1,0),
(5,9,'','',6,1.000,0.00,0.00,0.00,0,1,0),
(5,10,'','',5,1.000,0.00,0.00,0.00,0,1,0),
(5,11,'','',4,2.000,0.00,0.00,0.00,0,1,0),
(5,12,'','',2,2.000,0.00,0.00,0.00,0,1,0),
(5,13,'','',3,1.000,0.00,0.00,0.00,0,1,0),
(5,16,'','',14,1.000,0.00,0.00,0.00,0,1,0),
(5,17,'','',13,1.000,0.00,0.00,0.00,0,1,0),
(5,18,'','',8,2.000,0.00,0.00,0.00,0,1,0),
(5,20,'','',9,1.000,0.00,0.00,0.00,0,1,0),
(5,22,'','',11,1.000,0.00,0.00,0.00,0,1,0),
(5,23,'','',12,2.000,0.00,0.00,0.00,0,1,0),
(5,24,'','',7,2.000,0.00,0.00,0.00,0,1,0),
(6,3,'','',1,1.000,0.00,0.00,0.00,0,1,0),
(6,4,'','',2,1.000,0.00,0.00,0.00,0,1,0),
(6,5,'','',3,1.000,0.00,0.00,0.00,0,1,0),
(6,6,'','',4,1.000,0.00,0.00,0.00,0,1,0),
(6,7,'','',5,2.000,0.00,0.00,0.00,0,1,0),
(6,8,'','',6,1.000,0.00,0.00,0.00,0,1,0),
(6,9,'','',7,1.000,0.00,0.00,0.00,0,1,0),
(7,1,'','',1,1.000,200.00,220.00,0.00,0,1,0),
(7,2,'','',2,1.000,200.00,220.00,0.00,0,1,0),
(7,3,'','',3,1.000,200.00,220.00,0.00,0,1,0),
(7,4,'','',4,1.000,200.00,220.00,0.00,0,1,0),
(7,5,'','',5,1.000,200.00,220.00,0.00,0,1,0),
(7,7,'','',6,1.000,200.00,220.00,0.00,0,1,0),
(7,8,'','',7,1.000,200.00,220.00,0.00,0,1,0),
(7,9,'','',8,1.000,200.00,220.00,0.00,0,1,0),
(8,1,'','',1,1.000,200.00,220.00,20.00,0,1,0),
(8,2,'','',2,1.000,200.00,220.00,20.00,0,1,0),
(9,2,'','',1,1.000,200.00,220.00,0.00,0,1,0),
(10,1,'','',1,10.000,200.00,220.00,0.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,3,'Due',200.00,0.00,0,1,'2026-09-13 17:23:09',''),
(2,4,'Cash',400.00,0.00,0,1,'2026-09-14 11:38:50',''),
(3,7,'Bank Transfer',1760.00,0.00,0,1,'2026-09-17 13:53:01',''),
(4,8,'Cash',352.00,0.00,0,1,'2026-09-17 13:54:37','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:0136f25a76dc9ff312d5a0377c963fae','127.0.0.1','2026-09-17 13:59:54','__ci_last_regenerate|i:1789653594;csrf_ospos_v4|s:32:\"9a947d3e45d271dcf9d0e543775ed2a1\";'),
('ospos_session:0308deb16b7a213dc85cb1c305471c17','127.0.0.1','2026-09-17 13:58:54','__ci_last_regenerate|i:1789653534;csrf_ospos_v4|s:32:\"5a623439d859099ce47a5dada98d02c9\";'),
('ospos_session:06f1578b85952ecbebd29933931e6175','127.0.0.1','2026-09-17 14:04:55','__ci_last_regenerate|i:1789653895;csrf_ospos_v4|s:32:\"7d3393077145c72d9d3f13960de5affe\";'),
('ospos_session:0a8bc8089b64a87fb426f2b6fdf3775d','127.0.0.1','2026-09-17 13:54:24','__ci_last_regenerate|i:1789653264;csrf_ospos_v4|s:32:\"9ad6127f0c3448573958eb41086b4695\";'),
('ospos_session:0ba1ca5c9d7de04232a915b35a77e323','127.0.0.1','2026-09-17 13:50:53','__ci_last_regenerate|i:1789653053;csrf_ospos_v4|s:32:\"88a9d6130bbc0dafc2184add4ae96909\";'),
('ospos_session:125a9c0b72881ea23d3f0d980a0bafd9','127.0.0.1','2026-09-17 13:58:24','__ci_last_regenerate|i:1789653504;csrf_ospos_v4|s:32:\"7fcd9515f749a02a337b42add5f402d3\";'),
('ospos_session:14e5802b88f88580e20a54ac986e91a2','127.0.0.1','2026-09-17 13:49:23','__ci_last_regenerate|i:1789652963;csrf_ospos_v4|s:32:\"3d27e5b7cd16246e2fb1619e60e2a3b9\";'),
('ospos_session:18ead4ba4c74b5ad1120139de343162c','127.0.0.1','2026-09-17 14:11:56','__ci_last_regenerate|i:1789654316;csrf_ospos_v4|s:32:\"ed062421eb73dad70115bed75f9a23e9\";'),
('ospos_session:1ae106d479671fdfff37ed030f71aa22','127.0.0.1','2026-09-17 14:05:25','__ci_last_regenerate|i:1789653925;csrf_ospos_v4|s:32:\"928cab51d228977bfda6d9b0771bf72d\";'),
('ospos_session:29f270659f2bd5608001f6a21d604bd5','127.0.0.1','2026-09-17 13:56:54','__ci_last_regenerate|i:1789653414;csrf_ospos_v4|s:32:\"d1a68292fb226d5551ac57e4fb4e9a64\";'),
('ospos_session:2d7297b7b783b3730da77b96841292b9','127.0.0.1','2026-09-17 14:02:55','__ci_last_regenerate|i:1789653775;csrf_ospos_v4|s:32:\"15d0c4f03aced4e24f64fb1412864aef\";'),
('ospos_session:324428403b60f88a1b7f60fb0e2a8a75','127.0.0.1','2026-09-17 14:03:25','__ci_last_regenerate|i:1789653805;csrf_ospos_v4|s:32:\"599916461f60f12a4c2249110097af48\";'),
('ospos_session:3531cb00b7589f8cd4ee61fe3c72beb6','127.0.0.1','2026-09-17 13:46:52','__ci_last_regenerate|i:1789652812;csrf_ospos_v4|s:32:\"f9ac1ba5b376326bab257dbdcbe62700\";'),
('ospos_session:3a38b30e289dbe3d616cf008efca2f0e','127.0.0.1','2026-09-17 14:09:26','__ci_last_regenerate|i:1789654166;csrf_ospos_v4|s:32:\"239a0e7fb18d489341dee0f569489cc0\";'),
('ospos_session:3ef7c7a4bbbf22e59b85c59b61c0e1fb','127.0.0.1','2026-09-17 13:59:24','__ci_last_regenerate|i:1789653564;csrf_ospos_v4|s:32:\"b8ea13750b389316790fc30eb117fbf9\";'),
('ospos_session:4771d740382b3b5b2ec6cc91057f5192','127.0.0.1','2026-09-17 14:10:56','__ci_last_regenerate|i:1789654256;csrf_ospos_v4|s:32:\"b38849f51ba2930e40a8127c8de27498\";'),
('ospos_session:4e6577b5f7992be84538b5f9a1f97af7','127.0.0.1','2026-09-17 13:52:53','__ci_last_regenerate|i:1789653173;csrf_ospos_v4|s:32:\"22417066069fe0b958091ae35a7d5674\";'),
('ospos_session:502bce8a1b3d420d420c0d9a9ea9cadf','127.0.0.1','2026-09-17 14:01:55','__ci_last_regenerate|i:1789653715;csrf_ospos_v4|s:32:\"24a491e0bffdbf9f6e33c81c53279c1e\";'),
('ospos_session:54b5b71fd25099f716e472491cb25166','127.0.0.1','2026-09-17 13:54:54','__ci_last_regenerate|i:1789653294;csrf_ospos_v4|s:32:\"448818e002b8ce74289504a3380d9de9\";'),
('ospos_session:5d9bd23afbcb1302d085d3741e5ada43','127.0.0.1','2026-09-17 14:09:56','__ci_last_regenerate|i:1789654196;csrf_ospos_v4|s:32:\"0ecf76565d7b98397f79137b8560e41c\";'),
('ospos_session:61fbb7a33474ab2bdd7c875e5ea7e26e','127.0.0.1','2026-09-17 14:08:25','__ci_last_regenerate|i:1789654105;csrf_ospos_v4|s:32:\"c674ee15a619d3f62a572fc62a734711\";'),
('ospos_session:6691deb2feb121cbf93891721f4a6edc','127.0.0.1','2026-09-17 13:49:53','__ci_last_regenerate|i:1789652993;csrf_ospos_v4|s:32:\"16c8fa51a515912f8193cdda6258176f\";'),
('ospos_session:6afb5a49c19df42d6aa11027befd3b9c','127.0.0.1','2026-09-17 14:00:54','__ci_last_regenerate|i:1789653654;csrf_ospos_v4|s:32:\"51a887d27f8e1e8aed681d7e33991150\";'),
('ospos_session:6e48c79a65d332cdc02d46f4f35feb4f','127.0.0.1','2026-09-17 13:53:54','__ci_last_regenerate|i:1789653234;csrf_ospos_v4|s:32:\"6bb712db822eff6fffd1cb2ff973ea6d\";'),
('ospos_session:72e6719965ca0040ef4b83cabff52df9','127.0.0.1','2026-09-17 13:55:24','__ci_last_regenerate|i:1789653324;csrf_ospos_v4|s:32:\"7671b1feea645cdf332fc72d20008b4d\";'),
('ospos_session:73dec79cb7333f9f549f448c9d0eee0e','127.0.0.1','2026-09-17 13:48:53','__ci_last_regenerate|i:1789652933;csrf_ospos_v4|s:32:\"12253a5e1851bb3a98d7fe1097b643e0\";'),
('ospos_session:7c407efbb9ecf6c3da83cc4dbd58e9b7','127.0.0.1','2026-09-17 14:06:25','__ci_last_regenerate|i:1789653985;csrf_ospos_v4|s:32:\"49c35ecbfd239858d943254f86333421\";'),
('ospos_session:86dfb43ecc1811abb5ad4aa244794c30','127.0.0.1','2026-09-17 14:10:26','__ci_last_regenerate|i:1789654226;csrf_ospos_v4|s:32:\"4abbfdbd6af7afdc02dde46f65eb611f\";'),
('ospos_session:8c38f44d8ecdf8e0cd555222223daf34','127.0.0.1','2026-09-17 13:46:22','__ci_last_regenerate|i:1789652782;csrf_ospos_v4|s:32:\"68ca06aed78974a58d233f68578b0114\";'),
('ospos_session:8fd19f14c9b572cb7174f665b7c72b68','127.0.0.1','2026-09-17 13:51:53','__ci_last_regenerate|i:1789653113;csrf_ospos_v4|s:32:\"fe3e21776c6bfa100b8320bbfe12daf9\";'),
('ospos_session:94ead181825699fba4b9bcdad40b33f0','127.0.0.1','2026-09-17 13:51:23','__ci_last_regenerate|i:1789653083;csrf_ospos_v4|s:32:\"675600e5dee70fdf8a87a754e6941a26\";'),
('ospos_session:966edda51f75438155391f395f4b2635','127.0.0.1','2026-09-17 14:08:55','__ci_last_regenerate|i:1789654135;csrf_ospos_v4|s:32:\"85e84733717638adf59a7a8bfeda03e5\";'),
('ospos_session:96ac7e13066415893ebdcd388936c6b7','127.0.0.1','2026-09-17 14:01:24','__ci_last_regenerate|i:1789653684;csrf_ospos_v4|s:32:\"479b9cf26aaa907a3a3e650b15121752\";'),
('ospos_session:971c2c1733b50f21c1c65b0a33f40b02','172.20.0.2','2026-09-17 14:10:38','__ci_last_regenerate|i:1789654184;csrf_ospos_v4|s:32:\"957453e9107d3ef92498a367d2c24e21\";_ci_previous_url|s:28:\"https://ghazi-pos.local/home\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:1;sale_id|i:-1;sales_location|i:1;sales_employee|i:1;cash_adjustment_amount|d:0;item_location|s:1:\"1\";recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_supplier|i:-1;sales_print_after_sale|b:1;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:0:{}sales_customer|i:-1;sales_mode|s:4:\"sale\";sales_payments|a:0:{}'),
('ospos_session:a285523bc636eb901e6e506b19d68003','127.0.0.1','2026-09-17 13:57:24','__ci_last_regenerate|i:1789653444;csrf_ospos_v4|s:32:\"8c01c963bb6ef160010fe82b4462c677\";'),
('ospos_session:a3389e802dacaa4998a2b6e9ffc92971','127.0.0.1','2026-09-17 14:05:55','__ci_last_regenerate|i:1789653955;csrf_ospos_v4|s:32:\"d258fd9c4df294a409ea0bc6a11f9feb\";'),
('ospos_session:a6d7257f59c0c10bf790a9931df12d40','127.0.0.1','2026-09-17 13:52:23','__ci_last_regenerate|i:1789653143;csrf_ospos_v4|s:32:\"b6fadddb9bb6d95fb97e1febd80bba54\";'),
('ospos_session:aab565c7938d168f8838e76c68ecfc44','127.0.0.1','2026-09-17 13:50:23','__ci_last_regenerate|i:1789653023;csrf_ospos_v4|s:32:\"ce7aa10702ebcc8ff604c4c6fefba1e3\";'),
('ospos_session:add96177844d18fb9f35282939626a4b','127.0.0.1','2026-09-17 14:07:25','__ci_last_regenerate|i:1789654045;csrf_ospos_v4|s:32:\"f83d2778fa76ccfa007d09bdd8a53df5\";'),
('ospos_session:b543e941a9cf0c9ba50daada50a18c2b','127.0.0.1','2026-09-17 14:00:24','__ci_last_regenerate|i:1789653624;csrf_ospos_v4|s:32:\"77709439104a36e7f237fe697eae50fb\";'),
('ospos_session:b6c8731cf2c97522c23ac681f23ce25c','127.0.0.1','2026-09-17 14:11:26','__ci_last_regenerate|i:1789654286;csrf_ospos_v4|s:32:\"7506f8a8286c6d83e040f97d72f3d4eb\";'),
('ospos_session:ba6528ce54819fc83345654641a0954e','127.0.0.1','2026-09-17 13:56:24','__ci_last_regenerate|i:1789653384;csrf_ospos_v4|s:32:\"16ab6198428744baa240fecc72a084dc\";'),
('ospos_session:c4c0aa344b4580e8b66ecbfe1c8c4a7b','127.0.0.1','2026-09-17 14:02:25','__ci_last_regenerate|i:1789653745;csrf_ospos_v4|s:32:\"b41dcf0b813a0e8f9784cafe1009af84\";'),
('ospos_session:c6357a93f6f24b1590c4c49b11d6c67c','127.0.0.1','2026-09-17 14:07:55','__ci_last_regenerate|i:1789654075;csrf_ospos_v4|s:32:\"059614864d0fc6ba17b6bbbbbf52467f\";'),
('ospos_session:dbeb24cb7a2b5810aa4fd25ddca78f94','127.0.0.1','2026-09-17 13:47:23','__ci_last_regenerate|i:1789652843;csrf_ospos_v4|s:32:\"0d20610ded8f7455b3c48267e863eab1\";'),
('ospos_session:dfafca1a37a8775e4d34977143f360ac','127.0.0.1','2026-09-17 13:48:23','__ci_last_regenerate|i:1789652903;csrf_ospos_v4|s:32:\"0e58753b6510277a2150aec5684ae29d\";'),
('ospos_session:e5944e4135f22d8f75c27510d99ce2d0','127.0.0.1','2026-09-17 14:06:55','__ci_last_regenerate|i:1789654015;csrf_ospos_v4|s:32:\"82b094ca965414dfce2488c8097f8592\";'),
('ospos_session:e8d1414f34ab0929067a963712b7f2e8','127.0.0.1','2026-09-17 13:57:54','__ci_last_regenerate|i:1789653474;csrf_ospos_v4|s:32:\"2a2b9b1fad4d63350b743444a5f13f9b\";'),
('ospos_session:eacdc406f1c79ef48d6ab77b68c5bbdf','127.0.0.1','2026-09-17 14:03:55','__ci_last_regenerate|i:1789653835;csrf_ospos_v4|s:32:\"6665e97b4ae0723c1691ff76648c43a8\";'),
('ospos_session:ebf8e14110033b6439657a6b2539948b','127.0.0.1','2026-09-17 13:47:53','__ci_last_regenerate|i:1789652873;csrf_ospos_v4|s:32:\"a23f9afed660271d37bf151531a6576b\";'),
('ospos_session:eecbf4dbdf2eae549c246b1bec8be766','127.0.0.1','2026-09-17 13:53:23','__ci_last_regenerate|i:1789653203;csrf_ospos_v4|s:32:\"b8a0b2ccbd86ba901966d43f3f4f18d0\";'),
('ospos_session:f475411ae7414316d0f36434e3520ac4','127.0.0.1','2026-09-17 13:55:54','__ci_last_regenerate|i:1789653354;csrf_ospos_v4|s:32:\"d92813581591bc4c74a8b7a2eaa66ef9\";'),
('ospos_session:ff1b3f5e087e1ed1e0545a18e05eadaf','127.0.0.1','2026-09-17 14:04:25','__ci_last_regenerate|i:1789653865;csrf_ospos_v4|s:32:\"e006b1af26e6a792235bfa6b3009c4a3\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'stock',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(5,'PakLight','',NULL,'',0,0),
(6,'KM','',NULL,'',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-18 11:04:50
