/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','number'),
('barcode_first_row','name'),
('barcode_font','fontawesome-webfont.ttf'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','1'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C128'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','0'),
('category_dropdown',''),
('company','Ghazi Trader'),
('company_logo','pngegg.png'),
('country_codes','pk'),
('currency_code','PKR'),
('currency_decimals','2'),
('currency_symbol','Rs'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format',''),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category','Standard'),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','0'),
('dinner_table_enable','0'),
('email','usman@gmail.com'),
('email_receipt_check_behaviour','never'),
('enforce_privacy','0'),
('fax',''),
('financial_year','1'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','gif,jpg,png'),
('image_max_height','480'),
('image_max_size','128'),
('image_max_width','640'),
('include_hsn','0'),
('invoice_default_comments','This is a default comment'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','0'),
('last_used_quote_number','1'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form',''),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('phone','+923015804375'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','never'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','10'),
('receipt_show_company_name','1'),
('receipt_show_description','0'),
('receipt_show_serialnumber','0'),
('receipt_show_taxes','1'),
('receipt_show_tax_ind','0'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_short'),
('receiving_calculate_average_price',''),
('recv_invoice_format','{CO}'),
('return_policy','Items can be exchange only after 7 days in unworn codition'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id',''),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','Asia/Karachi'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Company','DROPDOWN',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,NULL,NULL,NULL,NULL),
(2,1,NULL,NULL,NULL,NULL),
(2,1,3,NULL,1,NULL),
(2,1,3,8,NULL,NULL),
(1,1,1,8,NULL,NULL),
(2,1,3,9,NULL,NULL),
(1,1,1,9,NULL,NULL),
(2,1,3,10,NULL,NULL),
(1,1,1,10,NULL,NULL),
(2,1,3,11,NULL,NULL),
(1,1,1,11,NULL,NULL),
(1,1,1,12,NULL,NULL),
(2,1,3,12,NULL,NULL),
(1,1,1,13,NULL,NULL),
(1,1,1,14,NULL,NULL),
(1,1,1,NULL,NULL,'1-1'),
(2,1,3,NULL,NULL,'1-3'),
(1,1,1,15,NULL,NULL),
(1,1,1,16,NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,'FFC',NULL,NULL),
(2,'FFC2',NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-08-28 17:53:43','2026-08-28 17:53:43',12000.00,2000.00,1,10000.00,3000.00,0.00,0.00,'',1,1,0,1000.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(3,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-02 14:38:53',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('usman','$2y$10$7pp9sA73yJ0vDkH2JSBYL.VyOcJNgjdOT7AkAlzmdUtatts/EVbZa',1,0,2,'','');
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
INSERT INTO `ospos_expense_categories` VALUES
(1,'FFC','New Expens',0);
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
INSERT INTO `ospos_giftcards` VALUES
('2026-09-02 14:42:34',1,'455413123121312',50.00,0,3);
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_Shop',1,'--'),
('items_Warehouse',1,'--'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_Shop',1,'--'),
('receivings_Warehouse',1,'--'),
('reports',1,'home'),
('reports_categories',1,'--'),
('reports_customers',1,'--'),
('reports_discounts',1,'--'),
('reports_employees',1,'--'),
('reports_expenses_categories',1,'--'),
('reports_inventory',1,'--'),
('reports_items',1,'--'),
('reports_payments',1,'--'),
('reports_receivings',1,'--'),
('reports_sales',1,'--'),
('reports_sales_taxes',1,'--'),
('reports_suppliers',1,'--'),
('reports_taxes',1,'--'),
('sales',1,'home'),
('sales_change_price',1,'--'),
('sales_delete',1,'--'),
('sales_Shop',1,'--'),
('sales_Warehouse',1,'--'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',1,20.000),
(2,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',2,10.000),
(3,1,1,'2026-08-28 16:47:27','POS 1',1,-1.000),
(4,1,1,'2026-08-28 16:50:56','Manual Edit of Quantity',2,-10.000),
(5,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',1,80.000),
(6,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',2,0.000),
(7,1,1,'2026-08-28 16:54:53','POS 2',1,-1.000),
(8,1,1,'2026-08-28 16:57:10','POS 3',1,-1.000),
(9,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',1,100.000),
(10,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',2,0.000),
(11,3,1,'2026-08-28 17:57:35','RECV 1',1,6000.000),
(12,3,1,'2026-08-30 10:48:38','Manual Edit of Quantity',2,40.000),
(13,2,1,'2026-08-30 10:49:11','Manual Edit of Quantity',2,20.000),
(14,1,1,'2026-08-30 10:50:47','Manual Edit of Quantity',2,12.000),
(15,3,1,'2026-08-30 10:51:09','Manual Edit of Quantity',1,-5500.000),
(16,1,1,'2026-09-02 14:39:45','POS 4',2,-10.000),
(17,1,1,'2026-09-02 14:41:47','POS 5',1,5.000),
(18,1,1,'2026-09-02 14:44:04','POS 6',1,-5.000),
(19,2,1,'2026-09-02 15:42:27','POS 7',1,-1.000),
(20,1,1,'2026-09-03 10:29:18','',1,-10.000),
(21,1,1,'2026-09-03 10:29:28','Manual Edit of Quantity',1,-7.000),
(22,1,1,'2026-09-03 10:30:51','Manual Edit of Quantity',1,20.000),
(23,3,1,'2026-09-03 10:43:16','POS 8',1,-4.000),
(24,1,1,'2026-09-03 10:43:16','POS 8',1,-2.000),
(25,3,1,'2026-09-03 10:52:30','POS 9',1,-4.000),
(26,1,1,'2026-09-03 10:52:30','POS 9',1,-2.000),
(27,3,1,'2026-09-03 10:53:11','POS 10',1,-4.000),
(28,1,1,'2026-09-03 10:53:11','POS 10',1,-2.000),
(29,3,1,'2026-09-03 10:55:28','POS 11',1,-4.000),
(30,1,1,'2026-09-03 10:55:28','POS 11',1,-2.000),
(31,1,1,'2026-09-03 10:59:48','POS 12',1,-2.000),
(32,3,1,'2026-09-03 10:59:48','POS 12',1,-4.000),
(33,1,1,'2026-09-03 11:02:35','POS 13',1,-4.000),
(34,1,1,'2026-09-03 11:11:17','POS 14',2,-4.000),
(35,1,1,'2026-09-03 11:17:09','POS 15',1,-4.000),
(36,1,1,'2026-09-03 11:20:59','POS 16',1,-4.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
INSERT INTO `ospos_item_kit_items` VALUES
(1,1,4.000,2);
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
INSERT INTO `ospos_item_kits` VALUES
(1,'12321-123123-123123','Sprite | Pack of 4','This is the pack of the 4 sprint of 1.5L',0,0.00,0,0,0);
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,-2.000),
(1,2,-2.000),
(2,1,79.000),
(2,2,20.000),
(3,1,580.000),
(3,2,40.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Cock Half Leter','Beverage',2,'123','',20.00,20.00,1.000,200.000,1,NULL,1,1,0,0,0,NULL,1.000,'Each',1,''),
('Cock Leter','Beverage',2,NULL,'',80.00,0.00,1.000,4000.000,2,NULL,1,0,0,0,0,NULL,1.000,'Each',2,''),
('Sprite','Beverage',2,'12312-123123','',500.00,600.00,1.000,50.000,3,NULL,1,0,0,0,0,NULL,1.000,'Each',3,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1787915084,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1787915084,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1787915084,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1787915084,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1787915084,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1787915084,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1787915084,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1787915084,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1787915084,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1787915084,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1787915084,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1787915084,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1787915084,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1787915084,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1787915084,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1787915084,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1787915084,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1787915084,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1787915084,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1787915084,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1787915084,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1787915084,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1787915084,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1787915084,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1787915084,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1787915084,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1787915084,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1787915085,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1787915085,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1787915085,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1787915085,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1787915085,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1787915085,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1787915085,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1787915085,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1787915085,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1787915085,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1787915085,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1787915085,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1787915085,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1787915085,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1787915085,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1787915085,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1787915085,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1787915085,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('Usman','IlamDin',1,'+923014567595','usman65@gmail.com','Address 1','','','','','','',1),
('Alex','Alex',1,'','','','','','','','','',2),
('WalkIN','WalkIN',NULL,'','','','','','','','','',3);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_Shop','items',2),
('items_Warehouse','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_Shop','receivings',2),
('receivings_Warehouse','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_Shop','sales',2),
('sales_Warehouse','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
INSERT INTO `ospos_receivings` VALUES
('2026-08-28 17:57:35',2,1,'',1,'Cash','123123123');
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
INSERT INTO `ospos_receivings_items` VALUES
(1,3,'','',1,120.000,500.00,500.00,0.00,0,1,50.000);
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-08-28 16:47:27',NULL,1,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-08-28 16:54:53',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-08-28 16:57:10',NULL,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-02 14:39:45',3,1,'This is the final sale of the person\n\n','0',NULL,4,'Q26000001',0,NULL,1),
('2026-09-02 14:41:47',NULL,1,'',NULL,NULL,5,NULL,0,NULL,4),
('2026-09-02 14:44:04',3,1,'',NULL,NULL,6,NULL,0,NULL,0),
('2026-09-02 15:42:27',NULL,1,'',NULL,NULL,7,NULL,0,NULL,0),
('2026-09-03 10:43:16',NULL,1,'',NULL,NULL,8,NULL,0,NULL,0),
('2026-09-03 10:52:30',NULL,1,'',NULL,NULL,9,NULL,0,NULL,0),
('2026-09-03 10:53:11',NULL,1,'',NULL,NULL,10,NULL,0,NULL,0),
('2026-09-03 10:55:28',NULL,1,'',NULL,NULL,11,NULL,0,NULL,0),
('2026-09-03 10:59:48',NULL,1,'',NULL,NULL,12,NULL,0,NULL,0),
('2026-09-03 11:02:35',NULL,1,'',NULL,NULL,13,NULL,0,NULL,4),
('2026-09-03 11:11:17',NULL,1,'',NULL,NULL,14,NULL,0,NULL,0),
('2026-09-03 11:17:09',NULL,1,'',NULL,NULL,15,NULL,0,NULL,0),
('2026-09-03 11:20:59',NULL,1,'',NULL,NULL,16,NULL,0,NULL,0);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,1.000,0.00,0.00,0.00,0,1,0),
(2,1,'','',1,1.000,20.00,20.00,0.00,0,1,0),
(3,1,'','',2,1.000,20.00,20.00,0.00,0,1,0),
(4,1,'','',1,10.000,20.00,567.00,0.00,0,2,0),
(5,1,'','',1,-5.000,20.00,20.00,0.00,0,1,0),
(6,1,'','',1,5.000,20.00,10.00,0.00,0,1,0),
(7,2,'','',1,1.000,80.00,100.00,0.00,0,1,0),
(8,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(8,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(9,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(9,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(10,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(10,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(11,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(11,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(12,1,'','',1,2.000,20.00,20.00,10.00,0,1,0),
(12,3,'','',2,4.000,500.00,600.00,10.00,0,1,0),
(13,1,'','12321',1,4.000,20.00,20.00,10.00,0,1,0),
(14,1,'','',1,4.000,20.00,20.00,10.00,0,2,0),
(15,1,'This is the descriotion field','12321',1,4.000,20.00,20.00,0.00,0,1,0),
(16,1,'','',1,4.000,20.00,20.00,0.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,2,'Cash',20.00,0.00,0,1,'2026-08-28 11:54:53',''),
(2,3,'Cash',100.00,80.00,0,1,'2026-08-28 11:57:10',''),
(4,5,'Cash',-100.00,0.00,0,1,'2026-09-02 09:41:47',''),
(5,6,'Cash',50.00,0.00,0,1,'2026-09-02 09:44:04',''),
(6,7,'Cash',100.00,0.00,0,1,'2026-09-02 10:42:27',''),
(7,8,'Cash',2196.00,0.00,0,1,'2026-09-03 05:43:16',''),
(8,9,'Cash',2196.00,0.00,0,1,'2026-09-03 05:52:30',''),
(9,10,'Cash',2196.00,0.00,0,1,'2026-09-03 05:53:11',''),
(10,11,'Cash',2500.00,304.00,0,1,'2026-09-03 05:55:28',''),
(11,12,'Cash',2196.00,0.00,0,1,'2026-09-03 05:59:48',''),
(12,14,'Cash',72.00,0.00,0,1,'2026-09-03 06:11:17',''),
(13,15,'Cash',80.00,0.00,0,1,'2026-09-03 06:17:09',''),
(14,16,'Cash',80.00,0.00,0,1,'2026-09-03 06:20:59','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:01d4e59c21ce199691470efdcb49b92b','127.0.0.1','2026-09-03 06:00:41','__ci_last_regenerate|i:1788415241;csrf_ospos_v4|s:32:\"16d46aa83f4f3024b0f7e949a50ad6d9\";'),
('ospos_session:0210ae56a72f04f1548bfd90ee09e31f','127.0.0.1','2026-09-03 05:32:37','__ci_last_regenerate|i:1788413557;csrf_ospos_v4|s:32:\"4b67a9c0fbfcbbeb791e9a1ec2c53bb3\";'),
('ospos_session:07ab456009e1d71e0381f2bf1bacc758','127.0.0.1','2026-09-03 05:52:09','__ci_last_regenerate|i:1788414729;csrf_ospos_v4|s:32:\"a711ef312d98021e0be6189eb971fb00\";'),
('ospos_session:084156b801ef229f21284adc8601f6bf','127.0.0.1','2026-09-03 05:36:37','__ci_last_regenerate|i:1788413797;csrf_ospos_v4|s:32:\"a0d308d62a607b71fb534384700cc492\";'),
('ospos_session:09b18c8c7f44ad23e85bcb0674000d78','127.0.0.1','2026-09-03 05:21:35','__ci_last_regenerate|i:1788412895;csrf_ospos_v4|s:32:\"b852856d837f88a2e35b113d7514a8ac\";'),
('ospos_session:0c2f198a80646d3cbd08f8f3d41c54ac','127.0.0.1','2026-09-03 05:47:09','__ci_last_regenerate|i:1788414429;csrf_ospos_v4|s:32:\"884af71251fb5b54987a4d7889933659\";'),
('ospos_session:10ef79662ea091d17eed96c7c06c1a46','127.0.0.1','2026-09-03 06:08:11','__ci_last_regenerate|i:1788415691;csrf_ospos_v4|s:32:\"19370647d8984e0a775e20f4a5300f09\";'),
('ospos_session:1345800982a063125b95d9fd3382715c','127.0.0.1','2026-09-03 06:10:12','__ci_last_regenerate|i:1788415812;csrf_ospos_v4|s:32:\"1a115b179247d42ec05fec46acbfcfce\";'),
('ospos_session:13c1fbee02e9529b64e20793afc385b7','127.0.0.1','2026-09-03 06:18:13','__ci_last_regenerate|i:1788416293;csrf_ospos_v4|s:32:\"65557c664b4b6d1f8f9bbc5c8be00fd0\";'),
('ospos_session:14831d026a382c1888be1e8764c12517','127.0.0.1','2026-09-03 05:12:34','__ci_last_regenerate|i:1788412354;csrf_ospos_v4|s:32:\"f0580b75177f1fdeab0e2939bf3bf83e\";'),
('ospos_session:15e3263106f4a175cde5158c367c4c36','127.0.0.1','2026-09-03 05:35:07','__ci_last_regenerate|i:1788413707;csrf_ospos_v4|s:32:\"2aee31b13d4823c468ab9cf6fdc501e9\";'),
('ospos_session:16c5e8e4ec0a1aa562c76e55f26035c5','127.0.0.1','2026-09-03 05:08:03','__ci_last_regenerate|i:1788412083;csrf_ospos_v4|s:32:\"7f3baf1f7b5edc74a264b32cf48cd601\";'),
('ospos_session:17acc9e93bfe6af1483f42a4266668d7','127.0.0.1','2026-09-03 05:51:09','__ci_last_regenerate|i:1788414669;csrf_ospos_v4|s:32:\"425f26c61741935c4d1d58f88b90059d\";'),
('ospos_session:19f050f47b7e0dc6cd1c5028a00b273d','127.0.0.1','2026-09-03 05:07:33','__ci_last_regenerate|i:1788412053;csrf_ospos_v4|s:32:\"0d073768d9602acbe66acbc3faacb8a7\";'),
('ospos_session:1a11f1a9432c1aea3737d7e2543d0afe','127.0.0.1','2026-09-03 05:55:40','__ci_last_regenerate|i:1788414940;csrf_ospos_v4|s:32:\"136da067c60240e82d7a9706b3d8f90d\";'),
('ospos_session:1aac25d15fbb3ce04e208ce2483347ef','127.0.0.1','2026-09-03 05:21:05','__ci_last_regenerate|i:1788412865;csrf_ospos_v4|s:32:\"5c5bf77a0867f686d359c7edea8504c8\";'),
('ospos_session:1abe79df245dbd0a6379f09effd93cdd','127.0.0.1','2026-09-03 05:33:37','__ci_last_regenerate|i:1788413617;csrf_ospos_v4|s:32:\"a9f29853b97fba684b4840719030e709\";'),
('ospos_session:1b3a390c4775a1855d8fe2c3928284a8','127.0.0.1','2026-09-03 05:23:05','__ci_last_regenerate|i:1788412985;csrf_ospos_v4|s:32:\"cc1092cdfb134cd7071770e9f5fc55b3\";'),
('ospos_session:216527abbcae67786eb414e21e078a79','127.0.0.1','2026-09-03 05:01:02','__ci_last_regenerate|i:1788411662;csrf_ospos_v4|s:32:\"4ffdde3f0efe7ef8f3ac8b6a3ee85d40\";'),
('ospos_session:22a6cf6c0af71757c9ff18c2f2fea006','127.0.0.1','2026-09-03 05:50:09','__ci_last_regenerate|i:1788414609;csrf_ospos_v4|s:32:\"fef00709a23c981c4f3640f54ef5e8d3\";'),
('ospos_session:231bb29b724938a2d3befe77b1acc363','127.0.0.1','2026-09-03 05:04:33','__ci_last_regenerate|i:1788411873;csrf_ospos_v4|s:32:\"5a3615add58e4ce3d154bc4147beddc1\";'),
('ospos_session:25884d43294888b2f25f3e94211db262','127.0.0.1','2026-09-03 05:39:08','__ci_last_regenerate|i:1788413948;csrf_ospos_v4|s:32:\"57cdf26b4b3c5956fbbd96330b422d5b\";'),
('ospos_session:2620df72493a909612f2abc7d63123fd','127.0.0.1','2026-09-03 05:24:36','__ci_last_regenerate|i:1788413076;csrf_ospos_v4|s:32:\"2b3bbac100f2ffee0695dc8f9a0a7a48\";'),
('ospos_session:2b5024254e4334b754eac8049790c78c','127.0.0.1','2026-09-03 05:50:39','__ci_last_regenerate|i:1788414639;csrf_ospos_v4|s:32:\"db11699d2aa4fc63d6fe5e12e9aec467\";'),
('ospos_session:2c3c56c98cf92748bae13c1083b4c38e','127.0.0.1','2026-09-03 06:15:42','__ci_last_regenerate|i:1788416142;csrf_ospos_v4|s:32:\"7ae16f50e07d23efa6b6e14310a77d30\";'),
('ospos_session:2c693b25dca4b803bd2fd62f2b329d7f','127.0.0.1','2026-09-03 05:03:33','__ci_last_regenerate|i:1788411813;csrf_ospos_v4|s:32:\"83359179cf7343601bb6511c63d693b0\";'),
('ospos_session:2dbd2a49a51881b84991ef73791be63d','127.0.0.1','2026-09-03 06:21:13','__ci_last_regenerate|i:1788416473;csrf_ospos_v4|s:32:\"1a50adac351cb81e8216fe88cb5cd805\";'),
('ospos_session:2dea69aa2cdf6b89fb130da02f255503','127.0.0.1','2026-09-03 05:31:07','__ci_last_regenerate|i:1788413467;csrf_ospos_v4|s:32:\"77fd2775454b6f7e4bbcec0ed1ef693a\";'),
('ospos_session:2e10c0a42c2b1d175c7078d10f16b496','127.0.0.1','2026-09-03 05:29:06','__ci_last_regenerate|i:1788413346;csrf_ospos_v4|s:32:\"21878ef9b5900927f703cf08cf1c62df\";'),
('ospos_session:309bee9bb35d7787c1505c30d32b1828','127.0.0.1','2026-09-03 06:12:42','__ci_last_regenerate|i:1788415962;csrf_ospos_v4|s:32:\"300dcb735fb3d1a8fe00d699a89ae65c\";'),
('ospos_session:312fd5a228187581f1e997476d0af6de','127.0.0.1','2026-09-03 05:26:36','__ci_last_regenerate|i:1788413196;csrf_ospos_v4|s:32:\"84f2a23e34db1563ff8f6d08e43c9d4b\";'),
('ospos_session:330aee6424488d677b1d31d662a5fe09','127.0.0.1','2026-09-03 05:23:35','__ci_last_regenerate|i:1788413015;csrf_ospos_v4|s:32:\"726955d09c5ad188b73d2df9be654b44\";'),
('ospos_session:332af309db4ed7c54e8fe50a244ede26','127.0.0.1','2026-09-03 05:32:07','__ci_last_regenerate|i:1788413527;csrf_ospos_v4|s:32:\"93c663d7cbead6fc6621e11da0effdba\";'),
('ospos_session:33a4f96ca654d8ecc66fdcd9d11bfa3e','127.0.0.1','2026-09-03 05:31:37','__ci_last_regenerate|i:1788413497;csrf_ospos_v4|s:32:\"8d6c2cc798035557c9124a6aec2dfc9c\";'),
('ospos_session:3423970308e6bdc598acc98fb7ff5a2d','127.0.0.1','2026-09-03 05:51:39','__ci_last_regenerate|i:1788414699;csrf_ospos_v4|s:32:\"4e82d4e37d1e17b04244213d784ee34c\";'),
('ospos_session:38f24381ce340474411d32d7fadc962b','127.0.0.1','2026-09-03 06:02:41','__ci_last_regenerate|i:1788415361;csrf_ospos_v4|s:32:\"f9eb6e8191c8d60a2bbb61922c0834db\";'),
('ospos_session:3930fe8910aba2a63d5230cdc1a52ab8','127.0.0.1','2026-09-03 05:34:37','__ci_last_regenerate|i:1788413677;csrf_ospos_v4|s:32:\"e55df14671feacfc4eff9b2684167635\";'),
('ospos_session:395c662fb1475c1b8df54b0e071a1365','127.0.0.1','2026-09-03 05:16:34','__ci_last_regenerate|i:1788412594;csrf_ospos_v4|s:32:\"c304f0da947c76b5a12e40cc40d3280e\";'),
('ospos_session:3dd0f5053ec8289b92ab4adcb8ae7afa','127.0.0.1','2026-09-03 05:45:09','__ci_last_regenerate|i:1788414309;csrf_ospos_v4|s:32:\"c79725588abafd65d383bbdfbfaf04ba\";'),
('ospos_session:3ee2a7c0d6b69fbf844d1c2659f44b91','127.0.0.1','2026-09-03 06:12:12','__ci_last_regenerate|i:1788415932;csrf_ospos_v4|s:32:\"72923c9c4ff42b97b98783c14e31c6fd\";'),
('ospos_session:40638c49efebb07a28463c4f3e9419a7','127.0.0.1','2026-09-03 05:11:04','__ci_last_regenerate|i:1788412264;csrf_ospos_v4|s:32:\"d88f7ca74831a24640bfe4db40f4eff5\";'),
('ospos_session:417120f6cab3455d223f3d359a347953','127.0.0.1','2026-09-03 06:22:43','__ci_last_regenerate|i:1788416563;csrf_ospos_v4|s:32:\"db108c15b45655a8cbae3314fbdb2623\";'),
('ospos_session:431291143d2faacf8e35421db9e46746','127.0.0.1','2026-09-03 06:09:42','__ci_last_regenerate|i:1788415782;csrf_ospos_v4|s:32:\"cf8655e8b00103fd4f1c98568ab018d7\";'),
('ospos_session:4421db44c68f529cbaf0ff70f7900416','127.0.0.1','2026-09-03 05:55:10','__ci_last_regenerate|i:1788414910;csrf_ospos_v4|s:32:\"35aa7956afdc831b47e354d6cadce6b6\";'),
('ospos_session:44ab4325c96d92141ebfb7ab8d034fdc','172.22.0.2','2026-09-03 05:01:14','__ci_last_regenerate|i:1788411642;csrf_ospos_v4|s:32:\"5b92b42cee07c6951f3b4fc1b91550d0\";_ci_previous_url|s:29:\"https://ghazi-pos.local/login\";'),
('ospos_session:452d4fe46e2e60af2d2ba0727dcd8b00','127.0.0.1','2026-09-03 05:27:36','__ci_last_regenerate|i:1788413256;csrf_ospos_v4|s:32:\"daf874ad568881d6c4e0e3323d4c3939\";'),
('ospos_session:4693d4f1e34db23ed2414a5d22ea4232','127.0.0.1','2026-09-03 05:01:33','__ci_last_regenerate|i:1788411693;csrf_ospos_v4|s:32:\"418a05b3ed6cc19e53c4a6cf24325f09\";'),
('ospos_session:473eed04fa3360c11d8260c0ca85ba06','127.0.0.1','2026-09-03 06:16:12','__ci_last_regenerate|i:1788416172;csrf_ospos_v4|s:32:\"05bef18968f8c66f7997d8f45de8f67a\";'),
('ospos_session:4c1a9d09e3a5f88391a28b47c24b0a08','127.0.0.1','2026-09-03 05:06:03','__ci_last_regenerate|i:1788411963;csrf_ospos_v4|s:32:\"4d4c4bc3f00cec1235d3dd440e2510ef\";'),
('ospos_session:4de66998cb88c7810d8c408df23f5d96','127.0.0.1','2026-09-03 05:10:04','__ci_last_regenerate|i:1788412204;csrf_ospos_v4|s:32:\"37620e36b89701e28cb62cb830a06f6f\";'),
('ospos_session:4e6a3adc8c499af01e3482f84ded77c8','127.0.0.1','2026-09-03 05:46:09','__ci_last_regenerate|i:1788414369;csrf_ospos_v4|s:32:\"9bd290e811687a038dabce3d326e6426\";'),
('ospos_session:5119b3ebbf24056031f5d0cf4818c4b0','127.0.0.1','2026-09-03 05:48:39','__ci_last_regenerate|i:1788414519;csrf_ospos_v4|s:32:\"fd597a7c523adfa6836c533d9d1cd17e\";'),
('ospos_session:52b37ffd0961e7722123a8c4d5bdc0bd','127.0.0.1','2026-09-03 05:42:08','__ci_last_regenerate|i:1788414128;csrf_ospos_v4|s:32:\"ed4c2f845995c7353ec42e252c3043d9\";'),
('ospos_session:530f465ad0e5b3d9550d4bd6705d7639','127.0.0.1','2026-09-03 05:12:04','__ci_last_regenerate|i:1788412324;csrf_ospos_v4|s:32:\"b6cc7891544bd6af97922ac55f42b582\";'),
('ospos_session:53a3d43baedcbb9f04d16c181e716c9a','127.0.0.1','2026-09-03 06:03:41','__ci_last_regenerate|i:1788415421;csrf_ospos_v4|s:32:\"d8a37b6486d5840df18b5de62c9f2a09\";'),
('ospos_session:55602c05fd8cb75ee8bb10b539c98125','127.0.0.1','2026-09-03 05:05:03','__ci_last_regenerate|i:1788411903;csrf_ospos_v4|s:32:\"09d205997d0cf94edd2e9b69a89d3636\";'),
('ospos_session:5aa84aaadec569ce44048248ffce11df','127.0.0.1','2026-09-03 05:48:09','__ci_last_regenerate|i:1788414489;csrf_ospos_v4|s:32:\"b19344e60dd6f3e2f28121604db83edf\";'),
('ospos_session:5d50a1aabb9438258f98ef39ff9c862e','127.0.0.1','2026-09-03 05:53:40','__ci_last_regenerate|i:1788414820;csrf_ospos_v4|s:32:\"14893552b4c7df3dd537e85143f4e095\";'),
('ospos_session:5e6af7e2ce057ca8075bbc71a6e97d18','127.0.0.1','2026-09-03 05:59:10','__ci_last_regenerate|i:1788415150;csrf_ospos_v4|s:32:\"b1a616574fed604a7b3b9b2dd6db578c\";'),
('ospos_session:6206bf12f99f762d22641006992f780f','127.0.0.1','2026-09-03 05:00:32','__ci_last_regenerate|i:1788411632;csrf_ospos_v4|s:32:\"7f0febe3cc76d08b4b768b9a9a22e7eb\";'),
('ospos_session:6279fac9df16bf206c9bd5125cf28bf9','127.0.0.1','2026-09-03 05:08:33','__ci_last_regenerate|i:1788412113;csrf_ospos_v4|s:32:\"5ae8ef523b0310d5724735bd0434cc56\";'),
('ospos_session:6457041438524dac96f67136acec1874','127.0.0.1','2026-09-03 05:54:10','__ci_last_regenerate|i:1788414850;csrf_ospos_v4|s:32:\"0641c9489933d60e2763b21bdf03cb26\";'),
('ospos_session:650cd458c9722471536d568c60522692','127.0.0.1','2026-09-03 06:08:42','__ci_last_regenerate|i:1788415722;csrf_ospos_v4|s:32:\"8f5b6581c11a2f6c3a9ce2517e65887f\";'),
('ospos_session:66a7d773c2db7e685db247e81501ac39','127.0.0.1','2026-09-03 06:13:42','__ci_last_regenerate|i:1788416022;csrf_ospos_v4|s:32:\"5d0f8f42a5e24a09077ec99aaf4a43fa\";'),
('ospos_session:66af019c9b6bd133997e3daf9bbfaa60','127.0.0.1','2026-09-03 06:10:42','__ci_last_regenerate|i:1788415842;csrf_ospos_v4|s:32:\"ad5b64917dd0c5ef38d61906fcd9b9cb\";'),
('ospos_session:69df34ce4d0990746073a8e52d64f6c3','127.0.0.1','2026-09-03 05:28:36','__ci_last_regenerate|i:1788413316;csrf_ospos_v4|s:32:\"84b5a18634c54b898b2e46857e986674\";'),
('ospos_session:69e4328bc7d686d1350705a8ec435659','127.0.0.1','2026-09-03 06:14:42','__ci_last_regenerate|i:1788416082;csrf_ospos_v4|s:32:\"29ed87452a9631f58ef43c742ed7047a\";'),
('ospos_session:6bfa77af4552c5da973850c4ff0d9b5d','127.0.0.1','2026-09-03 05:15:34','__ci_last_regenerate|i:1788412534;csrf_ospos_v4|s:32:\"0d3c295bc6dcc5c1a5c9d97a1373d763\";'),
('ospos_session:703f134b14284126b5e50557a74e3efe','127.0.0.1','2026-09-03 06:05:41','__ci_last_regenerate|i:1788415541;csrf_ospos_v4|s:32:\"9dfb64d4f8c603d9779b37ee19d2c955\";'),
('ospos_session:70fd2e71b28e885bb1ca247ece53436d','127.0.0.1','2026-09-03 05:43:08','__ci_last_regenerate|i:1788414188;csrf_ospos_v4|s:32:\"e4921612d0b310a1fd91ebeb199a756c\";'),
('ospos_session:73c1b0bdb984969a484549c3d25a2c43','127.0.0.1','2026-09-03 05:02:03','__ci_last_regenerate|i:1788411723;csrf_ospos_v4|s:32:\"863fc6f734bbfc122f21ddee53b36788\";'),
('ospos_session:7456d4a1545aff42b11b90200b92e654','127.0.0.1','2026-09-03 05:38:38','__ci_last_regenerate|i:1788413918;csrf_ospos_v4|s:32:\"1265cd597aaaf6ef671b033db4adb5e8\";'),
('ospos_session:7810719c3a9c946ba826c079eca37c1e','127.0.0.1','2026-09-03 05:52:40','__ci_last_regenerate|i:1788414760;csrf_ospos_v4|s:32:\"a6111f4e888cfdb67090e76f75274c1d\";'),
('ospos_session:78ef2e8a47c4a8616ee7afd7f2f9b826','127.0.0.1','2026-09-03 05:02:33','__ci_last_regenerate|i:1788411753;csrf_ospos_v4|s:32:\"7813a6b9158d33999ffb832ae794085f\";'),
('ospos_session:7a7d01f528a2da91771080428259e92d','127.0.0.1','2026-09-03 05:27:06','__ci_last_regenerate|i:1788413226;csrf_ospos_v4|s:32:\"e7c265d3ce702c412a31f81834bf2975\";'),
('ospos_session:7dae1d6ef3746ab8e78093e85e4c4952','127.0.0.1','2026-09-03 05:54:40','__ci_last_regenerate|i:1788414880;csrf_ospos_v4|s:32:\"314f841d0f990dd14a2065c3c8ee30b6\";'),
('ospos_session:7e29ad284e5cc184d4ad525ebefb9df8','127.0.0.1','2026-09-03 06:04:11','__ci_last_regenerate|i:1788415451;csrf_ospos_v4|s:32:\"4c1200476dfa605d72950951b1bb0e4c\";'),
('ospos_session:8197fe0573ef86867db4bfb4bf760c4c','127.0.0.1','2026-09-03 06:20:13','__ci_last_regenerate|i:1788416413;csrf_ospos_v4|s:32:\"08790e42261b95d709bcd77f99468409\";'),
('ospos_session:84f39629af734ef4285c9080858398e4','127.0.0.1','2026-09-03 05:25:36','__ci_last_regenerate|i:1788413136;csrf_ospos_v4|s:32:\"daeb99b899784dfb3185bdb11015358d\";'),
('ospos_session:85daf32e83422add1c8e968e943ce26d','127.0.0.1','2026-09-03 06:01:41','__ci_last_regenerate|i:1788415301;csrf_ospos_v4|s:32:\"bf29f609577dd9dee3aea7222781fca7\";'),
('ospos_session:86af6171339a20407ccd906c2a79eaa5','127.0.0.1','2026-09-03 05:57:10','__ci_last_regenerate|i:1788415030;csrf_ospos_v4|s:32:\"fb7b490ed8a1e924e3086c700d441d66\";'),
('ospos_session:86e1d517df7fd4f5728720202064b892','127.0.0.1','2026-09-03 05:18:35','__ci_last_regenerate|i:1788412715;csrf_ospos_v4|s:32:\"d0b349c24aebe51ec230e6576530f39a\";'),
('ospos_session:8a8256e90b80b487e29b5ad9d4851451','127.0.0.1','2026-09-03 06:19:43','__ci_last_regenerate|i:1788416383;csrf_ospos_v4|s:32:\"d81bd22ddebf72ca46e87e1f25917d77\";'),
('ospos_session:8bb73004a865f506e88d31692e28d6f5','127.0.0.1','2026-09-03 05:13:04','__ci_last_regenerate|i:1788412384;csrf_ospos_v4|s:32:\"90e88d4aa89dc843d95450f2069f6600\";'),
('ospos_session:8ea60d5574691d75ef61b94cdf20943b','127.0.0.1','2026-09-03 06:03:11','__ci_last_regenerate|i:1788415391;csrf_ospos_v4|s:32:\"dd87f9baca81413e146d57a3f4866ef3\";'),
('ospos_session:90c427f9a524a34bf4c1a9c804d10923','127.0.0.1','2026-09-03 05:04:03','__ci_last_regenerate|i:1788411843;csrf_ospos_v4|s:32:\"7207978519200418d43a9e34a07b02cf\";'),
('ospos_session:90fbafded8c8d4fe7c97210d2bcf33e5','127.0.0.1','2026-09-03 05:36:07','__ci_last_regenerate|i:1788413767;csrf_ospos_v4|s:32:\"a4cad07dc554a0347aea7adf33a30a7f\";'),
('ospos_session:925c7433f91af44efe22346fc5dd8e06','127.0.0.1','2026-09-03 05:59:40','__ci_last_regenerate|i:1788415180;csrf_ospos_v4|s:32:\"92ae53af5e77cf7a02848b9ee8cfcde0\";'),
('ospos_session:95f70851ca285835bc84576b846e614a','127.0.0.1','2026-09-03 05:46:39','__ci_last_regenerate|i:1788414399;csrf_ospos_v4|s:32:\"b7a7a740082179bdc6a3808d096b5ed6\";'),
('ospos_session:96d13336458360bad956289be0b07139','127.0.0.1','2026-09-03 05:45:39','__ci_last_regenerate|i:1788414339;csrf_ospos_v4|s:32:\"3f92e40e454f17e6c49af1daa0d71f0c\";'),
('ospos_session:9769016ae7baf3a0ed581e09af684987','127.0.0.1','2026-09-03 05:13:34','__ci_last_regenerate|i:1788412414;csrf_ospos_v4|s:32:\"18220976aaf469fbbc6fd6daff57e191\";'),
('ospos_session:99cddb633473afba62ae67c438b6b661','127.0.0.1','2026-09-03 05:57:40','__ci_last_regenerate|i:1788415060;csrf_ospos_v4|s:32:\"31a08367dc8652831b3613ceb7e12c9c\";'),
('ospos_session:9a0ead0cf714a1d4fde36da315d2d55a','127.0.0.1','2026-09-03 06:05:11','__ci_last_regenerate|i:1788415511;csrf_ospos_v4|s:32:\"8e73117d4850adfd4b980ea790a99118\";'),
('ospos_session:9af6094a33ba7e20480cb5573f671b57','127.0.0.1','2026-09-03 06:17:43','__ci_last_regenerate|i:1788416263;csrf_ospos_v4|s:32:\"0c26addde1172eeb577c5d1a2bba8f63\";'),
('ospos_session:9fdc2e5fc5143c45b7b035ea19479b38','127.0.0.1','2026-09-03 06:07:11','__ci_last_regenerate|i:1788415631;csrf_ospos_v4|s:32:\"5e336030aab876efc0bb74eb9e1a301b\";'),
('ospos_session:a183ec4e6ecca4604d19d52c025fb079','127.0.0.1','2026-09-03 05:30:36','__ci_last_regenerate|i:1788413436;csrf_ospos_v4|s:32:\"8fa9d47bb5addad75e6fb1b3027a31a7\";'),
('ospos_session:a312c3bb59ba743ba8abd369f01c3c2d','127.0.0.1','2026-09-03 05:06:33','__ci_last_regenerate|i:1788411993;csrf_ospos_v4|s:32:\"935a94cd2877eef4541faeccd469d473\";'),
('ospos_session:a33dc74cb88d3298731f5bdb023f851e','127.0.0.1','2026-09-03 05:30:06','__ci_last_regenerate|i:1788413406;csrf_ospos_v4|s:32:\"0d71c9aaea229d3ebc86c2fb91e8be46\";'),
('ospos_session:a417d5c0c9c44658918b76de3531adf7','127.0.0.1','2026-09-03 05:19:05','__ci_last_regenerate|i:1788412745;csrf_ospos_v4|s:32:\"0ac52326c6be346908f73756951349e5\";'),
('ospos_session:a4dddf0cb114c4e880b5aff139c81206','127.0.0.1','2026-09-03 05:14:04','__ci_last_regenerate|i:1788412444;csrf_ospos_v4|s:32:\"9c65e782c5b33648ae4659b11e91d457\";'),
('ospos_session:a57f4002ad3cc79f9e89311a216e6a17','127.0.0.1','2026-09-03 06:22:13','__ci_last_regenerate|i:1788416533;csrf_ospos_v4|s:32:\"76aaefb20cb763da0d440400ff642b36\";'),
('ospos_session:a786ea76fbcb8ad948b1c0e866318d38','127.0.0.1','2026-09-03 06:20:43','__ci_last_regenerate|i:1788416443;csrf_ospos_v4|s:32:\"d7241131707e6b160df6c96bfcedef14\";'),
('ospos_session:aa3c23178be009c21bfa8682a9a4dca5','172.22.0.2','2026-09-03 06:21:44','__ci_last_regenerate|i:1788416302;csrf_ospos_v4|s:32:\"f349e14340729fc5e5349665253623ae\";_ci_previous_url|s:33:\"https://ghazi-pos.local/customers\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:1;item_location|s:1:\"1\";sale_id|i:-1;sales_location|i:1;sales_employee|i:1;cash_adjustment_amount|d:0;recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_stock_source|i:1;recv_stock_destination|s:1:\"1\";recv_supplier|i:-1;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:0:{}sales_customer|i:-1;sales_mode|s:4:\"sale\";sales_payments|a:0:{}'),
('ospos_session:ad61874b4330821a10ec1445d4182bb1','127.0.0.1','2026-09-03 06:02:11','__ci_last_regenerate|i:1788415331;csrf_ospos_v4|s:32:\"c0e195cc8da7d770a0c2925d2d3bb458\";'),
('ospos_session:ae805a9b0a5ca01bacc33c9a9362c1a7','127.0.0.1','2026-09-03 05:44:08','__ci_last_regenerate|i:1788414248;csrf_ospos_v4|s:32:\"5aa23db53c7c4f3922af047b3148eab3\";'),
('ospos_session:aff0695d372b9a82cd10119e8cf928b6','127.0.0.1','2026-09-03 05:18:05','__ci_last_regenerate|i:1788412685;csrf_ospos_v4|s:32:\"a3fa215d2449123e8260ea4bb5aae1d8\";'),
('ospos_session:b10b194a09b1c0df118e6f0b525019e4','127.0.0.1','2026-09-03 06:11:42','__ci_last_regenerate|i:1788415902;csrf_ospos_v4|s:32:\"a2e1a70a30f54d618f621da4012b9f00\";'),
('ospos_session:b4c166fef4b4b4ab0b8c0e63f54a7085','127.0.0.1','2026-09-03 05:19:35','__ci_last_regenerate|i:1788412775;csrf_ospos_v4|s:32:\"ca8c62cf2b70d50d1b7e4b7418d0cbb4\";'),
('ospos_session:b4e3066e13e57bfe3598126bb643d668','127.0.0.1','2026-09-03 05:44:38','__ci_last_regenerate|i:1788414278;csrf_ospos_v4|s:32:\"0ba945ab37dca2a60ecdf678429bf4d6\";'),
('ospos_session:b623c84f36b02a8eed6790f9a0924255','127.0.0.1','2026-09-03 05:35:37','__ci_last_regenerate|i:1788413737;csrf_ospos_v4|s:32:\"926db9de575635c10ac3f5040bacfa38\";'),
('ospos_session:b7ef38449db8e46084d8418604af03db','127.0.0.1','2026-09-03 05:56:10','__ci_last_regenerate|i:1788414970;csrf_ospos_v4|s:32:\"53991883a5520f288e2a3fdef57d97f0\";'),
('ospos_session:ba3da69c81f0947d6979834431bad500','127.0.0.1','2026-09-03 05:09:34','__ci_last_regenerate|i:1788412174;csrf_ospos_v4|s:32:\"e5c750b99a19069a0843a9802388e18d\";'),
('ospos_session:bb35f1bd57da5a9cbdb00e3120bdfd7c','127.0.0.1','2026-09-03 06:13:12','__ci_last_regenerate|i:1788415992;csrf_ospos_v4|s:32:\"d921877efe7fc0e5b5fb7098b77811dc\";'),
('ospos_session:bb8473483fc3788f261502acf4b6b090','127.0.0.1','2026-09-03 05:58:40','__ci_last_regenerate|i:1788415120;csrf_ospos_v4|s:32:\"31933afb6cce8f415f26f3c80018642b\";'),
('ospos_session:bbdb937cd2fed598b1b123056accee2e','127.0.0.1','2026-09-03 05:38:08','__ci_last_regenerate|i:1788413888;csrf_ospos_v4|s:32:\"8b5642cd74111d79beff31938f7c74ee\";'),
('ospos_session:c07cddd6f9395a2f0841daaeeb4687c9','127.0.0.1','2026-09-03 05:17:04','__ci_last_regenerate|i:1788412624;csrf_ospos_v4|s:32:\"8cf15e57b262e45315d983ad34b21cfd\";'),
('ospos_session:c477233701e80ff73f432d2df0c226f6','127.0.0.1','2026-09-03 05:29:36','__ci_last_regenerate|i:1788413376;csrf_ospos_v4|s:32:\"047caf4801d3621accbf6e4fc00b7ab6\";'),
('ospos_session:c59bdc6d833d839fa02a7cb5ca81491b','127.0.0.1','2026-09-03 05:15:04','__ci_last_regenerate|i:1788412504;csrf_ospos_v4|s:32:\"af709a92c4d5e4d718746e908bc1348c\";'),
('ospos_session:c5cfe723e3e7fc352bd5b6a2803260cf','127.0.0.1','2026-09-03 05:05:33','__ci_last_regenerate|i:1788411933;csrf_ospos_v4|s:32:\"831840cea8ffdcf95e0f9c676075bdb3\";'),
('ospos_session:c65ceb350073922f3533ef7e160ea2f4','127.0.0.1','2026-09-03 05:22:05','__ci_last_regenerate|i:1788412925;csrf_ospos_v4|s:32:\"2ad8854275c7ff8e047494d7154a5505\";'),
('ospos_session:c881b9e8703c9cbedeeb521a05c78907','127.0.0.1','2026-09-03 06:06:41','__ci_last_regenerate|i:1788415601;csrf_ospos_v4|s:32:\"f012e6d289dd8a1a64ad96f8c40eed2a\";'),
('ospos_session:c8d50a4450f5c8201d3af77b5c470261','127.0.0.1','2026-09-03 06:11:12','__ci_last_regenerate|i:1788415872;csrf_ospos_v4|s:32:\"5d04755ec6c56c79b7cf248df1429fc2\";'),
('ospos_session:c8f4f63212cb455bf624a84e28ccc868','127.0.0.1','2026-09-03 05:07:03','__ci_last_regenerate|i:1788412023;csrf_ospos_v4|s:32:\"f5841d1bd7bff44e85e884a3cb97a5e6\";'),
('ospos_session:c98695299eeebf1e93424ecda21817b7','127.0.0.1','2026-09-03 05:41:38','__ci_last_regenerate|i:1788414098;csrf_ospos_v4|s:32:\"b5723cceecdf9b0f20e0d2c876cb4680\";'),
('ospos_session:cbd8b42f9abc02b022b41bd21099b3eb','127.0.0.1','2026-09-03 06:19:13','__ci_last_regenerate|i:1788416353;csrf_ospos_v4|s:32:\"142714532ff9e5246faffebecfc46c4f\";'),
('ospos_session:cc9643f3eaf86ff924cb4c20e7a1cb20','127.0.0.1','2026-09-03 05:49:09','__ci_last_regenerate|i:1788414549;csrf_ospos_v4|s:32:\"3550d79bbe978c6d86c55b9bcb20aec4\";'),
('ospos_session:ce3d58dbdd48408fd3cfbc1c371862af','127.0.0.1','2026-09-03 05:56:40','__ci_last_regenerate|i:1788415000;csrf_ospos_v4|s:32:\"80da36d2a52927e5733d4aae1d5517e1\";'),
('ospos_session:d11a1cc25cb7a690299055da796c06ab','127.0.0.1','2026-09-03 05:43:38','__ci_last_regenerate|i:1788414218;csrf_ospos_v4|s:32:\"fba06492402df37e2d6e7691e6f0d9e2\";'),
('ospos_session:d18e73c96d2d8ee0403e3bd3f27ae129','127.0.0.1','2026-09-03 06:09:12','__ci_last_regenerate|i:1788415752;csrf_ospos_v4|s:32:\"bb11bf3e4c21bf0556e887aef6af2f2a\";'),
('ospos_session:d1c90a0ebeb8e275a7e983c5a7253b25','127.0.0.1','2026-09-03 05:34:07','__ci_last_regenerate|i:1788413647;csrf_ospos_v4|s:32:\"2e0742eef889896438b5bed6ccc5285f\";'),
('ospos_session:d2035b15a1803b09f33714ee0ac8f2df','127.0.0.1','2026-09-03 05:47:39','__ci_last_regenerate|i:1788414459;csrf_ospos_v4|s:32:\"0f587f0f36714d78bcd7aaddf3056447\";'),
('ospos_session:d20b6a349fdf700818722609f86f70d9','127.0.0.1','2026-09-03 06:07:41','__ci_last_regenerate|i:1788415661;csrf_ospos_v4|s:32:\"c0da9df96cbd863efa77baac71b1192e\";'),
('ospos_session:d2136531de09c80cb84270c03b24fbfe','127.0.0.1','2026-09-03 05:58:10','__ci_last_regenerate|i:1788415090;csrf_ospos_v4|s:32:\"b91a644d60b371e62589b23d17b6bc08\";'),
('ospos_session:d2ad505e36dd03479cc55f44fa945a78','127.0.0.1','2026-09-03 05:42:38','__ci_last_regenerate|i:1788414158;csrf_ospos_v4|s:32:\"d58684ea054dfa8e1ba942ac441dd645\";'),
('ospos_session:d52a95b1175a12d817a8f29a72ba5f53','127.0.0.1','2026-09-03 06:00:11','__ci_last_regenerate|i:1788415211;csrf_ospos_v4|s:32:\"44dad6afc1b265e34fb9b981aa75717e\";'),
('ospos_session:dc39466995b42016eeda219207b450c6','127.0.0.1','2026-09-03 05:22:35','__ci_last_regenerate|i:1788412955;csrf_ospos_v4|s:32:\"6c41a77f79ab5162099567f467f50578\";'),
('ospos_session:dc6a617a3fdee0a9374818174e0db512','127.0.0.1','2026-09-03 05:37:07','__ci_last_regenerate|i:1788413827;csrf_ospos_v4|s:32:\"0b2986dbf4c860fba822947347b2cabd\";'),
('ospos_session:dccfd4a545bb67b7e1fd4c6f600b82a8','127.0.0.1','2026-09-03 05:10:34','__ci_last_regenerate|i:1788412234;csrf_ospos_v4|s:32:\"75282b40e5de3801263302a335b696d0\";'),
('ospos_session:dcd7e834565d2a53ee90ca7c03ac47fc','127.0.0.1','2026-09-03 06:15:12','__ci_last_regenerate|i:1788416112;csrf_ospos_v4|s:32:\"f052c9f6f6c355aba25e9d5c0f2adfe2\";'),
('ospos_session:dd46e67002c8dfde939284bc9de9d392','127.0.0.1','2026-09-03 05:33:07','__ci_last_regenerate|i:1788413587;csrf_ospos_v4|s:32:\"cbe5576838e57927874dbaf29b1cbd3f\";'),
('ospos_session:ded6148a9311057de0af370151219700','127.0.0.1','2026-09-03 05:11:34','__ci_last_regenerate|i:1788412294;csrf_ospos_v4|s:32:\"3af0df23c84b5200574fb786593217ea\";'),
('ospos_session:df8b2d273f9f96cad17fe5e9e9e239d8','127.0.0.1','2026-09-03 05:49:39','__ci_last_regenerate|i:1788414579;csrf_ospos_v4|s:32:\"d55d6fdf2611d2110b026ef0676c9146\";'),
('ospos_session:e0513aada30c8a60fea949ea86795226','127.0.0.1','2026-09-03 05:03:03','__ci_last_regenerate|i:1788411783;csrf_ospos_v4|s:32:\"e7192bbb10e59fcac022b6c977c38f44\";'),
('ospos_session:e0a4993304cfac293f91c5ccdb574f8b','127.0.0.1','2026-09-03 05:17:35','__ci_last_regenerate|i:1788412655;csrf_ospos_v4|s:32:\"6bb476d8fca7ea3dbf0a53dcb046a00e\";'),
('ospos_session:e0c31d4001208cff16181db4776c6a59','127.0.0.1','2026-09-03 06:16:43','__ci_last_regenerate|i:1788416203;csrf_ospos_v4|s:32:\"3b03b074b8476420efee43d93516b536\";'),
('ospos_session:e2172e3d612e0731232620bcfc16c1f9','127.0.0.1','2026-09-03 05:41:08','__ci_last_regenerate|i:1788414068;csrf_ospos_v4|s:32:\"84a20c684f4bb4c34fb057523db6b861\";'),
('ospos_session:e34aebfa87dbee44a800bd5c8871f857','127.0.0.1','2026-09-03 05:20:05','__ci_last_regenerate|i:1788412805;csrf_ospos_v4|s:32:\"28faf5c2b36fc0cdfd78c9b0132770a1\";'),
('ospos_session:e549ecb99e778b2a34e53a00aafc1136','127.0.0.1','2026-09-03 06:17:13','__ci_last_regenerate|i:1788416233;csrf_ospos_v4|s:32:\"343cf3c4214bebcf9dfc555941860359\";'),
('ospos_session:eb7e11afea4862b4bb8e94d7314cbd37','127.0.0.1','2026-09-03 05:24:05','__ci_last_regenerate|i:1788413045;csrf_ospos_v4|s:32:\"4d9d92b00a13627501cdb4cdea0dfa1c\";'),
('ospos_session:ebe6273eab188b5bd5320b79d8ece6d6','127.0.0.1','2026-09-03 05:40:38','__ci_last_regenerate|i:1788414038;csrf_ospos_v4|s:32:\"bbc15caafa1df207d546efaf6c553690\";'),
('ospos_session:ec741aa95ac5ea3e7a69d78c88368d31','127.0.0.1','2026-09-03 05:09:03','__ci_last_regenerate|i:1788412143;csrf_ospos_v4|s:32:\"a8e8391ae2dad6a0ec331474c58d7a4b\";'),
('ospos_session:eda91b25831c53edb1edf07ae7eb27a6','127.0.0.1','2026-09-03 05:14:34','__ci_last_regenerate|i:1788412474;csrf_ospos_v4|s:32:\"80d0b6d096ef2f998d34bd69b3cbe2dd\";'),
('ospos_session:ee4bd7bc75aedf2c5b2ed5f82bcbe855','127.0.0.1','2026-09-03 06:14:12','__ci_last_regenerate|i:1788416052;csrf_ospos_v4|s:32:\"be9f1b443493e0459d5a18e1b7c54a38\";'),
('ospos_session:ef1dc22e3482cc8f3364a67bb975a7a5','127.0.0.1','2026-09-03 05:20:35','__ci_last_regenerate|i:1788412835;csrf_ospos_v4|s:32:\"73a2ba3fedd4a708b76cfedbb950d0e2\";'),
('ospos_session:f00a693029a7bd062e94b6088b777e7e','127.0.0.1','2026-09-03 06:18:43','__ci_last_regenerate|i:1788416323;csrf_ospos_v4|s:32:\"af524c90cc00289a25dfdfd55c7ec2b4\";'),
('ospos_session:f10d904a46d072e0129bc8ebf98a097e','127.0.0.1','2026-09-03 05:16:04','__ci_last_regenerate|i:1788412564;csrf_ospos_v4|s:32:\"dec0f87bbb4f161644e45daba6c7d064\";'),
('ospos_session:f1803c5ee32efc8880a715e1cff6146f','127.0.0.1','2026-09-03 05:26:06','__ci_last_regenerate|i:1788413166;csrf_ospos_v4|s:32:\"feaa766064fe673fdd4c1d3767a869f2\";'),
('ospos_session:f4b1560359736b6e73aa1c6fb3f85e10','127.0.0.1','2026-09-03 06:21:43','__ci_last_regenerate|i:1788416503;csrf_ospos_v4|s:32:\"f0e5f0cbd4fbdb8c7b2214ad1a171c74\";'),
('ospos_session:f88f06042b37dc2147de25308d0f2c3e','127.0.0.1','2026-09-03 05:28:06','__ci_last_regenerate|i:1788413286;csrf_ospos_v4|s:32:\"3c239d32b41fda965d3482954b1f870e\";'),
('ospos_session:f9786913c17c385cb2f0736f532509eb','127.0.0.1','2026-09-03 05:40:08','__ci_last_regenerate|i:1788414008;csrf_ospos_v4|s:32:\"b71cd8ecc1d2553870217034801e3459\";'),
('ospos_session:fb8ffcef2ce8d7769b0f11e7c8c16e9f','127.0.0.1','2026-09-03 05:39:38','__ci_last_regenerate|i:1788413978;csrf_ospos_v4|s:32:\"6d7d2849103c7d577791a5e985ca0b7c\";'),
('ospos_session:fbe86975603eef73cf15cde384bc654a','127.0.0.1','2026-09-03 05:53:10','__ci_last_regenerate|i:1788414790;csrf_ospos_v4|s:32:\"79ad0d06d82afe33929bf421b76e1e9a\";'),
('ospos_session:fc0e291742089179bcd6f6229a697949','127.0.0.1','2026-09-03 06:04:41','__ci_last_regenerate|i:1788415481;csrf_ospos_v4|s:32:\"c4c2d8e9c726b16e5b4f4a1c624ccd3d\";'),
('ospos_session:fd980f99da36aae515f3de789dce3d05','127.0.0.1','2026-09-03 06:06:11','__ci_last_regenerate|i:1788415571;csrf_ospos_v4|s:32:\"5c8de5622c32509eac48ca243c777903\";'),
('ospos_session:fdf4194d777dd03a2b160efbb7203c58','127.0.0.1','2026-09-03 05:37:37','__ci_last_regenerate|i:1788413857;csrf_ospos_v4|s:32:\"03f389df81dbb605f636512ead569c97\";'),
('ospos_session:fe420b75da10c3f583fac7e586356b08','127.0.0.1','2026-09-03 06:01:11','__ci_last_regenerate|i:1788415271;csrf_ospos_v4|s:32:\"663923f97731d418e98600b980d967dd\";'),
('ospos_session:fe7fc2f05af92292135561e9ed514ee2','127.0.0.1','2026-09-03 05:25:06','__ci_last_regenerate|i:1788413106;csrf_ospos_v4|s:32:\"a1b8f8a2ed0414adfafcd18744834c94\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'Warehouse',0),
(2,'Shop',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(2,'FFC','FFC',NULL,'',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03 13:10:46
