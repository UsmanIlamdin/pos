/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','id'),
('barcode_first_row','category'),
('barcode_font','0'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','0'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C128'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','1'),
('category_dropdown','0'),
('clcdesq_api_key',''),
('clcdesq_api_url',''),
('company','CortexFlow'),
('company_logo','Screenshot 2026-08-28 at 4.49.58 PM.png'),
('country_codes','us'),
('currency_code','PKR'),
('currency_decimals','2'),
('currency_symbol','Rs'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format','0'),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category',''),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','0'),
('dinner_table_enable','0'),
('email','changeme@example.com'),
('email_receipt_check_behaviour','last'),
('enforce_privacy','0'),
('fax',''),
('financial_year','1'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','jpg,gif,png'),
('image_max_height','640'),
('image_max_size','1024'),
('image_max_width','640'),
('include_hsn','0'),
('invoice_default_comments','This is a default comment'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','0'),
('last_used_quote_number','0'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form','floating_labels'),
('mailchimp_api_key',''),
('mailchimp_list_id',''),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('payment_reference_code_max','40'),
('payment_reference_code_min','3'),
('phone','555-555-5555'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','last'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','12'),
('receipt_show_company_name','1'),
('receipt_show_description','0'),
('receipt_show_serialnumber','1'),
('receipt_show_taxes','1'),
('receipt_show_tax_ind','1'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_short'),
('receiving_calculate_average_price','0'),
('recv_invoice_format','{CO}'),
('return_policy','Exchange possible within 7 days with Receipt'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id','454-554-1234'),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','Asia/Karachi'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Expiry Date','DATE',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,5,NULL,NULL,'1-5'),
(1,1,7,NULL,NULL,'1-7');
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,NULL,'2026-09-30',NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-09-04 05:01:04','2026-09-04 05:01:04',40000.00,3300.00,0,70000.00,0.00,0.00,26700.00,'',1,1,0,0.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(2,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-04 04:07:02',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('admin','$2y$10$vJBSMlD02EC7ENSrKfVQXuvq9tNRHMtcOA8MSK2NYS748HHWm.gcG',1,0,2,NULL,NULL);
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_Shop_1',1,'home'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_Shop_1',1,'home'),
('reports',1,'home'),
('reports_categories',1,'home'),
('reports_customers',1,'home'),
('reports_discounts',1,'home'),
('reports_employees',1,'home'),
('reports_expenses_categories',1,'home'),
('reports_inventory',1,'home'),
('reports_items',1,'home'),
('reports_payments',1,'home'),
('reports_receivings',1,'home'),
('reports_sales',1,'home'),
('reports_sales_taxes',1,'home'),
('reports_suppliers',1,'home'),
('reports_taxes',1,'home'),
('sales',1,'home'),
('sales_change_price',1,'--'),
('sales_delete',1,'--'),
('sales_Shop_1',1,'home'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-09-04 04:03:40','Manual Edit of Quantity',1,222.000),
(2,1,1,'2026-09-04 04:05:45','POS 1',1,-1.000),
(3,2,1,'2026-09-04 04:58:44','Manual Edit of Quantity',1,900.000),
(4,1,1,'2026-09-04 05:00:15','RECV 1',1,300.000),
(5,1,1,'2026-09-04 05:03:37','POS 2',1,-6.000),
(6,2,1,'2026-09-04 05:03:37','POS 2',1,-6.000),
(7,3,1,'2026-09-04 05:04:54','Manual Edit of Quantity',1,100.000),
(8,3,1,'2026-09-04 05:08:09','POS 3',1,-1.000),
(9,1,1,'2026-09-04 05:08:09','POS 3',1,-6.000),
(10,3,1,'2026-09-04 05:08:42','POS 4',1,-1.000),
(11,1,1,'2026-09-04 05:08:42','POS 4',1,-6.000),
(12,3,1,'2026-09-04 05:10:41','POS 5',1,-1.000),
(13,1,1,'2026-09-04 05:10:41','POS 5',1,-6.000),
(14,3,1,'2026-09-05 09:51:05','POS 6',1,-1.000),
(15,1,1,'2026-09-05 09:51:05','POS 6',1,-6.000),
(16,3,1,'2026-09-06 13:46:18','Manual Edit of Quantity',1,-96.000),
(17,1,1,'2026-09-06 13:49:04','RECV 2',1,500.000),
(18,1,1,'2026-09-10 11:59:45','POS 7',1,-6.000),
(19,4,1,'2026-09-12 14:06:34','Manual Edit of Quantity',1,5.000),
(20,5,1,'2026-09-12 14:08:12','Manual Edit of Quantity',1,10.000),
(21,6,1,'2026-09-12 14:09:47','Manual Edit of Quantity',1,0.000),
(22,7,1,'2026-09-12 14:10:28','Manual Edit of Quantity',1,0.000),
(23,8,1,'2026-09-12 14:40:33','Manual Edit of Quantity',1,100.000),
(24,9,1,'2026-09-12 14:40:49','Manual Edit of Quantity',1,0.000),
(25,10,1,'2026-09-12 14:41:11','Manual Edit of Quantity',1,0.000),
(26,11,1,'2026-09-12 14:41:34','Manual Edit of Quantity',1,0.000),
(27,12,1,'2026-09-12 14:41:48','Manual Edit of Quantity',1,0.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
INSERT INTO `ospos_item_kit_items` VALUES
(1,1,6.000,0),
(1,2,6.000,0),
(2,1,6.000,0);
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
INSERT INTO `ospos_item_kits` VALUES
(1,'SKU-15','Ramzan Offer','',0,10.00,0,0,0),
(2,'SKU-19','Ramzan Offer 2','This is the free item with 2 pack of 1.L any beverage',3,0.00,0,0,2);
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,985.000),
(2,1,894.000),
(3,1,0.000),
(4,1,5.000),
(5,1,10.000),
(6,1,0.000),
(7,1,0.000),
(8,1,100.000),
(9,1,0.000),
(10,1,0.000),
(11,1,0.000),
(12,1,0.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Coca Cola 1.5L','Beverage',NULL,'SKU-12','',150.00,180.00,22.000,222.000,1,NULL,0,0,0,0,0,NULL,1.000,'Each',1,''),
('Sprite 1.5L','Beverage',NULL,'SKU-13','',180.00,190.00,1.000,200.000,2,NULL,0,0,0,0,0,NULL,1.000,'Each',2,''),
('Free Coca Cola Sample','Beverage',NULL,'SKU-17','',200.00,200.00,0.000,0.000,3,'Screenshot_2026-08-28_at_4.49.58___PM.png',0,0,1,1,3,NULL,1.000,'Each',3,''),
('Coca Cola 1L','Beverage',3,'SKU-14','THis is the Coca Cola Item',0.00,0.00,10.000,1.000,4,NULL,0,1,0,0,0,NULL,1.000,'Each',4,''),
('Coca Cola 0.5L','Beverage',NULL,'SKU-15','',100.00,120.00,50.000,10.000,5,NULL,1,1,0,0,0,NULL,1.000,'Each',5,''),
('Coca Cola 2L','Beverage',NULL,'SKU-16','',0.00,0.00,1.000,1.000,6,NULL,0,0,0,0,0,NULL,1.000,'Each',6,''),
('Coca Cola 2.25L','Beverage',NULL,'SKU-17','',0.00,0.00,1.000,1.000,7,NULL,0,0,0,0,0,NULL,1.000,'Each',7,''),
('Sprte 1L','Beverage',NULL,'SKU-18','',120.00,150.00,1.000,1.000,8,NULL,0,0,0,0,0,NULL,1.000,'Each',8,''),
('Sprite 0.5L','Beverage',NULL,'SKU-19','',0.00,0.00,1.000,1.000,9,NULL,0,0,0,0,0,NULL,1.000,'Each',9,''),
('Sprite 2.25L','Beverage',NULL,'SKU-20','',0.00,0.00,1.000,1.000,10,NULL,0,0,0,0,0,NULL,1.000,'Each',10,''),
('Sprite 2L','Beverage',NULL,'SKU-21','',0.00,0.00,1.000,1.000,11,NULL,0,0,0,0,0,NULL,1.000,'Each',11,''),
('Fanta 1L','Beverage',NULL,'SKU-22','',0.00,0.00,1.000,1.000,12,NULL,0,0,0,0,0,NULL,1.000,'Each',12,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1788508907,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1788508908,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1788508908,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1788508908,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1788508908,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1788508908,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1788508908,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1788508908,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1788508908,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1788508908,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1788508908,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1788508908,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1788508908,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1788508908,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1788508908,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1788508908,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1788508908,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1788508908,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1788508908,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1788508908,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1788508908,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1788508908,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1788508908,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1788508908,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1788508908,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1788508908,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1788508908,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1788508908,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1788508908,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1788508908,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1788508908,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1788508908,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1788508908,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1788508908,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1788508908,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1788508908,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1788508909,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1788508909,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1788508909,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1788508909,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1788508909,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1788508909,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1788508909,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1788508909,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1788508909,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('John','Doe',NULL,'555-555-5555','changeme@example.com','Address 1','','','','','','',1),
('WalkIn','Walkin',1,'','','','','','','','','',2),
('Zahid','Ali',1,'555-555-5555','sanor15802@prodbits.com','Street # 4, Makkah Town, Khudian, Kasur','','Kasur','','','Pakistan','',3);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_Shop_1','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_Shop_1','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_Shop_1','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
INSERT INTO `ospos_receivings` VALUES
('2026-09-04 05:00:15',NULL,1,'This item is received',1,'Cash','ASD-123'),
('2026-09-06 13:49:04',NULL,1,'',2,'Cash','ASD-123');
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
INSERT INTO `ospos_receivings_items` VALUES
(1,1,'','',1,300.000,150.00,140.00,0.00,0,1,1.000),
(2,1,'','',1,500.000,150.00,130.00,0.00,0,1,1.000);
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-09-04 04:05:45',NULL,1,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-09-04 05:03:37',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-09-04 05:08:09',NULL,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-04 05:08:42',NULL,1,'',NULL,NULL,4,NULL,0,NULL,0),
('2026-09-04 05:10:41',NULL,1,'',NULL,NULL,5,NULL,0,NULL,0),
('2026-09-05 09:51:05',NULL,1,'This is the receipt',NULL,NULL,6,NULL,0,NULL,0),
('2026-09-10 11:59:45',NULL,1,'',NULL,NULL,7,NULL,0,NULL,0);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,1.000,150.00,180.00,0.00,0,1,0),
(2,1,'','',1,6.000,150.00,180.00,10.00,0,1,0),
(2,2,'','',2,6.000,180.00,190.00,10.00,0,1,0),
(3,1,'','',2,6.000,150.00,180.00,0.00,0,1,0),
(3,3,'','',1,1.000,200.00,200.00,0.00,0,1,0),
(4,1,'','',2,6.000,150.00,180.00,0.00,0,1,0),
(4,3,'','',1,1.000,200.00,200.00,0.00,0,1,0),
(5,1,'','',2,6.000,150.00,180.00,0.00,0,1,0),
(5,3,'','',1,1.000,200.00,200.00,0.00,0,1,0),
(6,1,'','',2,6.000,150.00,180.00,0.00,0,1,0),
(6,3,'','',1,1.000,200.00,200.00,0.00,0,1,0),
(7,1,'','',1,6.000,150.00,180.00,0.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
INSERT INTO `ospos_sales_items_taxes` VALUES
(1,1,1,'2',0.0000,1,1,0,0.0000,NULL,NULL,NULL),
(1,1,1,'3',0.0000,1,1,0,0.0000,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,1,'Cash',180.00,0.00,0,1,'2026-09-04 08:05:45',''),
(2,2,'Cash',1998.00,0.00,0,1,'2026-09-04 09:03:37',''),
(3,3,'Cash',1280.00,0.00,0,1,'2026-09-04 09:08:09',''),
(4,4,'Cash',1280.00,0.00,0,1,'2026-09-04 09:08:42',''),
(6,5,'Cash',1280.00,0.00,0,1,'2026-09-04 09:10:41',''),
(8,6,'Cash',1500.00,220.00,0,1,'2026-09-05 04:51:05',''),
(9,7,'Cash',1080.00,0.00,0,1,'2026-09-10 06:59:45','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:019bab0961d0df642ab56ba0f53b1434','127.0.0.1','2026-09-12 09:37:38','__ci_last_regenerate|i:1789205858;csrf_ospos_v4|s:32:\"79e3ef034fbb4967adf72230793809e1\";'),
('ospos_session:01c7b5d4451dc1226b62316a56f6c57b','127.0.0.1','2026-09-10 07:04:48','__ci_last_regenerate|i:1789023888;csrf_ospos_v4|s:32:\"7dd642c278380c21bc060e2114f801a8\";'),
('ospos_session:037045bdeaf9da8b741ac4f381e7646d','127.0.0.1','2026-09-06 08:53:01','__ci_last_regenerate|i:1788684781;csrf_ospos_v4|s:32:\"1c4afafe7514beae8ac90197fda673d0\";'),
('ospos_session:03fbc5356ea9c35eee2d38767bf45495','127.0.0.1','2026-09-12 09:14:35','__ci_last_regenerate|i:1789204475;csrf_ospos_v4|s:32:\"3102bd7849ce268127d15854e8360841\";'),
('ospos_session:04ad8ef7def362c4b108a1a1b05e2373','127.0.0.1','2026-09-07 05:02:43','__ci_last_regenerate|i:1788757363;csrf_ospos_v4|s:32:\"1cf26b08d0b9bbd59308b49bf8d27e99\";'),
('ospos_session:053c620c97803f413fc90468427ff18f','127.0.0.1','2026-09-12 09:05:34','__ci_last_regenerate|i:1789203934;csrf_ospos_v4|s:32:\"0fbbba01ba13e0f37f0e6cbe2a407f75\";'),
('ospos_session:0726bdf3373239e04ae5c855a759160a','127.0.0.1','2026-09-07 04:06:56','__ci_last_regenerate|i:1788754016;csrf_ospos_v4|s:32:\"482db09845bf61dd67099db50f954dc6\";'),
('ospos_session:0887bc7777ffab20aec1ee0eec5d6810','127.0.0.1','2026-09-12 09:36:38','__ci_last_regenerate|i:1789205798;csrf_ospos_v4|s:32:\"d9e5930ad611c7d6b06a8c3aed1d4e9f\";'),
('ospos_session:08a46b7d8b3ca60a70f82e563e1697b5','127.0.0.1','2026-09-06 09:15:04','__ci_last_regenerate|i:1788686104;csrf_ospos_v4|s:32:\"8964454f88406b032f4bd34b30ef1c1b\";'),
('ospos_session:093ff3efa7583e20bde700d71b81510a','127.0.0.1','2026-09-06 17:19:17','__ci_last_regenerate|i:1788715157;csrf_ospos_v4|s:32:\"47c3993b4f25c1fc900e85876bac5dff\";'),
('ospos_session:0947a8e9d38c6528d8fad2e81c05cfc8','127.0.0.1','2026-09-06 14:23:21','__ci_last_regenerate|i:1788704601;csrf_ospos_v4|s:32:\"fcc882a8ef5d875288d8b617422f6a4f\";'),
('ospos_session:0b0d945328b00f80d5078ac7a1fbece9','127.0.0.1','2026-09-06 08:52:01','__ci_last_regenerate|i:1788684721;csrf_ospos_v4|s:32:\"65f74ae3c290d865a86da05df6e2c010\";'),
('ospos_session:0b2beb6cf23ada323278a7208f080cde','127.0.0.1','2026-09-12 09:01:33','__ci_last_regenerate|i:1789203693;csrf_ospos_v4|s:32:\"1d384413c18a3b6515f4b010f348cfe0\";'),
('ospos_session:0b7bf4b370510a6f334199f55a89e5ae','127.0.0.1','2026-09-12 09:16:35','__ci_last_regenerate|i:1789204595;csrf_ospos_v4|s:32:\"015455329deac8262f04dbbaf79b3600\";'),
('ospos_session:0cccde2ff97b890aafe2614a2ca4e3ff','172.20.0.2','2026-09-12 09:39:03','__ci_last_regenerate|i:1789205943;csrf_ospos_v4|s:32:\"ee91085f1134531a08952cb6a17a152f\";_ci_previous_url|s:29:\"https://ghazi-pos.local/items\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:0;item_location|s:1:\"1\";'),
('ospos_session:0f5136ad36047f1baceca40cf8ac2267','127.0.0.1','2026-09-12 09:16:05','__ci_last_regenerate|i:1789204565;csrf_ospos_v4|s:32:\"03078cfdad67120feba295baaa30b4af\";'),
('ospos_session:12d3770901beca21a606cdcd5d444a51','127.0.0.1','2026-09-12 09:47:21','__ci_last_regenerate|i:1789206441;csrf_ospos_v4|s:32:\"e077a66195b7a2811044d54b706cc675\";'),
('ospos_session:1400afc6a286b0c2c226d2896c29fd7e','127.0.0.1','2026-09-06 18:17:24','__ci_last_regenerate|i:1788718644;csrf_ospos_v4|s:32:\"69201c90fcf981510b98d40c8d4f0834\";'),
('ospos_session:1507f8492ea1c9c1596352d778359179','127.0.0.1','2026-09-06 08:48:30','__ci_last_regenerate|i:1788684510;csrf_ospos_v4|s:32:\"20ff305bc1a1fe5fcd76fadaabcf025a\";'),
('ospos_session:1697d1c13176849d6ef99fc717bd709f','127.0.0.1','2026-09-10 07:00:48','__ci_last_regenerate|i:1789023648;csrf_ospos_v4|s:32:\"7233921085d3c71208585364a340e55d\";'),
('ospos_session:1775f589899c2d3c6825feb2d1ffc7c3','127.0.0.1','2026-09-06 09:00:32','__ci_last_regenerate|i:1788685232;csrf_ospos_v4|s:32:\"9e2cbdd24bed0ce24505bef31983751f\";'),
('ospos_session:191c9f21cd96668b1ab1b2649c3cd254','127.0.0.1','2026-09-06 09:03:02','__ci_last_regenerate|i:1788685382;csrf_ospos_v4|s:32:\"a53dafd2c6584478504a5973aeffd74a\";'),
('ospos_session:1aa9655e33c272564faab5bb0adc54ec','172.20.0.2','2026-09-06 08:49:18','__ci_last_regenerate|i:1788684302;csrf_ospos_v4|s:32:\"2270b02310e803859f16adcd4ddeb9b6\";_ci_previous_url|s:33:\"https://ghazi-pos.local/suppliers\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:1;item_location|s:1:\"1\";sale_id|i:-1;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:0:{}sales_customer|i:-1;sales_mode|s:4:\"sale\";sales_location|i:1;sales_payments|a:0:{}recv_stock_source|i:1;recv_print_after_sale|b:1;recv_cart|a:0:{}recv_mode|s:6:\"return\";recv_supplier|i:-1;'),
('ospos_session:1e518fa15318f0400b1e7ee38a3ff274','127.0.0.1','2026-09-12 09:02:33','__ci_last_regenerate|i:1789203753;csrf_ospos_v4|s:32:\"cd540a08f464facfafab86bd57e8599d\";'),
('ospos_session:200ddb007a38f7a950f0332839ab25ab','127.0.0.1','2026-09-12 09:43:20','__ci_last_regenerate|i:1789206200;csrf_ospos_v4|s:32:\"48a19826d3816a4fe93baed5d12b2402\";'),
('ospos_session:20c6f82c3c7bec6afb287f6d91e69f3a','127.0.0.1','2026-09-12 09:07:34','__ci_last_regenerate|i:1789204054;csrf_ospos_v4|s:32:\"85cf9cb434d53830d5f92154d88d5c4a\";'),
('ospos_session:21474ba0945b20e6041b37f59cee93e4','127.0.0.1','2026-09-06 08:50:30','__ci_last_regenerate|i:1788684630;csrf_ospos_v4|s:32:\"b62e480b765d78399c7ff0bc1437fd24\";'),
('ospos_session:2197e6314c604a6cdddb9463095994c3','127.0.0.1','2026-09-06 09:11:33','__ci_last_regenerate|i:1788685893;csrf_ospos_v4|s:32:\"30c435fb367ad0e1d6be0a88a1c8d766\";'),
('ospos_session:228eda51936728daa54f19e736c5f684','172.20.0.3','2026-09-12 09:47:49','__ci_last_regenerate|i:1789206464;csrf_ospos_v4|s:32:\"df553e6f64c2d39c5a4ecfd39ad1eeee\";_ci_previous_url|s:29:\"https://ghazi-pos.local/items\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:0;item_location|s:1:\"1\";'),
('ospos_session:23ddf76e861b852b0b5a0860996906ad','127.0.0.1','2026-09-10 07:02:18','__ci_last_regenerate|i:1789023738;csrf_ospos_v4|s:32:\"8aaee3e03346e89ff3bb19e944ce4275\";'),
('ospos_session:241a8fb425e99e1577fac81cb316caac','127.0.0.1','2026-09-06 09:10:03','__ci_last_regenerate|i:1788685803;csrf_ospos_v4|s:32:\"049ff866994b6578e1bb9681005f56c4\";'),
('ospos_session:256be939b47553b2df24d9c1603089c2','127.0.0.1','2026-09-12 09:24:06','__ci_last_regenerate|i:1789205046;csrf_ospos_v4|s:32:\"f71940e82fdfb2676f59615666f1521c\";'),
('ospos_session:2593d69a0348badf7c8b2bb0e93b7deb','127.0.0.1','2026-09-12 09:12:05','__ci_last_regenerate|i:1789204325;csrf_ospos_v4|s:32:\"964a842ea993b2731649051ac2470c54\";'),
('ospos_session:25dcd36e0dfe1f03a9a2328dfeafefd9','127.0.0.1','2026-09-06 08:43:59','__ci_last_regenerate|i:1788684239;csrf_ospos_v4|s:32:\"53dc198a620632939215d8d1e16b621d\";'),
('ospos_session:2695faebc70248f0f6480cbeb70e77be','127.0.0.1','2026-09-06 08:54:31','__ci_last_regenerate|i:1788684871;csrf_ospos_v4|s:32:\"eb81e6f9d79048c8fe300566db726210\";'),
('ospos_session:26b1a97eae747ea6c555fe469e29704c','127.0.0.1','2026-09-12 09:39:50','__ci_last_regenerate|i:1789205990;csrf_ospos_v4|s:32:\"da29bd888e4611f639eaba21c6cf05c8\";'),
('ospos_session:27817aaf78698faeb5553585263b8b63','127.0.0.1','2026-09-12 09:04:34','__ci_last_regenerate|i:1789203874;csrf_ospos_v4|s:32:\"a45ee6af4494fdd4040e55bb34688ab9\";'),
('ospos_session:28f406ee43c0e7f5ca291a947d8a8d2c','127.0.0.1','2026-09-07 05:07:44','__ci_last_regenerate|i:1788757664;csrf_ospos_v4|s:32:\"83fe1aa8e0a17d3851f4d542a85bfc31\";'),
('ospos_session:2a46d86ac808531adf344139733964d1','127.0.0.1','2026-09-06 16:24:47','__ci_last_regenerate|i:1788711887;csrf_ospos_v4|s:32:\"fdc1edd8d035a59df3318c2a8adb0cbc\";'),
('ospos_session:2a5aa30b5b45c356449d818c8bf09274','127.0.0.1','2026-09-11 14:14:51','__ci_last_regenerate|i:1789136091;csrf_ospos_v4|s:32:\"58d45affe8e71d57b539b438575cf196\";'),
('ospos_session:2bcbafc901d062b94f9a8299e9452cae','127.0.0.1','2026-09-06 09:07:02','__ci_last_regenerate|i:1788685622;csrf_ospos_v4|s:32:\"79ce026c289674eee92bda36b34d950b\";'),
('ospos_session:2c269dd5fcb9ce8116d5e2d8e0be2114','127.0.0.1','2026-09-10 06:59:48','__ci_last_regenerate|i:1789023588;csrf_ospos_v4|s:32:\"5cc019fc262047cd063eb0153a4a9d00\";'),
('ospos_session:2d2c32f4144f036a6f0ec7ecd985290a','127.0.0.1','2026-09-12 09:05:04','__ci_last_regenerate|i:1789203904;csrf_ospos_v4|s:32:\"860b7b13d65d99a38b2897b783b8ad57\";'),
('ospos_session:2f4177f658c225a07598629db2be6b35','127.0.0.1','2026-09-07 05:10:14','__ci_last_regenerate|i:1788757814;csrf_ospos_v4|s:32:\"51696f06ed9a7c10ce3c001621bf6734\";'),
('ospos_session:312261ab40dad3222e45426352e5fefe','127.0.0.1','2026-09-12 09:14:05','__ci_last_regenerate|i:1789204445;csrf_ospos_v4|s:32:\"873cb7ddce1c7c8bb56ada98853cf260\";'),
('ospos_session:3155c76f8a9bd9dab27ecfc631064437','127.0.0.1','2026-09-12 09:08:04','__ci_last_regenerate|i:1789204084;csrf_ospos_v4|s:32:\"ea0cf86ae71959658c9101958df503dd\";'),
('ospos_session:320e5c8742c6e985618a0b11da18f01b','127.0.0.1','2026-09-12 09:25:36','__ci_last_regenerate|i:1789205136;csrf_ospos_v4|s:32:\"92a0782e264cc36e435ce58266678bd5\";'),
('ospos_session:320edc683495b755160fa9c565adc21f','127.0.0.1','2026-09-07 05:11:44','__ci_last_regenerate|i:1788757904;csrf_ospos_v4|s:32:\"8c0fc629d58c39aaf962f97786b59ef5\";'),
('ospos_session:3295d4eed383289b0b6e3ff9b978e9c4','127.0.0.1','2026-09-06 08:49:30','__ci_last_regenerate|i:1788684570;csrf_ospos_v4|s:32:\"f3b9e1f209997df6162b9088010a583c\";'),
('ospos_session:32a9ebae01076ed642dca88750e3fcc0','127.0.0.1','2026-09-10 07:00:18','__ci_last_regenerate|i:1789023618;csrf_ospos_v4|s:32:\"d35b2036543692d0349f8ed2805cb0d2\";'),
('ospos_session:32be052c9ed8c650cf2036a13031cf74','127.0.0.1','2026-09-07 05:07:14','__ci_last_regenerate|i:1788757634;csrf_ospos_v4|s:32:\"78c70829349f1d6f865fce6d378d211d\";'),
('ospos_session:352a69393f3757033036e2298115a236','127.0.0.1','2026-09-12 09:31:07','__ci_last_regenerate|i:1789205467;csrf_ospos_v4|s:32:\"207d8ac093c563e69e315a5851063e70\";'),
('ospos_session:37c530fe178532127f2665b4daeb528e','127.0.0.1','2026-09-12 09:47:51','__ci_last_regenerate|i:1789206471;csrf_ospos_v4|s:32:\"f7145ac61b461eb83a92f2e9a7ab5991\";'),
('ospos_session:384e3863b964371e9082e60d056a827d','127.0.0.1','2026-09-06 09:02:02','__ci_last_regenerate|i:1788685322;csrf_ospos_v4|s:32:\"a29748f3f0fcdd989295903923dc7966\";'),
('ospos_session:39892c10c7f09b2d15306790d5fd33b5','127.0.0.1','2026-09-10 07:03:18','__ci_last_regenerate|i:1789023798;csrf_ospos_v4|s:32:\"3ce13e93ecb541038d66d3dd103f4bbb\";'),
('ospos_session:3a32c74e8365193c795edf07377ef683','127.0.0.1','2026-09-06 15:52:17','__ci_last_regenerate|i:1788709937;csrf_ospos_v4|s:32:\"dd4d2318b22e8131a28debd6c05d806a\";'),
('ospos_session:3a3f4b48d4586b1ba7dbb74d2fde77a7','127.0.0.1','2026-09-12 09:27:37','__ci_last_regenerate|i:1789205257;csrf_ospos_v4|s:32:\"07439e103babc3c223b272a32e906715\";'),
('ospos_session:3a907cb16da508c15e93cbe0c1cdacfa','127.0.0.1','2026-09-12 09:21:06','__ci_last_regenerate|i:1789204866;csrf_ospos_v4|s:32:\"a84eabb3c46bb922740190a31f7614c3\";'),
('ospos_session:3b12a9d19460e32860a6954ab58cc37e','127.0.0.1','2026-09-06 09:00:02','__ci_last_regenerate|i:1788685202;csrf_ospos_v4|s:32:\"75f5d81b5b9feea89a8f64829feec4eb\";'),
('ospos_session:3b3381b06b4c299da43e443ff2449282','127.0.0.1','2026-09-06 08:58:01','__ci_last_regenerate|i:1788685081;csrf_ospos_v4|s:32:\"c4dff342153b3a3db30c721820009afe\";'),
('ospos_session:3c3357fc775080a0c03b0c8e70b40339','127.0.0.1','2026-09-12 09:22:36','__ci_last_regenerate|i:1789204956;csrf_ospos_v4|s:32:\"8a0a63c92f51d9a78236351bc46dbe72\";'),
('ospos_session:3ccf20672e3314580504b28274b0c9b4','127.0.0.1','2026-09-10 06:58:17','__ci_last_regenerate|i:1789023497;csrf_ospos_v4|s:32:\"c0c95fafb9e65a9cbcd0b04cb1ce7ed9\";'),
('ospos_session:3dcdb556a6fe4bfe0ec44dea8826fde7','127.0.0.1','2026-09-06 12:31:29','__ci_last_regenerate|i:1788697889;csrf_ospos_v4|s:32:\"13e72f4aec7b7ba4307bf1bc69e8dca8\";'),
('ospos_session:4125f13e6d00bb8b1967f9a66f0fdcd0','127.0.0.1','2026-09-12 09:06:34','__ci_last_regenerate|i:1789203994;csrf_ospos_v4|s:32:\"a04964c0ed3a7c9dd92091d66ec8763e\";'),
('ospos_session:412b82f4d2cff93d296073dd7812301c','127.0.0.1','2026-09-12 09:15:35','__ci_last_regenerate|i:1789204535;csrf_ospos_v4|s:32:\"99693a0fbfd99ce240c85cbb24613e84\";'),
('ospos_session:417871b86d390fa251a10eef255072ec','127.0.0.1','2026-09-12 09:28:07','__ci_last_regenerate|i:1789205287;csrf_ospos_v4|s:32:\"66339a3d8b87cf7778d4e31bef199ff0\";'),
('ospos_session:43825ea395c6c57a573dab12a9a23c46','127.0.0.1','2026-09-12 09:10:34','__ci_last_regenerate|i:1789204234;csrf_ospos_v4|s:32:\"d33251f4941bc25371b57f4f3b0aee5e\";'),
('ospos_session:448c01eab24ea1e7cb0f78efabf0ef6e','127.0.0.1','2026-09-12 09:29:07','__ci_last_regenerate|i:1789205347;csrf_ospos_v4|s:32:\"5aea40d2e2ab10e99e277738c73f1418\";'),
('ospos_session:44dc7dcd19e82a2b92a3c841672d5ece','127.0.0.1','2026-09-07 01:09:53','__ci_last_regenerate|i:1788743393;csrf_ospos_v4|s:32:\"ff0dfc66aa365839668e33a2f50add22\";'),
('ospos_session:47434543232e89782d2a12a6d9d690b2','127.0.0.1','2026-09-10 06:59:18','__ci_last_regenerate|i:1789023558;csrf_ospos_v4|s:32:\"ddfde75b7d77695faf6bcf1aa38a00f0\";'),
('ospos_session:496f49aa847b42f6fb35046327d09e89','127.0.0.1','2026-09-06 08:59:31','__ci_last_regenerate|i:1788685171;csrf_ospos_v4|s:32:\"353934c7e8c972d37b2cc3da272d8e72\";'),
('ospos_session:49ece2d550ea3f27d997eaaf99b554d4','127.0.0.1','2026-09-12 09:42:20','__ci_last_regenerate|i:1789206140;csrf_ospos_v4|s:32:\"6efddc9b423abb3d2eee4e25ada1fdcd\";'),
('ospos_session:4c18363344ad8b8effa201d77ea97a6b','127.0.0.1','2026-09-06 23:08:59','__ci_last_regenerate|i:1788736139;csrf_ospos_v4|s:32:\"4c86351a36d2efa60db851c785743d13\";'),
('ospos_session:4f95c4b12ccce5db585f7b576d45c8b3','127.0.0.1','2026-09-06 19:35:29','__ci_last_regenerate|i:1788723329;csrf_ospos_v4|s:32:\"ad05f53e67b4f406581acbbc0e37b4f5\";'),
('ospos_session:505318be2bc1458155df9bcd75ed6ec6','127.0.0.1','2026-09-06 08:47:00','__ci_last_regenerate|i:1788684420;csrf_ospos_v4|s:32:\"c39d1268f856617c7ba32119cf6a6fb2\";'),
('ospos_session:52d1159605925a521d674957ac39ee66','127.0.0.1','2026-09-12 09:17:35','__ci_last_regenerate|i:1789204655;csrf_ospos_v4|s:32:\"9e6680b6582109b80e5a142eba0abfac\";'),
('ospos_session:54d5a1fbd2297ca723befd9d4f99fdc3','127.0.0.1','2026-09-06 08:52:31','__ci_last_regenerate|i:1788684751;csrf_ospos_v4|s:32:\"7d08839f8b5b9c7a20ed788dde096cc2\";'),
('ospos_session:54fd3d2ce0dacb5f805463fb54629125','127.0.0.1','2026-09-12 09:12:35','__ci_last_regenerate|i:1789204355;csrf_ospos_v4|s:32:\"cc1aad31b277c570ae7b611f7b02e95e\";'),
('ospos_session:551d449ab7488890719fe031d26155ad','127.0.0.1','2026-09-07 05:09:14','__ci_last_regenerate|i:1788757754;csrf_ospos_v4|s:32:\"5a7bb8aacc743421a693f8d24ebfd264\";'),
('ospos_session:568617c24a6df4d505fefe68045af94c','127.0.0.1','2026-09-06 09:08:03','__ci_last_regenerate|i:1788685683;csrf_ospos_v4|s:32:\"734c550bd9bcac50bcf187ccf5ccbd3b\";'),
('ospos_session:56df12dad7d3f3fcff85d9ad5337f9a8','127.0.0.1','2026-09-06 09:10:33','__ci_last_regenerate|i:1788685833;csrf_ospos_v4|s:32:\"184d1ebe73193fd64551a6a8f3e7648e\";'),
('ospos_session:5786a746bd5fa3b9ec2e85140ed7eeac','127.0.0.1','2026-09-11 14:17:21','__ci_last_regenerate|i:1789136241;csrf_ospos_v4|s:32:\"dc1122c4e6cdd6da9a0d8726c174a294\";'),
('ospos_session:579c3e0f3873530f7e5a20ab8a7a2140','127.0.0.1','2026-09-07 05:05:13','__ci_last_regenerate|i:1788757513;csrf_ospos_v4|s:32:\"03d4bbd9be6f026297be7a31e12f8c7e\";'),
('ospos_session:584ef6de4231d1c4a2a48d7bbac807b4','127.0.0.1','2026-09-07 05:06:14','__ci_last_regenerate|i:1788757574;csrf_ospos_v4|s:32:\"4ccacfa157533e1ff898d568f92a87d8\";'),
('ospos_session:5a35a871f60b36705f6d868d108c54c0','127.0.0.1','2026-09-12 09:34:08','__ci_last_regenerate|i:1789205648;csrf_ospos_v4|s:32:\"dbcd64be87fdf890f83544503662bd67\";'),
('ospos_session:5bef1e558cb35ecdf2b4e0951b72de7d','127.0.0.1','2026-09-07 05:03:43','__ci_last_regenerate|i:1788757423;csrf_ospos_v4|s:32:\"59d98ce9dde67d1ee10a4e4e67f60d1d\";'),
('ospos_session:5f1781905ed4b44c3efbc6029fc4fe9a','127.0.0.1','2026-09-12 09:21:36','__ci_last_regenerate|i:1789204896;csrf_ospos_v4|s:32:\"51afa201a383e79ad0eb234c3ea953f4\";'),
('ospos_session:5f2a1a834c022a29b7fcabf1e30d1ec5','127.0.0.1','2026-09-12 09:45:20','__ci_last_regenerate|i:1789206320;csrf_ospos_v4|s:32:\"05b656508424d0bbc0ce955db301180c\";'),
('ospos_session:5f975af24c4532a1a6c2bba98ee57be9','127.0.0.1','2026-09-12 09:36:08','__ci_last_regenerate|i:1789205768;csrf_ospos_v4|s:32:\"35558680dbbed9f5dd6f57f8f26e5365\";'),
('ospos_session:60429bf87a37f9cf135cce51d43da71f','127.0.0.1','2026-09-06 08:59:01','__ci_last_regenerate|i:1788685141;csrf_ospos_v4|s:32:\"fafc97904ca250a2e516fe4cddf8b3f3\";'),
('ospos_session:61412339d8b34033c79c6c1e1d6d654c','127.0.0.1','2026-09-12 09:17:05','__ci_last_regenerate|i:1789204625;csrf_ospos_v4|s:32:\"a1130ecbfe78e566d10590291f81ef03\";'),
('ospos_session:6294b99939a73b43f658a3cc708bd979','127.0.0.1','2026-09-10 06:58:47','__ci_last_regenerate|i:1789023527;csrf_ospos_v4|s:32:\"67f8ec165d3acd0c3dd3a2f240d41ccd\";'),
('ospos_session:63e188b7181486416ea19680b9f756db','127.0.0.1','2026-09-12 09:28:37','__ci_last_regenerate|i:1789205317;csrf_ospos_v4|s:32:\"5cd24a3efe0f91d841d1ddd1d1c5c000\";'),
('ospos_session:680f450d2027ff58c417361a1ef7b1bf','127.0.0.1','2026-09-12 09:38:08','__ci_last_regenerate|i:1789205888;csrf_ospos_v4|s:32:\"40d2cdf6e08c7c9545961a0bfa56d879\";'),
('ospos_session:692f5ed290b034a1d038c78165e4dca0','127.0.0.1','2026-09-06 16:15:26','__ci_last_regenerate|i:1788711326;csrf_ospos_v4|s:32:\"29488bf119451fc05f116d6ab2e42cf5\";'),
('ospos_session:6adaaaa24002225f5d0a9754840f765e','127.0.0.1','2026-09-12 09:33:38','__ci_last_regenerate|i:1789205618;csrf_ospos_v4|s:32:\"ddecefe7b99581d8c60ec325fcf36476\";'),
('ospos_session:6beb81176ec4525017caa7025901612e','127.0.0.1','2026-09-12 09:32:37','__ci_last_regenerate|i:1789205557;csrf_ospos_v4|s:32:\"0a77cbbd1836dc77f6ea54c9dc08fd00\";'),
('ospos_session:6bfb3db5aa5190420851e104640317d1','127.0.0.1','2026-09-06 08:54:01','__ci_last_regenerate|i:1788684841;csrf_ospos_v4|s:32:\"ca3c55c86566247b97e0a2510d5f1c92\";'),
('ospos_session:6cdb2d4dea718db3130312a986bf41b4','127.0.0.1','2026-09-06 08:47:30','__ci_last_regenerate|i:1788684450;csrf_ospos_v4|s:32:\"a47fdccf76c9c80b42bfc6ec740aa3a0\";'),
('ospos_session:6ee8d2356b096fd9cee400f32bceeb63','127.0.0.1','2026-09-07 05:11:14','__ci_last_regenerate|i:1788757874;csrf_ospos_v4|s:32:\"4fd83a723f713de895f48916b26abc53\";'),
('ospos_session:6f6a5bb0087ce1d2cb3d815d714b4df3','127.0.0.1','2026-09-06 09:09:03','__ci_last_regenerate|i:1788685743;csrf_ospos_v4|s:32:\"661c158409fda02829475ee951ebab41\";'),
('ospos_session:701344e537298654d5e8bb36de229e16','127.0.0.1','2026-09-06 09:12:03','__ci_last_regenerate|i:1788685923;csrf_ospos_v4|s:32:\"3d9e9041598da4929d45e39403df8e70\";'),
('ospos_session:706a5244fed2e54043f54d17287326eb','127.0.0.1','2026-09-06 08:55:01','__ci_last_regenerate|i:1788684901;csrf_ospos_v4|s:32:\"37fa55c62c432e80dce69cda60eedb38\";'),
('ospos_session:70d9175d82dc7c9dab3c21fec905ac3e','127.0.0.1','2026-09-06 08:56:31','__ci_last_regenerate|i:1788684991;csrf_ospos_v4|s:32:\"481ffbfa5c89d572938df3796d7a5363\";'),
('ospos_session:71ae020485a8715c0d23c92c0130279b','127.0.0.1','2026-09-06 13:12:58','__ci_last_regenerate|i:1788700378;csrf_ospos_v4|s:32:\"639220184f9445f5591ac5ef930a4919\";'),
('ospos_session:72fc0f0b1f0ba09db3f66a95989faad5','127.0.0.1','2026-09-06 09:05:02','__ci_last_regenerate|i:1788685502;csrf_ospos_v4|s:32:\"324c760300cb2aaa46a6d6410de38962\";'),
('ospos_session:73635954fb7ffd392d42ef94d2fcf051','127.0.0.1','2026-09-06 10:09:15','__ci_last_regenerate|i:1788689355;csrf_ospos_v4|s:32:\"4e426ff3ad309e7406056694811c1f6d\";'),
('ospos_session:73b392d24156b0e4fc02977bf59ed61a','127.0.0.1','2026-09-12 09:31:37','__ci_last_regenerate|i:1789205497;csrf_ospos_v4|s:32:\"c1cc844e902c65acb1db653ffc5ed93a\";'),
('ospos_session:74aa56fb615efcb8a5bb85d340519b81','127.0.0.1','2026-09-12 09:23:06','__ci_last_regenerate|i:1789204986;csrf_ospos_v4|s:32:\"4d51fad6ce01f835b5b0a7bacd6b8d10\";'),
('ospos_session:7576d1792369e519e88fc4dad950ca21','127.0.0.1','2026-09-12 09:11:35','__ci_last_regenerate|i:1789204295;csrf_ospos_v4|s:32:\"70dedb0705071dc93074a921c5f5b547\";'),
('ospos_session:75f9814aacafa4865c903cf9b44afb18','127.0.0.1','2026-09-07 05:05:44','__ci_last_regenerate|i:1788757544;csrf_ospos_v4|s:32:\"c41d3ecf9748fd7ce212b12a2e55e2c7\";'),
('ospos_session:7606d0d0bdc3084ed0c3bc4a62453a16','127.0.0.1','2026-09-06 17:36:27','__ci_last_regenerate|i:1788716187;csrf_ospos_v4|s:32:\"fbea71d207740f56e64d7f6f2c5882aa\";'),
('ospos_session:76657e7840d517c07e223b028332bb1d','127.0.0.1','2026-09-06 13:55:58','__ci_last_regenerate|i:1788702958;csrf_ospos_v4|s:32:\"e2647880179850b35b83f2efafdde546\";'),
('ospos_session:7724cf32f69f70bb287b79c869d9fac6','127.0.0.1','2026-09-06 10:02:55','__ci_last_regenerate|i:1788688975;csrf_ospos_v4|s:32:\"04f17c968a922b3fea9b056b23e406ca\";'),
('ospos_session:780f2622a252c7603b2c2c62db9eb7f0','127.0.0.1','2026-09-06 09:04:32','__ci_last_regenerate|i:1788685472;csrf_ospos_v4|s:32:\"715c4a299642b7c7a8f7ae5be6a550a6\";'),
('ospos_session:78216d8bf92483838d132009f8efd74b','127.0.0.1','2026-09-07 04:36:38','__ci_last_regenerate|i:1788755798;csrf_ospos_v4|s:32:\"457d02f94fda447d92a91961ff3f9fed\";'),
('ospos_session:794ba2c1fc50fe82467452a38b009138','127.0.0.1','2026-09-12 09:06:04','__ci_last_regenerate|i:1789203964;csrf_ospos_v4|s:32:\"3497fa02e022ebb73a505c9239a71246\";'),
('ospos_session:7958c9336fc0133972bff47747e3ef89','127.0.0.1','2026-09-12 09:04:04','__ci_last_regenerate|i:1789203844;csrf_ospos_v4|s:32:\"c77cdcd9173f86e5142f3c561e00d0be\";'),
('ospos_session:7b086c77fc0a0bbb893a0301ac485460','127.0.0.1','2026-09-12 09:35:38','__ci_last_regenerate|i:1789205738;csrf_ospos_v4|s:32:\"f9dc3696e7185ef098ed8f9e3dd46071\";'),
('ospos_session:7b4558adc643d4880a8ad150a7172817','127.0.0.1','2026-09-12 09:03:03','__ci_last_regenerate|i:1789203783;csrf_ospos_v4|s:32:\"23c15cc1a5d5ee2c473414e6180145e0\";'),
('ospos_session:7c046ae04791fa320c3eb677ba730f24','127.0.0.1','2026-09-12 09:29:37','__ci_last_regenerate|i:1789205377;csrf_ospos_v4|s:32:\"a0b2643fe61fb2d650f54c4284cfd764\";'),
('ospos_session:7c06838ece2275ba77fd1537c8e919b1','127.0.0.1','2026-09-06 09:12:33','__ci_last_regenerate|i:1788685953;csrf_ospos_v4|s:32:\"dedba124a5ad8434a15393a7ab2ff40f\";'),
('ospos_session:7cf03c26fde16ed5ac0245775922328d','127.0.0.1','2026-09-06 09:15:34','__ci_last_regenerate|i:1788686134;csrf_ospos_v4|s:32:\"05dab08b916a280b3c3d96a67dd1bbcd\";'),
('ospos_session:7d937afde0d97e07f08db686d6801798','127.0.0.1','2026-09-07 05:02:13','__ci_last_regenerate|i:1788757333;csrf_ospos_v4|s:32:\"c35da2ed8aa04b5041dff8d41755d1cb\";'),
('ospos_session:7f589e958f25a621e30bbc284937026f','127.0.0.1','2026-09-12 09:24:36','__ci_last_regenerate|i:1789205076;csrf_ospos_v4|s:32:\"18e13744cc41aa32995fe4a18f07400a\";'),
('ospos_session:803186e5811819a067a155128a08b6b9','127.0.0.1','2026-09-12 09:44:50','__ci_last_regenerate|i:1789206290;csrf_ospos_v4|s:32:\"e3f534d3778cd3dc5fd04e44ba1a7c54\";'),
('ospos_session:804064a1ff26bb18ddb3e808fe32e5ad','127.0.0.1','2026-09-07 05:04:13','__ci_last_regenerate|i:1788757453;csrf_ospos_v4|s:32:\"113c8b24cbdf7997bdbf6ac8fc53595a\";'),
('ospos_session:824a7286babafabcef93aaf4c9870416','127.0.0.1','2026-09-11 14:15:21','__ci_last_regenerate|i:1789136121;csrf_ospos_v4|s:32:\"f61d146c56ee4129cf7fa9cac2b2dad4\";'),
('ospos_session:82c444a2e53045fcbd238f3b4bd001b2','127.0.0.1','2026-09-06 09:01:32','__ci_last_regenerate|i:1788685292;csrf_ospos_v4|s:32:\"c537f005f5107d08e8c0f67f2aa3d153\";'),
('ospos_session:83459438739c5fffd2d1706ec10b6b1e','127.0.0.1','2026-09-06 09:13:03','__ci_last_regenerate|i:1788685983;csrf_ospos_v4|s:32:\"fbd9847dcd85048e3e2935e7d3f9cff4\";'),
('ospos_session:83c9477320b0431a7c979fd80c66450c','127.0.0.1','2026-09-07 03:41:42','__ci_last_regenerate|i:1788752502;csrf_ospos_v4|s:32:\"cab3c8c77a74443c81ef80334df50c33\";'),
('ospos_session:84129ffe746316a56fbdfa68683de4f4','127.0.0.1','2026-09-12 09:07:04','__ci_last_regenerate|i:1789204024;csrf_ospos_v4|s:32:\"f59a5ebf73be102ca4cb9cdfea2826a8\";'),
('ospos_session:874da2ac6a017eb0a225f8a78a398c2e','172.20.0.3','2026-09-10 07:04:59','__ci_last_regenerate|i:1789023822;csrf_ospos_v4|s:32:\"bbd287a4de4881a236fd565c98adfa88\";_ci_previous_url|s:33:\"https://ghazi-pos.local/customers\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:0;item_location|s:1:\"1\";sale_id|i:-1;sales_location|i:1;sales_employee|i:1;cash_adjustment_amount|d:0;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:1:{i:1;a:25:{s:7:\"item_id\";s:1:\"1\";s:13:\"item_location\";i:1;s:10:\"stock_name\";s:6:\"Shop 1\";s:4:\"line\";i:1;s:4:\"name\";s:14:\"Coca Cola 1.5L\";s:11:\"item_number\";s:6:\"SKU-12\";s:16:\"attribute_values\";N;s:18:\"attribute_dtvalues\";N;s:11:\"description\";s:0:\"\";s:12:\"serialnumber\";s:0:\"\";s:21:\"allow_alt_description\";s:1:\"0\";s:13:\"is_serialized\";s:1:\"0\";s:8:\"quantity\";s:5:\"6.000\";s:8:\"discount\";s:1:\"0\";s:13:\"discount_type\";i:0;s:8:\"in_stock\";s:7:\"985.000\";s:5:\"price\";s:6:\"180.00\";s:10:\"cost_price\";s:6:\"150.00\";s:5:\"total\";s:9:\"1080.0000\";s:16:\"discounted_total\";s:9:\"1080.0000\";s:12:\"print_option\";i:0;s:10:\"stock_type\";s:1:\"0\";s:9:\"item_type\";s:1:\"0\";s:8:\"hsn_code\";s:0:\"\";s:15:\"tax_category_id\";N;}}sales_customer|i:-1;sales_mode|s:4:\"sale\";sale_type|i:0;sales_payments|a:0:{}recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_supplier|i:-1;'),
('ospos_session:87e368c5d5944292d89cf5d33d3c0526','127.0.0.1','2026-09-12 09:03:34','__ci_last_regenerate|i:1789203814;csrf_ospos_v4|s:32:\"d0d69b25187bd5d7ed3fe4de2a67368b\";'),
('ospos_session:8819aae71be36dbe260b18e6f26ed583','127.0.0.1','2026-09-06 09:14:04','__ci_last_regenerate|i:1788686044;csrf_ospos_v4|s:32:\"14c674b2927b8d9348229cec40bef613\";'),
('ospos_session:882a17c63c6fe3cc71d0566a6d4d2394','127.0.0.1','2026-09-06 20:54:27','__ci_last_regenerate|i:1788728067;csrf_ospos_v4|s:32:\"e389224882234ff6464a2b5e6bf2198e\";'),
('ospos_session:88d140a6aad686cc810a7a50c0577b02','127.0.0.1','2026-09-10 07:02:48','__ci_last_regenerate|i:1789023768;csrf_ospos_v4|s:32:\"71b6a1323efd9a17e4bd927f4ae6b55a\";'),
('ospos_session:891c279e95c0d0d3d3229348d63b320b','127.0.0.1','2026-09-12 09:35:08','__ci_last_regenerate|i:1789205708;csrf_ospos_v4|s:32:\"5de3a337396c8029a9a709dc2094743e\";'),
('ospos_session:895cebd504257ddd1e2d8f2df8b84889','127.0.0.1','2026-09-06 09:04:02','__ci_last_regenerate|i:1788685442;csrf_ospos_v4|s:32:\"259def7e426b357fb92f614ae451bfac\";'),
('ospos_session:8a833cd29050303c3974c8058c6367e4','127.0.0.1','2026-09-11 14:15:51','__ci_last_regenerate|i:1789136151;csrf_ospos_v4|s:32:\"5f076362c2361800b6706a21251b87ec\";'),
('ospos_session:8a964f0709ea23fbca716e4e7c5da2cd','127.0.0.1','2026-09-12 09:15:05','__ci_last_regenerate|i:1789204505;csrf_ospos_v4|s:32:\"5399e03b6b229ead0fe85814c5875390\";'),
('ospos_session:8c315e42f5c4427e3edcab3ec16da2d8','127.0.0.1','2026-09-06 14:56:19','__ci_last_regenerate|i:1788706579;csrf_ospos_v4|s:32:\"ec9caf58c91dcc4a700616302eedd7c7\";'),
('ospos_session:8dfdc19630cd4b2d72cc37b76d7c00f1','127.0.0.1','2026-09-06 09:08:33','__ci_last_regenerate|i:1788685713;csrf_ospos_v4|s:32:\"c6cd90fcfe203a3b2f627483e55531ed\";'),
('ospos_session:8e0055e7d3e21aa80ab39a8d70a1c774','127.0.0.1','2026-09-07 05:03:13','__ci_last_regenerate|i:1788757393;csrf_ospos_v4|s:32:\"eef631cf4abb2fe504c97c4e5371ccf8\";'),
('ospos_session:8ea94a6c9f9309cd6a70b20a5214eb65','127.0.0.1','2026-09-07 00:18:19','__ci_last_regenerate|i:1788740299;csrf_ospos_v4|s:32:\"7a879f54a253a3662fe303cfef839ea6\";'),
('ospos_session:8f36353e8179b71cd763d5a1dfa4631f','127.0.0.1','2026-09-10 07:03:48','__ci_last_regenerate|i:1789023828;csrf_ospos_v4|s:32:\"99834f6a937c6df8ddafad355dd984fb\";'),
('ospos_session:91a0939be1e84af38667dc4df658346c','127.0.0.1','2026-09-10 07:01:18','__ci_last_regenerate|i:1789023678;csrf_ospos_v4|s:32:\"f079c4daddda6479e05c4e80e06cde8f\";'),
('ospos_session:91f8de20a81dc31d8446218d3eba13f9','127.0.0.1','2026-09-06 16:29:19','__ci_last_regenerate|i:1788712159;csrf_ospos_v4|s:32:\"df6beb89de3072d33655c45bccd637c6\";'),
('ospos_session:92a499c978845acccb0366792631502b','127.0.0.1','2026-09-06 15:57:12','__ci_last_regenerate|i:1788710232;csrf_ospos_v4|s:32:\"907e22b42083e3afcb496059cc52e553\";'),
('ospos_session:92a9deecd7064c17c961fa64876bd5fe','127.0.0.1','2026-09-12 09:32:07','__ci_last_regenerate|i:1789205527;csrf_ospos_v4|s:32:\"c4a1dae01824a8a9df32f8d90c06ddeb\";'),
('ospos_session:92d8824e7e1285485293d922edf4ed3f','127.0.0.1','2026-09-12 09:23:36','__ci_last_regenerate|i:1789205016;csrf_ospos_v4|s:32:\"7d9160f7a72de4bac990f8e18c807bc4\";'),
('ospos_session:93687b1d341c80bef895a96dcd867e4a','127.0.0.1','2026-09-06 09:06:32','__ci_last_regenerate|i:1788685592;csrf_ospos_v4|s:32:\"53d894655ffeb22e70bad8d53545ace6\";'),
('ospos_session:944a1a9e4f5870a72dc123d01b904de1','127.0.0.1','2026-09-06 16:46:33','__ci_last_regenerate|i:1788713193;csrf_ospos_v4|s:32:\"e6fe8a4f0266e6540ef634095a836572\";'),
('ospos_session:9558b180d84a6e2883fb2b97016d2cca','127.0.0.1','2026-09-06 08:57:01','__ci_last_regenerate|i:1788685021;csrf_ospos_v4|s:32:\"a9312a0fd511be513d0d47d1d1097b3b\";'),
('ospos_session:96a5874ce72e09a5feebd5f467219ae0','127.0.0.1','2026-09-12 09:01:03','__ci_last_regenerate|i:1789203663;csrf_ospos_v4|s:32:\"5a4d180897f37f310ba7ed1113dd1011\";'),
('ospos_session:974a41cc6fbb111c490e1e1625166602','127.0.0.1','2026-09-06 09:01:02','__ci_last_regenerate|i:1788685262;csrf_ospos_v4|s:32:\"2a26299bf688ec93165f983dc9711e11\";'),
('ospos_session:98d948c6a63e9de84f5a0f4caa761380','127.0.0.1','2026-09-06 17:09:11','__ci_last_regenerate|i:1788714551;csrf_ospos_v4|s:32:\"863789f61a58416407882d9bc5818b55\";'),
('ospos_session:997ef0fe0545dcfb6252e225b1fe6230','127.0.0.1','2026-09-07 05:01:43','__ci_last_regenerate|i:1788757303;csrf_ospos_v4|s:32:\"a46ac32b6fb6343c9275f9d6fea38c4e\";'),
('ospos_session:9ad2688df1d1fc941a2f3bf0648e9005','127.0.0.1','2026-09-12 09:26:37','__ci_last_regenerate|i:1789205197;csrf_ospos_v4|s:32:\"acbf07edc7af700a9ebfa7ae5c6bb3ff\";'),
('ospos_session:9b0bef90fd3f73fe9b82a429cf83ffb4','127.0.0.1','2026-09-06 17:49:48','__ci_last_regenerate|i:1788716988;csrf_ospos_v4|s:32:\"e165cd313a7b56688e0c20e300e4e2f5\";'),
('ospos_session:9c9ba0e379aff5d283f5463995c18bdf','127.0.0.1','2026-09-06 08:56:01','__ci_last_regenerate|i:1788684961;csrf_ospos_v4|s:32:\"377548b04b965044f25cc8b2b8fc013f\";'),
('ospos_session:9cc8bf28d3afb6c98653d8cb7911ef3c','127.0.0.1','2026-09-06 08:53:31','__ci_last_regenerate|i:1788684811;csrf_ospos_v4|s:32:\"120587da3a035d3cc25e9a10a5152c6a\";'),
('ospos_session:9d170f2cc0229973822cdc2ba22acbf2','127.0.0.1','2026-09-06 08:49:00','__ci_last_regenerate|i:1788684540;csrf_ospos_v4|s:32:\"e49239aac939425d45e3817293e4629b\";'),
('ospos_session:9eeadf30987100179a7039a9109c79f4','127.0.0.1','2026-09-06 15:27:44','__ci_last_regenerate|i:1788708464;csrf_ospos_v4|s:32:\"43bb83fa0ae44162c8ae7971fbde3b42\";'),
('ospos_session:a16ab64467e5b6acd27f297d057fd693','127.0.0.1','2026-09-06 08:51:00','__ci_last_regenerate|i:1788684660;csrf_ospos_v4|s:32:\"5470deacf1bada2362ea28b90f16b523\";'),
('ospos_session:a176add8732dc2ff8c71ab2d12fe74db','127.0.0.1','2026-09-12 09:40:50','__ci_last_regenerate|i:1789206050;csrf_ospos_v4|s:32:\"f5a2525180e43f5bcde99fb8d5a23c42\";'),
('ospos_session:a3b164fd54d8061e25ff15d62b56b89e','127.0.0.1','2026-09-07 04:24:50','__ci_last_regenerate|i:1788755090;csrf_ospos_v4|s:32:\"89efdd43e28ec87a91d190a84109ac56\";'),
('ospos_session:a40e6e687e296b951152b289f8ed0344','127.0.0.1','2026-09-06 09:07:33','__ci_last_regenerate|i:1788685653;csrf_ospos_v4|s:32:\"3eca76ee4fe0fb42fb0c8988203c5f6b\";'),
('ospos_session:a41857d9ea86b6e8acbe1da702ca0cb1','127.0.0.1','2026-09-12 09:19:36','__ci_last_regenerate|i:1789204776;csrf_ospos_v4|s:32:\"a5955744133b63ae0f7a1a69faf7f17c\";'),
('ospos_session:a44fd1d4a17bc2026728e504fef29c93','127.0.0.1','2026-09-06 08:46:30','__ci_last_regenerate|i:1788684390;csrf_ospos_v4|s:32:\"22e4f75c60d4fe8b7505a8e14dcb8db6\";'),
('ospos_session:a7218637b8112d282fbd13eb14af2145','127.0.0.1','2026-09-06 09:11:03','__ci_last_regenerate|i:1788685863;csrf_ospos_v4|s:32:\"502c6ef56f841a4639a3425b0ef36336\";'),
('ospos_session:a87e9d2fd1582d14d7892b680c8ac580','127.0.0.1','2026-09-10 07:01:48','__ci_last_regenerate|i:1789023708;csrf_ospos_v4|s:32:\"bec445343a132ab27aab046a5700f7ad\";'),
('ospos_session:a912b28955c9fbd1172a0b2ddbadb685','127.0.0.1','2026-09-12 09:18:05','__ci_last_regenerate|i:1789204685;csrf_ospos_v4|s:32:\"caa7b041e205ce1548a5b5fe66193484\";'),
('ospos_session:aa00053b10121f8eb0328f146a6581ea','127.0.0.1','2026-09-06 08:57:31','__ci_last_regenerate|i:1788685051;csrf_ospos_v4|s:32:\"0ac6ff26a253793f5a1a1d9fe14f61aa\";'),
('ospos_session:aaca293f78be35c30754342307775d16','127.0.0.1','2026-09-11 14:16:51','__ci_last_regenerate|i:1789136211;csrf_ospos_v4|s:32:\"31883785a13ff7f0cd916c28cf8cbb7c\";'),
('ospos_session:ab6ff4311ee3aeabf7e7ebf5c596e8fb','127.0.0.1','2026-09-12 09:10:04','__ci_last_regenerate|i:1789204204;csrf_ospos_v4|s:32:\"d9597aa3021593d0a4ccad7f2ad8f186\";'),
('ospos_session:abf14c4b4da322dc5986aa9c00a579d0','127.0.0.1','2026-09-12 09:43:50','__ci_last_regenerate|i:1789206230;csrf_ospos_v4|s:32:\"474ee28c479a7d87abe3af3f45c0da37\";'),
('ospos_session:afc32e6daeb53c40b5100373b45731a5','127.0.0.1','2026-09-06 08:51:30','__ci_last_regenerate|i:1788684690;csrf_ospos_v4|s:32:\"8829a2a3624a08cd9284111cdb44adb0\";'),
('ospos_session:b089e1cd375d016cb52e067e5e39ff52','127.0.0.1','2026-09-12 09:41:20','__ci_last_regenerate|i:1789206080;csrf_ospos_v4|s:32:\"1555ce7bb1bfd172c587536ef107f66d\";'),
('ospos_session:b1cb41887cc2a253362f01a770e782b3','127.0.0.1','2026-09-06 08:58:31','__ci_last_regenerate|i:1788685111;csrf_ospos_v4|s:32:\"7622da6a9fc250d337af0355f4526692\";'),
('ospos_session:b35590d3135cf610a496bb742fdcbbd0','127.0.0.1','2026-09-06 16:23:20','__ci_last_regenerate|i:1788711800;csrf_ospos_v4|s:32:\"91bfe04db86a9a03602f42f496550e76\";'),
('ospos_session:b7fe6dd233b41220b6ef2891d1aeb15e','127.0.0.1','2026-09-07 05:04:43','__ci_last_regenerate|i:1788757483;csrf_ospos_v4|s:32:\"4de6339f169e9be9ecbf0608068628e9\";'),
('ospos_session:b8381d3a55de45213c130c3290455756','127.0.0.1','2026-09-07 05:08:44','__ci_last_regenerate|i:1788757724;csrf_ospos_v4|s:32:\"528507df9facc92ce78bc900a0324513\";'),
('ospos_session:baecdc2037c58ce51f771a974e2ee60b','127.0.0.1','2026-09-06 08:45:00','__ci_last_regenerate|i:1788684300;csrf_ospos_v4|s:32:\"f8d4f6246da5b224a4bd42d1a3720db7\";'),
('ospos_session:bb34e3eb77033d3057bf06e9a6a34d65','127.0.0.1','2026-09-06 11:52:27','__ci_last_regenerate|i:1788695547;csrf_ospos_v4|s:32:\"660a816bbde5dba8be44de75baa3357d\";'),
('ospos_session:bc178e358f72a2ca50a9f2993b9dfbdf','127.0.0.1','2026-09-07 00:23:19','__ci_last_regenerate|i:1788740599;csrf_ospos_v4|s:32:\"160a4802cd2df64e59ba475710f53b9e\";'),
('ospos_session:be3f982a394b615ad0d1b98764bc4882','127.0.0.1','2026-09-12 09:37:08','__ci_last_regenerate|i:1789205828;csrf_ospos_v4|s:32:\"cf8d8ef01231e0e3dde092d67f0e9462\";'),
('ospos_session:be4b0640e58db235c1ce96680e4d1e3f','127.0.0.1','2026-09-12 09:38:38','__ci_last_regenerate|i:1789205918;csrf_ospos_v4|s:32:\"d8216e5d7fcd5d2fa4678b4b4a934675\";'),
('ospos_session:bec0411c312b7cac94b1c5b26953b889','127.0.0.1','2026-09-06 08:44:29','__ci_last_regenerate|i:1788684269;csrf_ospos_v4|s:32:\"25cb276fa91e2ad75cba4cde1891e7b6\";'),
('ospos_session:bf49bbe5878cbf1632afc3c44cc12095','127.0.0.1','2026-09-06 09:02:32','__ci_last_regenerate|i:1788685352;csrf_ospos_v4|s:32:\"569f01858d1ead498ec577866ca022aa\";'),
('ospos_session:bf4c67ce46f623e713e12efb2d5029e2','127.0.0.1','2026-09-06 14:13:24','__ci_last_regenerate|i:1788704004;csrf_ospos_v4|s:32:\"7a386923f4de553b29d078930da1e16c\";'),
('ospos_session:bf8271d2c63376a69752b82f8d2c7f03','127.0.0.1','2026-09-07 02:25:18','__ci_last_regenerate|i:1788747918;csrf_ospos_v4|s:32:\"bbdc552b21002d7473e0e9b487fb4498\";'),
('ospos_session:bf894ac69f295c4ab861c8a6a16b15ff','127.0.0.1','2026-09-12 09:25:06','__ci_last_regenerate|i:1789205106;csrf_ospos_v4|s:32:\"08c5cf8d7e37fa66db53fe31c221e775\";'),
('ospos_session:bfbb8145695a397f4a0fafe3bda582da','127.0.0.1','2026-09-07 05:06:44','__ci_last_regenerate|i:1788757604;csrf_ospos_v4|s:32:\"efa8889ae27c0354f446cc0bb48e67d5\";'),
('ospos_session:c16820c2dd00a0bb763b149add13da2a','127.0.0.1','2026-09-07 05:10:44','__ci_last_regenerate|i:1788757844;csrf_ospos_v4|s:32:\"530043349e1f6ec7526076d3826ad020\";'),
('ospos_session:c343066fe47c5c3e1042e02ebb802e92','127.0.0.1','2026-09-12 09:45:51','__ci_last_regenerate|i:1789206351;csrf_ospos_v4|s:32:\"2e9eda0684f4645f9f9d17aaf82d67e3\";'),
('ospos_session:c4d6be1ebf56d015cb7b53e9f7d27935','127.0.0.1','2026-09-12 09:20:36','__ci_last_regenerate|i:1789204836;csrf_ospos_v4|s:32:\"b332b0f8030d1295917c2aeb7d1b3312\";'),
('ospos_session:c5823d2f278aed949a20200ff8967b47','127.0.0.1','2026-09-06 09:14:34','__ci_last_regenerate|i:1788686074;csrf_ospos_v4|s:32:\"f4041d5aab9047ab4385c2c815c292f6\";'),
('ospos_session:c7177d45fd4e14bf5bc5a6c83c397683','127.0.0.1','2026-09-12 09:44:20','__ci_last_regenerate|i:1789206260;csrf_ospos_v4|s:32:\"84073954085241b685ccef0174edd82a\";'),
('ospos_session:c81bf4dfb1c8a21d6af4ab07be3f34dd','127.0.0.1','2026-09-06 21:54:20','__ci_last_regenerate|i:1788731660;csrf_ospos_v4|s:32:\"d48b1349e93e4827c34b098f78d0b3e9\";'),
('ospos_session:c9a05e65fcac663156a9a3e2e3de3a92','127.0.0.1','2026-09-11 14:16:21','__ci_last_regenerate|i:1789136181;csrf_ospos_v4|s:32:\"f4de1439fcf8a805b8e159635e67306b\";'),
('ospos_session:cb699b50496eece362b7daf1cf70b62b','127.0.0.1','2026-09-12 09:20:06','__ci_last_regenerate|i:1789204806;csrf_ospos_v4|s:32:\"3fb64a049f7aafceb5902e6640db0d4a\";'),
('ospos_session:cdbec793507b258f1a941404ae0ae815','127.0.0.1','2026-09-12 09:40:20','__ci_last_regenerate|i:1789206020;csrf_ospos_v4|s:32:\"0a2fa1911a540503ad0f6b4f4dd13208\";'),
('ospos_session:ce0f7696da11dde76fcde760d81f2db8','127.0.0.1','2026-09-12 09:46:21','__ci_last_regenerate|i:1789206381;csrf_ospos_v4|s:32:\"b21fc953735b1605a8aa70c26f312c26\";'),
('ospos_session:ce6629d430c46da286a3c6ac81176b66','127.0.0.1','2026-09-12 09:11:05','__ci_last_regenerate|i:1789204265;csrf_ospos_v4|s:32:\"0486267af68a2c8198f963e7370325e9\";'),
('ospos_session:cff598661eb9754d6871ad113955bb48','127.0.0.1','2026-09-12 09:13:05','__ci_last_regenerate|i:1789204385;csrf_ospos_v4|s:32:\"d1c76c8dd3feab724303eb662c96ed58\";'),
('ospos_session:d0114e61210dcf8b5682e2122095d740','127.0.0.1','2026-09-07 05:09:44','__ci_last_regenerate|i:1788757784;csrf_ospos_v4|s:32:\"d51d44ccd05644fb6f52749072f5ce06\";'),
('ospos_session:d095b92b2e164279b37fd51ade30fe8c','127.0.0.1','2026-09-07 05:01:13','__ci_last_regenerate|i:1788757273;csrf_ospos_v4|s:32:\"c5d9275d5a5bd3eb980c7f9799a4ff5c\";'),
('ospos_session:d0d628ef2194c09ec857bd862506b87f','127.0.0.1','2026-09-12 09:30:07','__ci_last_regenerate|i:1789205407;csrf_ospos_v4|s:32:\"fb0adbaf8636f2ea34478017c9a33d59\";'),
('ospos_session:d16767fa387d8ffae213a1927876c0ed','127.0.0.1','2026-09-12 09:08:34','__ci_last_regenerate|i:1789204114;csrf_ospos_v4|s:32:\"464560b5b86e545585b9aaa8e84ff39c\";'),
('ospos_session:d3b7b260a915f16b7bc455a15e987385','127.0.0.1','2026-09-12 09:46:51','__ci_last_regenerate|i:1789206411;csrf_ospos_v4|s:32:\"4b7c47dacec086344b788753f42a6c6a\";'),
('ospos_session:d56828d7522b78d28c1339239593049d','127.0.0.1','2026-09-06 08:45:30','__ci_last_regenerate|i:1788684330;csrf_ospos_v4|s:32:\"93b4e11bdf8f9d07689e3cbaf1fb1013\";'),
('ospos_session:d728dc293673aa56367d8b75caa7851a','127.0.0.1','2026-09-06 09:09:33','__ci_last_regenerate|i:1788685773;csrf_ospos_v4|s:32:\"65b7fee4d99bdf6279a83bb9c0e98e01\";'),
('ospos_session:d7645ccfe11a2b99ed198135b9aa3ba0','127.0.0.1','2026-09-12 09:26:07','__ci_last_regenerate|i:1789205167;csrf_ospos_v4|s:32:\"7df2e33522d278f4d2a103551f0efa76\";'),
('ospos_session:d78b329b85350f361cdd7ffefe8c1970','127.0.0.1','2026-09-12 09:13:35','__ci_last_regenerate|i:1789204415;csrf_ospos_v4|s:32:\"a887ff99a05fd833bf7f5b069e0ec2b6\";'),
('ospos_session:d88733adb430908a943a45b4d0370614','127.0.0.1','2026-09-12 09:34:38','__ci_last_regenerate|i:1789205678;csrf_ospos_v4|s:32:\"b34f241f70053d29faa96154e5a4fe4c\";'),
('ospos_session:d900954d88a52e68aeea5f8d670179fd','127.0.0.1','2026-09-10 06:57:47','__ci_last_regenerate|i:1789023467;csrf_ospos_v4|s:32:\"8f47d818e9f3e762461a471cb3f269de\";'),
('ospos_session:d90b0fa2de80d878fe88fa91734b8f4d','127.0.0.1','2026-09-12 09:39:20','__ci_last_regenerate|i:1789205960;csrf_ospos_v4|s:32:\"eb8386f57d6ba8d72505d4a25a62390e\";'),
('ospos_session:d9db778ef71f410fedaeac9e9cedebfe','127.0.0.1','2026-09-06 11:11:14','__ci_last_regenerate|i:1788693074;csrf_ospos_v4|s:32:\"240c402bf1edf40ca3f21cfb4f4126ea\";'),
('ospos_session:d9e18d8604312cff954f2a1ae2d3ad55','127.0.0.1','2026-09-06 12:11:59','__ci_last_regenerate|i:1788696719;csrf_ospos_v4|s:32:\"a574eeaddc75ce31a78195f1b6a644d3\";'),
('ospos_session:d9f67457bd82eafd7fba082f803b268f','127.0.0.1','2026-09-11 14:17:51','__ci_last_regenerate|i:1789136271;csrf_ospos_v4|s:32:\"714989c9d99199f3e32767dba135b7ae\";'),
('ospos_session:db3e9f62636d3ae89d6af2db4b791e15','127.0.0.1','2026-09-12 09:30:37','__ci_last_regenerate|i:1789205437;csrf_ospos_v4|s:32:\"45507c82889244e852b8d89654c4e50b\";'),
('ospos_session:dc9f9e21baf0e7e51951c9614df41da2','127.0.0.1','2026-09-12 09:22:06','__ci_last_regenerate|i:1789204926;csrf_ospos_v4|s:32:\"80b0f2a07973158c8d5b6d9c24a25405\";'),
('ospos_session:ddb98709bbd892e713647e64e8539e6f','127.0.0.1','2026-09-07 02:53:26','__ci_last_regenerate|i:1788749606;csrf_ospos_v4|s:32:\"8a4dda9482927a259fb672fee32a316b\";'),
('ospos_session:de1ed274978e3de3004b39cc4d5ff42c','127.0.0.1','2026-09-12 09:09:04','__ci_last_regenerate|i:1789204144;csrf_ospos_v4|s:32:\"c776586f980060e821f73a791276cde1\";'),
('ospos_session:de5fdd80e8480493b29edc530a4fe170','127.0.0.1','2026-09-12 09:09:34','__ci_last_regenerate|i:1789204174;csrf_ospos_v4|s:32:\"05aa4743dbbc9dcd0838582cb26e419e\";'),
('ospos_session:e0d80f856860d64c1dc346f955eceb3a','127.0.0.1','2026-09-10 07:05:18','__ci_last_regenerate|i:1789023918;csrf_ospos_v4|s:32:\"c8175e56156cc8595abdc48e79d2a1fa\";'),
('ospos_session:e16050f5e714f25cb112b1a0e30e566f','127.0.0.1','2026-09-07 05:08:14','__ci_last_regenerate|i:1788757694;csrf_ospos_v4|s:32:\"509dbbe0210e168b2fd14836bb014b7f\";'),
('ospos_session:e1d863d2a97676e2253e7d7de2f8f1cc','127.0.0.1','2026-09-06 14:33:19','__ci_last_regenerate|i:1788705199;csrf_ospos_v4|s:32:\"7d674ec86b57f646b8bd227a421b6875\";'),
('ospos_session:e215eea965774f86240ae23d053f7603','127.0.0.1','2026-09-12 09:18:36','__ci_last_regenerate|i:1789204715;csrf_ospos_v4|s:32:\"2901b46c0fa04cb216fac57871af6628\";'),
('ospos_session:e33a98b202ed0cbf6fc49da26b5c4aec','127.0.0.1','2026-09-12 09:41:50','__ci_last_regenerate|i:1789206110;csrf_ospos_v4|s:32:\"6c128dc0639428895bf9c4fe7e93abb2\";'),
('ospos_session:e433f9e617d373d21ea3c33c70191892','127.0.0.1','2026-09-12 09:02:03','__ci_last_regenerate|i:1789203723;csrf_ospos_v4|s:32:\"ad5b812eee6fef28191659f33c9c095e\";'),
('ospos_session:e4427598e34e7cb91547df9a770688f9','127.0.0.1','2026-09-06 09:05:32','__ci_last_regenerate|i:1788685532;csrf_ospos_v4|s:32:\"34eaffac2e5946c77424bdd7681f3be5\";'),
('ospos_session:e8832a5c5b6088784c218da8ee662c01','127.0.0.1','2026-09-06 08:55:31','__ci_last_regenerate|i:1788684931;csrf_ospos_v4|s:32:\"4e7c74b9cd7919aa204abdbb874144ae\";'),
('ospos_session:e9a8f98a89f9ea4ddefe0131fe969e06','127.0.0.1','2026-09-12 09:19:06','__ci_last_regenerate|i:1789204746;csrf_ospos_v4|s:32:\"a20f17746c789c4d43f62ceae4d01439\";'),
('ospos_session:ea0a333f112e737b50d0072f6c18e8f6','127.0.0.1','2026-09-12 09:42:50','__ci_last_regenerate|i:1789206170;csrf_ospos_v4|s:32:\"3da044b70923b0aeb72aa977e0a4eb62\";'),
('ospos_session:edd53b1388cc21ce35cbe1a36f81fb7e','127.0.0.1','2026-09-06 08:46:00','__ci_last_regenerate|i:1788684360;csrf_ospos_v4|s:32:\"9e823ee67417ebf2933837d60d1de2e7\";'),
('ospos_session:eefb0f5aea16137b4599efae44947229','127.0.0.1','2026-09-06 09:06:02','__ci_last_regenerate|i:1788685562;csrf_ospos_v4|s:32:\"45e5cc754afe2fdfecab0ece54350f24\";'),
('ospos_session:ef47152c037fd8ce151679858383279b','127.0.0.1','2026-09-06 08:48:00','__ci_last_regenerate|i:1788684480;csrf_ospos_v4|s:32:\"875cf9ee80a0f2854b7b8a486aa05d86\";'),
('ospos_session:f213f7a309774d37b0949add519e8a5e','127.0.0.1','2026-09-06 08:50:00','__ci_last_regenerate|i:1788684600;csrf_ospos_v4|s:32:\"c204394301e883c9fc50c894be970387\";'),
('ospos_session:f2819b975749a244931de5d030b887a6','127.0.0.1','2026-09-12 09:33:08','__ci_last_regenerate|i:1789205588;csrf_ospos_v4|s:32:\"5a7ff74b7cc218b14c8b2f7228844e42\";'),
('ospos_session:f5435c8cf9c5855f55cd593504354f51','127.0.0.1','2026-09-06 18:57:45','__ci_last_regenerate|i:1788721065;csrf_ospos_v4|s:32:\"8d4f42cfe3bf3d39cd05c7f918635fa8\";'),
('ospos_session:f890ef99d388cc3974df9557f9ec8b6a','127.0.0.1','2026-09-07 04:53:32','__ci_last_regenerate|i:1788756812;csrf_ospos_v4|s:32:\"b424c06b7a5df23c1e5af411cf55fba2\";'),
('ospos_session:f914155c133f3b6fd166a6d987ab73e9','127.0.0.1','2026-09-06 09:03:32','__ci_last_regenerate|i:1788685412;csrf_ospos_v4|s:32:\"cb33e6f6db2a0e0d9dbac44153317e27\";'),
('ospos_session:fa4b0295c0fefd68e791cc6511dd7b69','127.0.0.1','2026-09-12 09:27:07','__ci_last_regenerate|i:1789205227;csrf_ospos_v4|s:32:\"d3b168ae4eb101ded6bb42ae404dc79c\";'),
('ospos_session:fc5edfebf190fe6032b9e2bcc22c2802','127.0.0.1','2026-09-10 07:04:18','__ci_last_regenerate|i:1789023858;csrf_ospos_v4|s:32:\"bac94c7ed80a88a378f2aeef10d8ba56\";'),
('ospos_session:ff4adf8644c87873590c85ffff54e7b1','127.0.0.1','2026-09-06 09:13:33','__ci_last_regenerate|i:1788686013;csrf_ospos_v4|s:32:\"b2b852125c22f49bcded9304b05335c4\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'Shop 1',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(3,'FFC','FFC Acord','PK123EEF1231029831283','',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-12  9:48:03
