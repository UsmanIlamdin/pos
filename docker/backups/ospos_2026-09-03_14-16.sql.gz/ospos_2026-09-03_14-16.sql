/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','number'),
('barcode_first_row','name'),
('barcode_font','fontawesome-webfont.ttf'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','1'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C128'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','0'),
('category_dropdown','0'),
('company','Ghazi Trader'),
('company_logo','pngegg.png'),
('country_codes','pk'),
('currency_code','PKR'),
('currency_decimals','2'),
('currency_symbol','Rs'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format',''),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category','Standard'),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','1'),
('dinner_table_enable','0'),
('email','usman@gmail.com'),
('email_receipt_check_behaviour','never'),
('enforce_privacy','0'),
('fax',''),
('financial_year','1'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','jpg,gif,png'),
('image_max_height','480'),
('image_max_size','128'),
('image_max_width','640'),
('include_hsn','0'),
('invoice_default_comments','This is a default comment'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','0'),
('last_used_quote_number','1'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form','floating_labels'),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('phone','+923015804375'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','never'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','10'),
('receipt_show_company_name','1'),
('receipt_show_description','0'),
('receipt_show_serialnumber','0'),
('receipt_show_taxes','0'),
('receipt_show_tax_ind','0'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_short'),
('receiving_calculate_average_price','0'),
('recv_invoice_format','{CO}'),
('return_policy','Items can be exchange only after 7 days in unworn codition'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id',''),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','Asia/Karachi'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Company','DROPDOWN',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,NULL,NULL,NULL,NULL),
(2,1,NULL,NULL,NULL,NULL),
(2,1,3,NULL,1,NULL),
(2,1,3,8,NULL,NULL),
(1,1,1,8,NULL,NULL),
(2,1,3,9,NULL,NULL),
(1,1,1,9,NULL,NULL),
(2,1,3,10,NULL,NULL),
(1,1,1,10,NULL,NULL),
(2,1,3,11,NULL,NULL),
(1,1,1,11,NULL,NULL),
(1,1,1,12,NULL,NULL),
(2,1,3,12,NULL,NULL),
(1,1,1,13,NULL,NULL),
(1,1,1,14,NULL,NULL),
(1,1,1,15,NULL,NULL),
(1,1,1,16,NULL,NULL),
(1,1,1,17,NULL,NULL),
(2,1,3,NULL,NULL,'1-3'),
(1,1,1,NULL,NULL,'1-1'),
(1,1,1,18,NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,'FFC',NULL,NULL),
(2,'FFC2',NULL,NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-08-28 17:53:43','2026-08-28 17:53:43',12000.00,2000.00,1,10000.00,3000.00,0.00,0.00,'',1,1,0,1000.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(3,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-02 14:38:53',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('usman','$2y$10$7pp9sA73yJ0vDkH2JSBYL.VyOcJNgjdOT7AkAlzmdUtatts/EVbZa',1,0,2,'','');
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
INSERT INTO `ospos_expense_categories` VALUES
(1,'FFC','New Expens',0);
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
INSERT INTO `ospos_giftcards` VALUES
('2026-09-02 14:42:34',1,'455413123121312',50.00,0,3);
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_Shop',1,'--'),
('items_Warehouse',1,'--'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_Shop',1,'--'),
('receivings_Warehouse',1,'--'),
('reports',1,'home'),
('reports_categories',1,'--'),
('reports_customers',1,'--'),
('reports_discounts',1,'--'),
('reports_employees',1,'--'),
('reports_expenses_categories',1,'--'),
('reports_inventory',1,'--'),
('reports_items',1,'--'),
('reports_payments',1,'--'),
('reports_receivings',1,'--'),
('reports_sales',1,'--'),
('reports_sales_taxes',1,'--'),
('reports_suppliers',1,'--'),
('reports_taxes',1,'--'),
('sales',1,'home'),
('sales_change_price',1,'--'),
('sales_delete',1,'--'),
('sales_Shop',1,'--'),
('sales_Warehouse',1,'--'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',1,20.000),
(2,1,1,'2026-08-28 16:46:50','Manual Edit of Quantity',2,10.000),
(3,1,1,'2026-08-28 16:47:27','POS 1',1,-1.000),
(4,1,1,'2026-08-28 16:50:56','Manual Edit of Quantity',2,-10.000),
(5,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',1,80.000),
(6,2,1,'2026-08-28 16:53:21','Manual Edit of Quantity',2,0.000),
(7,1,1,'2026-08-28 16:54:53','POS 2',1,-1.000),
(8,1,1,'2026-08-28 16:57:10','POS 3',1,-1.000),
(9,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',1,100.000),
(10,3,1,'2026-08-28 17:52:02','Manual Edit of Quantity',2,0.000),
(11,3,1,'2026-08-28 17:57:35','RECV 1',1,6000.000),
(12,3,1,'2026-08-30 10:48:38','Manual Edit of Quantity',2,40.000),
(13,2,1,'2026-08-30 10:49:11','Manual Edit of Quantity',2,20.000),
(14,1,1,'2026-08-30 10:50:47','Manual Edit of Quantity',2,12.000),
(15,3,1,'2026-08-30 10:51:09','Manual Edit of Quantity',1,-5500.000),
(16,1,1,'2026-09-02 14:39:45','POS 4',2,-10.000),
(17,1,1,'2026-09-02 14:41:47','POS 5',1,5.000),
(18,1,1,'2026-09-02 14:44:04','POS 6',1,-5.000),
(19,2,1,'2026-09-02 15:42:27','POS 7',1,-1.000),
(20,1,1,'2026-09-03 10:29:18','',1,-10.000),
(21,1,1,'2026-09-03 10:29:28','Manual Edit of Quantity',1,-7.000),
(22,1,1,'2026-09-03 10:30:51','Manual Edit of Quantity',1,20.000),
(23,3,1,'2026-09-03 10:43:16','POS 8',1,-4.000),
(24,1,1,'2026-09-03 10:43:16','POS 8',1,-2.000),
(25,3,1,'2026-09-03 10:52:30','POS 9',1,-4.000),
(26,1,1,'2026-09-03 10:52:30','POS 9',1,-2.000),
(27,3,1,'2026-09-03 10:53:11','POS 10',1,-4.000),
(28,1,1,'2026-09-03 10:53:11','POS 10',1,-2.000),
(29,3,1,'2026-09-03 10:55:28','POS 11',1,-4.000),
(30,1,1,'2026-09-03 10:55:28','POS 11',1,-2.000),
(31,1,1,'2026-09-03 10:59:48','POS 12',1,-2.000),
(32,3,1,'2026-09-03 10:59:48','POS 12',1,-4.000),
(33,1,1,'2026-09-03 11:02:35','POS 13',1,-4.000),
(34,1,1,'2026-09-03 11:11:17','POS 14',2,-4.000),
(35,1,1,'2026-09-03 11:17:09','POS 15',1,-4.000),
(36,1,1,'2026-09-03 11:20:59','POS 16',1,-4.000),
(37,1,1,'2026-09-03 18:11:54','Manual Edit of Quantity',1,14.000),
(38,1,1,'2026-09-03 18:11:54','Manual Edit of Quantity',2,14.000),
(39,1,1,'2026-09-03 18:18:07','POS 17',1,-8.000),
(40,2,1,'2026-09-03 18:18:07','POS 17',1,-6.000),
(41,1,1,'2026-09-03 18:20:44','Manual Edit of Quantity',1,396.000),
(42,1,1,'2026-09-03 18:20:44','Manual Edit of Quantity',2,108.000),
(43,2,1,'2026-09-03 18:20:56','Manual Edit of Quantity',1,657.000),
(44,2,1,'2026-09-03 18:20:56','Manual Edit of Quantity',2,180.000),
(45,3,1,'2026-09-03 18:21:04','Manual Edit of Quantity',2,360.000),
(46,2,1,'2026-09-03 19:05:38','POS 18',1,-1.000),
(47,1,1,'2026-09-03 19:05:38','POS 18',1,-4.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
INSERT INTO `ospos_item_kit_items` VALUES
(2,1,4.000,2),
(2,2,1.000,1);
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
INSERT INTO `ospos_item_kits` VALUES
(2,'SKU-12',' Ramzan Offer','Buy 1 Pack of Cock Get 1 1L Cock Free ',0,10.00,0,0,1);
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,396.000),
(1,2,120.000),
(2,1,729.000),
(2,2,200.000),
(3,1,580.000),
(3,2,400.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Cock Half Leter','Beverage',2,'123','',20.00,20.00,1.000,200.000,1,NULL,1,1,0,0,1,NULL,1.000,'Each',1,''),
('Cock Leter','Beverage',2,'1234','',80.00,96.00,1.000,4000.000,2,NULL,1,0,0,0,1,NULL,1.000,'Each',2,''),
('Sprite','Beverage',2,'12312-123123','',500.00,600.00,1.000,50.000,3,NULL,1,0,0,0,0,NULL,1.000,'Each',3,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1787915084,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1787915084,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1787915084,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1787915084,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1787915084,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1787915084,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1787915084,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1787915084,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1787915084,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1787915084,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1787915084,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1787915084,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1787915084,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1787915084,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1787915084,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1787915084,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1787915084,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1787915084,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1787915084,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1787915084,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1787915084,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1787915084,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1787915084,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1787915084,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1787915084,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1787915084,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1787915084,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1787915085,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1787915085,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1787915085,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1787915085,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1787915085,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1787915085,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1787915085,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1787915085,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1787915085,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1787915085,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1787915085,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1787915085,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1787915085,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1787915085,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1787915085,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1787915085,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1787915085,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1787915085,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('Usman','IlamDin',1,'+923014567595','usman65@gmail.com','Address 1','','','','','','',1),
('Alex','Alex',1,'','','','','','','','','',2),
('WalkIN','WalkIN',NULL,'','','','','','','','','',3);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_Shop','items',2),
('items_Warehouse','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_Shop','receivings',2),
('receivings_Warehouse','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_Shop','sales',2),
('sales_Warehouse','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
INSERT INTO `ospos_receivings` VALUES
('2026-08-28 17:57:35',2,1,'',1,'Cash','123123123');
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
INSERT INTO `ospos_receivings_items` VALUES
(1,3,'','',1,120.000,500.00,500.00,0.00,0,1,50.000);
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-08-28 16:47:27',NULL,1,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-08-28 16:54:53',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-08-28 16:57:10',NULL,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-02 14:39:45',3,1,'This is the final sale of the person\n\n','0',NULL,4,'Q26000001',0,NULL,1),
('2026-09-02 14:41:47',NULL,1,'',NULL,NULL,5,NULL,0,NULL,4),
('2026-09-02 14:44:04',3,1,'',NULL,NULL,6,NULL,0,NULL,0),
('2026-09-02 15:42:27',NULL,1,'',NULL,NULL,7,NULL,0,NULL,0),
('2026-09-03 10:43:16',NULL,1,'',NULL,NULL,8,NULL,0,NULL,0),
('2026-09-03 10:52:30',NULL,1,'',NULL,NULL,9,NULL,0,NULL,0),
('2026-09-03 10:53:11',NULL,1,'',NULL,NULL,10,NULL,0,NULL,0),
('2026-09-03 10:55:28',NULL,1,'',NULL,NULL,11,NULL,0,NULL,0),
('2026-09-03 10:59:48',NULL,1,'',NULL,NULL,12,NULL,0,NULL,0),
('2026-09-03 11:02:35',NULL,1,'',NULL,NULL,13,NULL,0,NULL,4),
('2026-09-03 11:11:17',NULL,1,'',NULL,NULL,14,NULL,0,NULL,0),
('2026-09-03 11:17:09',NULL,1,'',NULL,NULL,15,NULL,0,NULL,0),
('2026-09-03 11:20:59',NULL,1,'',NULL,NULL,16,NULL,0,NULL,0),
('2026-09-03 18:18:07',NULL,1,'',NULL,NULL,17,NULL,0,NULL,0),
('2026-09-03 19:05:38',NULL,1,'',NULL,NULL,18,NULL,0,NULL,0);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,1.000,0.00,0.00,0.00,0,1,0),
(2,1,'','',1,1.000,20.00,20.00,0.00,0,1,0),
(3,1,'','',2,1.000,20.00,20.00,0.00,0,1,0),
(4,1,'','',1,10.000,20.00,567.00,0.00,0,2,0),
(5,1,'','',1,-5.000,20.00,20.00,0.00,0,1,0),
(6,1,'','',1,5.000,20.00,10.00,0.00,0,1,0),
(7,2,'','',1,1.000,80.00,100.00,0.00,0,1,0),
(8,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(8,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(9,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(9,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(10,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(10,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(11,1,'','',2,2.000,20.00,20.00,10.00,0,1,0),
(11,3,'','',1,4.000,500.00,600.00,10.00,0,1,0),
(12,1,'','',1,2.000,20.00,20.00,10.00,0,1,0),
(12,3,'','',2,4.000,500.00,600.00,10.00,0,1,0),
(13,1,'','12321',1,4.000,20.00,20.00,10.00,0,1,0),
(14,1,'','',1,4.000,20.00,20.00,10.00,0,2,0),
(15,1,'This is the descriotion field','12321',1,4.000,20.00,20.00,0.00,0,1,0),
(16,1,'','',1,4.000,20.00,20.00,0.00,0,1,0),
(17,1,'','',1,8.000,20.00,20.00,0.00,0,1,0),
(17,2,'','',2,6.000,80.00,96.00,0.00,0,1,0),
(18,1,'','',2,4.000,20.00,20.00,10.00,0,1,0),
(18,2,'','',1,1.000,80.00,96.00,10.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,2,'Cash',20.00,0.00,0,1,'2026-08-28 11:54:53',''),
(2,3,'Cash',100.00,80.00,0,1,'2026-08-28 11:57:10',''),
(4,5,'Cash',-100.00,0.00,0,1,'2026-09-02 09:41:47',''),
(5,6,'Cash',50.00,0.00,0,1,'2026-09-02 09:44:04',''),
(6,7,'Cash',100.00,0.00,0,1,'2026-09-02 10:42:27',''),
(7,8,'Cash',2196.00,0.00,0,1,'2026-09-03 05:43:16',''),
(8,9,'Cash',2196.00,0.00,0,1,'2026-09-03 05:52:30',''),
(9,10,'Cash',2196.00,0.00,0,1,'2026-09-03 05:53:11',''),
(10,11,'Cash',2500.00,304.00,0,1,'2026-09-03 05:55:28',''),
(11,12,'Cash',2196.00,0.00,0,1,'2026-09-03 05:59:48',''),
(12,14,'Cash',72.00,0.00,0,1,'2026-09-03 06:11:17',''),
(13,15,'Cash',80.00,0.00,0,1,'2026-09-03 06:17:09',''),
(14,16,'Cash',80.00,0.00,0,1,'2026-09-03 06:20:59',''),
(15,17,'Cash',736.00,0.00,0,1,'2026-09-03 13:18:07',''),
(16,18,'Cash',158.40,0.00,0,1,'2026-09-03 14:05:38','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:046f26022170931924765d61c358b559','127.0.0.1','2026-09-03 13:43:56','__ci_last_regenerate|i:1788443036;csrf_ospos_v4|s:32:\"e545f6111d1ba10abb0338ae092b549e\";'),
('ospos_session:059490a21f7f6fd84b2807b9b4e09125','127.0.0.1','2026-09-03 14:08:42','__ci_last_regenerate|i:1788444522;csrf_ospos_v4|s:32:\"75f41ac6e8de12e6b6de6f13c68183db\";'),
('ospos_session:0646db68c39d1ececc0770f9dba2af26','127.0.0.1','2026-09-03 14:05:11','__ci_last_regenerate|i:1788444311;csrf_ospos_v4|s:32:\"1b0a1d394682650b3400299b2a295963\";'),
('ospos_session:0a38d39c3e4457ed48dcc1b52459b157','127.0.0.1','2026-09-03 13:29:24','__ci_last_regenerate|i:1788442164;csrf_ospos_v4|s:32:\"8f2a943f70c04f47bf960c47bdfde2c2\";'),
('ospos_session:0b9770fbc9ed14e13b6f3db979218b27','127.0.0.1','2026-09-03 13:30:54','__ci_last_regenerate|i:1788442254;csrf_ospos_v4|s:32:\"69161ee8329eba3a4b3185e3b1b76e2d\";'),
('ospos_session:0bcf2a876ca60d0563fac3c306e53f15','127.0.0.1','2026-09-03 14:11:14','__ci_last_regenerate|i:1788444674;csrf_ospos_v4|s:32:\"1b05469a3db12dffdff50e073c04a76a\";'),
('ospos_session:0c935df9a460f504baeaf35c291d9d3c','127.0.0.1','2026-09-03 13:39:55','__ci_last_regenerate|i:1788442795;csrf_ospos_v4|s:32:\"d984d1733c721c92dab5db250aab8bd8\";'),
('ospos_session:142be3c7041acfd44868fff78bba7b50','127.0.0.1','2026-09-03 13:54:29','__ci_last_regenerate|i:1788443669;csrf_ospos_v4|s:32:\"b8f52eeb32f91c707bec379ea54f4a8e\";'),
('ospos_session:190a565ec3c289af7ba85b4b312f8572','127.0.0.1','2026-09-03 14:10:43','__ci_last_regenerate|i:1788444643;csrf_ospos_v4|s:32:\"2fdee776476ac85e3fa6667f60d85aa0\";'),
('ospos_session:19e3adee37cde99999b5f98e33616ea8','127.0.0.1','2026-09-03 13:19:22','__ci_last_regenerate|i:1788441562;csrf_ospos_v4|s:32:\"5970cc93c2916a08750866ee78ca1d6c\";'),
('ospos_session:1cc895e8182e23151315341a109cffbf','127.0.0.1','2026-09-03 13:32:54','__ci_last_regenerate|i:1788442374;csrf_ospos_v4|s:32:\"72413e91445af84fd000c860a747b00c\";'),
('ospos_session:1eb40dd95a25c6f42e781cbc4253eeee','127.0.0.1','2026-09-03 14:10:12','__ci_last_regenerate|i:1788444612;csrf_ospos_v4|s:32:\"eb510d3816566331b44975357ed6078e\";'),
('ospos_session:1ff250bc6e50ecad7797ab70b9b1832e','127.0.0.1','2026-09-03 13:35:25','__ci_last_regenerate|i:1788442525;csrf_ospos_v4|s:32:\"1c2cea51a3a9122f062533927d37df22\";'),
('ospos_session:21ffc02e9aaf90cb92d49d794e791602','127.0.0.1','2026-09-03 13:22:53','__ci_last_regenerate|i:1788441773;csrf_ospos_v4|s:32:\"8d0645c9e1c9023b4c5b27b85b49f5b9\";'),
('ospos_session:23c9ea116f04fa0a602101b330598c7e','127.0.0.1','2026-09-03 13:22:23','__ci_last_regenerate|i:1788441743;csrf_ospos_v4|s:32:\"e2a5bf32400026f34f858a6ea63dc6e3\";'),
('ospos_session:264849d9d3d649040fb1b3754a5ab361','127.0.0.1','2026-09-03 13:47:27','__ci_last_regenerate|i:1788443247;csrf_ospos_v4|s:32:\"63081a60d82debc9a3f3bb2c2a1b9fc1\";'),
('ospos_session:297f903e359b9dac0f8f0f83e41cfba9','127.0.0.1','2026-09-03 14:02:11','__ci_last_regenerate|i:1788444131;csrf_ospos_v4|s:32:\"7480e4401734c6018c1579832902b863\";'),
('ospos_session:29a538548f6b2f2373616a946df87eaa','127.0.0.1','2026-09-03 13:27:53','__ci_last_regenerate|i:1788442073;csrf_ospos_v4|s:32:\"4f8754a622ce9bb82dbc97cd5bc0dc7b\";'),
('ospos_session:29d82d60605b438f91d0c3b17b43c3a4','127.0.0.1','2026-09-03 13:36:55','__ci_last_regenerate|i:1788442615;csrf_ospos_v4|s:32:\"4afe23043b15ddf8dc809bfb8cb07777\";'),
('ospos_session:2a457558997ca921e5da979f89eaa782','127.0.0.1','2026-09-03 13:42:56','__ci_last_regenerate|i:1788442976;csrf_ospos_v4|s:32:\"b73546f80bda82992f579c4129969aa8\";'),
('ospos_session:2ca8d2246149156991687fb275309204','127.0.0.1','2026-09-03 13:45:26','__ci_last_regenerate|i:1788443126;csrf_ospos_v4|s:32:\"36434cbc75d8a9bbbaac6d3cba61ae6f\";'),
('ospos_session:2f692c63a6f18e0df1d9230fe6d7c9c5','127.0.0.1','2026-09-03 13:13:51','__ci_last_regenerate|i:1788441231;csrf_ospos_v4|s:32:\"7d2beb76343684c476ab880a97648ccf\";'),
('ospos_session:3392821a90bac82ec741ea1353144173','172.22.0.3','2026-09-03 14:15:38','__ci_last_regenerate|i:1788444897;csrf_ospos_v4|s:32:\"c5dd78bb6b88098112e4e5e0e88de4bc\";_ci_previous_url|s:33:\"https://ghazi-pos.local/item_kits\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:1;item_location|s:1:\"1\";sale_id|i:-1;sales_location|i:1;recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_stock_source|i:1;recv_stock_destination|s:1:\"1\";recv_supplier|i:-1;sales_employee|i:1;cash_adjustment_amount|d:0;'),
('ospos_session:33f2e80e76b4b24f8458034cdcdbd1b7','127.0.0.1','2026-09-03 13:59:10','__ci_last_regenerate|i:1788443950;csrf_ospos_v4|s:32:\"2d6652a136ac04b6cc3c6c04e2ce66e1\";'),
('ospos_session:3616443beefda819e6e16be1ea3b769d','127.0.0.1','2026-09-03 13:51:57','__ci_last_regenerate|i:1788443517;csrf_ospos_v4|s:32:\"94766c78c75ff7de7802405d87861e51\";'),
('ospos_session:385784c3e20018907949fa342ccff8c6','127.0.0.1','2026-09-03 13:28:54','__ci_last_regenerate|i:1788442134;csrf_ospos_v4|s:32:\"46163f250f941b641170aadc8a428316\";'),
('ospos_session:389146c536ee9e3333e4966996cdef69','127.0.0.1','2026-09-03 13:17:22','__ci_last_regenerate|i:1788441442;csrf_ospos_v4|s:32:\"ff130174e49c0d22c6a9266c0c367068\";'),
('ospos_session:3a8232ea0e21617215613e2f2360504e','127.0.0.1','2026-09-03 13:37:55','__ci_last_regenerate|i:1788442675;csrf_ospos_v4|s:32:\"ed7dd406b43b1a18e24bb511d71fd3a1\";'),
('ospos_session:3b4daee84f3dc1ee20120b24bdc58f20','127.0.0.1','2026-09-03 14:14:14','__ci_last_regenerate|i:1788444854;csrf_ospos_v4|s:32:\"2991594d362f3b2b1217ac1c94853eb2\";'),
('ospos_session:3ebd4ef667a8416be6b456e87287a7df','127.0.0.1','2026-09-03 13:18:22','__ci_last_regenerate|i:1788441502;csrf_ospos_v4|s:32:\"f557004f3cc30d0e428699d68dc4005d\";'),
('ospos_session:42b6a839e7f458fb5a6074997e91f753','127.0.0.1','2026-09-03 13:59:40','__ci_last_regenerate|i:1788443980;csrf_ospos_v4|s:32:\"bb30651a74121b59a7d4b5dcf8088350\";'),
('ospos_session:446b6eee1d56de0422cfb0ec3a12ec5f','127.0.0.1','2026-09-03 14:03:41','__ci_last_regenerate|i:1788444221;csrf_ospos_v4|s:32:\"9a21f28061f627fe79c34586bf2774dc\";'),
('ospos_session:4862189a3cf4797b53ef693b77977b27','127.0.0.1','2026-09-03 13:20:22','__ci_last_regenerate|i:1788441622;csrf_ospos_v4|s:32:\"f276123c9ab04ed55cfe4c58c61dba76\";'),
('ospos_session:487c9460a7299f65b671b5ce43a28627','127.0.0.1','2026-09-03 13:17:52','__ci_last_regenerate|i:1788441472;csrf_ospos_v4|s:32:\"3bcc51a87cea7bc824f8683de5140908\";'),
('ospos_session:49407f2f428f0cedf6750715d83f67e3','127.0.0.1','2026-09-03 13:53:58','__ci_last_regenerate|i:1788443638;csrf_ospos_v4|s:32:\"97ea286c8853a9e5d99c003390b4f9d0\";'),
('ospos_session:4cf7a9fac8e5ca2320b31010aff1075c','127.0.0.1','2026-09-03 13:49:27','__ci_last_regenerate|i:1788443367;csrf_ospos_v4|s:32:\"2cffb0834a4d23687c44f88a20e727e7\";'),
('ospos_session:542d949c0fd856581a8e9f62c290d7cd','127.0.0.1','2026-09-03 13:30:24','__ci_last_regenerate|i:1788442224;csrf_ospos_v4|s:32:\"7cbd321af9c2e41e7755a2e6e48c45ef\";'),
('ospos_session:56534545971438865954e76944fd0264','127.0.0.1','2026-09-03 13:39:25','__ci_last_regenerate|i:1788442765;csrf_ospos_v4|s:32:\"772d979923b73dcd5ca07ee0e7921461\";'),
('ospos_session:57f494caa605a74db2bdd5824783d79a','127.0.0.1','2026-09-03 13:24:23','__ci_last_regenerate|i:1788441863;csrf_ospos_v4|s:32:\"68c0a2309eb97f665d018ae9c486da9b\";'),
('ospos_session:5a6acd7943fddf7b01322de4aecb821a','127.0.0.1','2026-09-03 13:43:26','__ci_last_regenerate|i:1788443006;csrf_ospos_v4|s:32:\"79419b09832975ac02bae7a0538e2825\";'),
('ospos_session:5e491976a56393a439cd9f957367dbd5','127.0.0.1','2026-09-03 14:12:14','__ci_last_regenerate|i:1788444734;csrf_ospos_v4|s:32:\"3864ab6b296f626b12066655d3b40d2c\";'),
('ospos_session:60bf17c2bb3c5d499f92fef82cfbf7d7','127.0.0.1','2026-09-03 13:49:57','__ci_last_regenerate|i:1788443397;csrf_ospos_v4|s:32:\"538d2f3dfeeac425cc387a62ae743ea9\";'),
('ospos_session:6156a1f2a5f634f4e75e373feebe96cc','127.0.0.1','2026-09-03 14:01:11','__ci_last_regenerate|i:1788444071;csrf_ospos_v4|s:32:\"16b771ed37a8f5faaafdb7f0578f2e89\";'),
('ospos_session:62c70c1d3fae75855919d165df2cb95d','127.0.0.1','2026-09-03 13:27:23','__ci_last_regenerate|i:1788442043;csrf_ospos_v4|s:32:\"e0903f1b046226522a546c45a891cec8\";'),
('ospos_session:663dd135fba237159246e9ef341d0655','127.0.0.1','2026-09-03 13:46:26','__ci_last_regenerate|i:1788443186;csrf_ospos_v4|s:32:\"79d1a45c70928cafb69c8e8af33340a5\";'),
('ospos_session:688462a59f158c324ea5b2b991f87cc7','127.0.0.1','2026-09-03 13:53:28','__ci_last_regenerate|i:1788443608;csrf_ospos_v4|s:32:\"49b36f73b988069e94e995cda3783633\";'),
('ospos_session:6fe95df82f209a55b92e997427c1fb02','127.0.0.1','2026-09-03 14:09:42','__ci_last_regenerate|i:1788444582;csrf_ospos_v4|s:32:\"9e826b4e8c4aeaed188be046e6e38133\";'),
('ospos_session:71b6c6ced64babe286d66a49914dc143','127.0.0.1','2026-09-03 13:19:52','__ci_last_regenerate|i:1788441592;csrf_ospos_v4|s:32:\"56d25cfb20a64587975354d0bcabbf14\";'),
('ospos_session:745eb7e5b133e9064e9b1a54321337de','127.0.0.1','2026-09-03 13:54:59','__ci_last_regenerate|i:1788443699;csrf_ospos_v4|s:32:\"5675fe19d467fd7539f77546493f55e9\";'),
('ospos_session:74fedba659796bdcd99cf2f3016679e6','127.0.0.1','2026-09-03 13:57:40','__ci_last_regenerate|i:1788443860;csrf_ospos_v4|s:32:\"493f40d36311093501eedf8c2a5acc65\";'),
('ospos_session:755e49a8725b953422f5f22c095059a5','127.0.0.1','2026-09-03 13:40:55','__ci_last_regenerate|i:1788442855;csrf_ospos_v4|s:32:\"6c107a44e431a21d72560f932ef76fbd\";'),
('ospos_session:75938f6edfcd6ae3a87738a6d7c53096','127.0.0.1','2026-09-03 13:21:23','__ci_last_regenerate|i:1788441683;csrf_ospos_v4|s:32:\"45530384f75ac22c3b366c8ddd42d46e\";'),
('ospos_session:77e543aac8f480296e9137ae75478e81','127.0.0.1','2026-09-03 13:56:10','__ci_last_regenerate|i:1788443770;csrf_ospos_v4|s:32:\"b79ecd547415a2dc81451c63af87a99c\";'),
('ospos_session:7b1ac6327a610e3817c87b0894b85ad7','127.0.0.1','2026-09-03 13:14:52','__ci_last_regenerate|i:1788441292;csrf_ospos_v4|s:32:\"2d6d5694110b72abd9d920ade8ef7eca\";'),
('ospos_session:7bf77be1c52dab56bcbe31e34daba3db','127.0.0.1','2026-09-03 13:26:53','__ci_last_regenerate|i:1788442013;csrf_ospos_v4|s:32:\"b47820767263b0abd0da99e29cc60994\";'),
('ospos_session:800deb26d1dbeac1ae12a808e83890ce','127.0.0.1','2026-09-03 13:12:51','__ci_last_regenerate|i:1788441171;csrf_ospos_v4|s:32:\"38ba6cf62ddf46437299c3704fd5452b\";'),
('ospos_session:809ffb86dc3ebf0ede8ccb2552212e14','127.0.0.1','2026-09-03 13:45:56','__ci_last_regenerate|i:1788443156;csrf_ospos_v4|s:32:\"e0bf4a8d366afc4fc3640cd35dfaf31c\";'),
('ospos_session:82c6bfb83c7235d58d060625a68e7595','127.0.0.1','2026-09-03 14:15:14','__ci_last_regenerate|i:1788444914;csrf_ospos_v4|s:32:\"cebb22dd2e297a294b5246011f58385b\";'),
('ospos_session:83788e40d14f0307a0fb23598c623394','127.0.0.1','2026-09-03 13:48:27','__ci_last_regenerate|i:1788443307;csrf_ospos_v4|s:32:\"7671b1f32ee4a7e16d2a75894219227f\";'),
('ospos_session:85976a7806c4609faab2c418b8f8fbfd','127.0.0.1','2026-09-03 13:55:29','__ci_last_regenerate|i:1788443729;csrf_ospos_v4|s:32:\"5355a41f6383625b55534ed49ab3e93f\";'),
('ospos_session:8649157f9c1ffb5a478d2fee491e7784','127.0.0.1','2026-09-03 14:13:14','__ci_last_regenerate|i:1788444794;csrf_ospos_v4|s:32:\"5e619c727dc5d95317e8bdda7542a18e\";'),
('ospos_session:86f80cd0a755fc33e46a60b8a3b511de','127.0.0.1','2026-09-03 13:41:56','__ci_last_regenerate|i:1788442916;csrf_ospos_v4|s:32:\"bcbe13307584e427031fa3928f7124a1\";'),
('ospos_session:8821c89f9d3c7660d808b2d65ec060fb','127.0.0.1','2026-09-03 13:42:26','__ci_last_regenerate|i:1788442946;csrf_ospos_v4|s:32:\"290d033970677a16d6bee8c2bc558e87\";'),
('ospos_session:8907f1e265b15ad9058c49ac0d4866dd','127.0.0.1','2026-09-03 13:44:26','__ci_last_regenerate|i:1788443066;csrf_ospos_v4|s:32:\"664c07cbcc051c2fb3eed076958fce5d\";'),
('ospos_session:895aeed74e5379567f72decc28982864','127.0.0.1','2026-09-03 13:48:57','__ci_last_regenerate|i:1788443337;csrf_ospos_v4|s:32:\"ac6908a1f71c01e52c6f53e3c8a4ec24\";'),
('ospos_session:8b0cbbce4da6778227a29d14a6e90bb1','127.0.0.1','2026-09-03 13:23:53','__ci_last_regenerate|i:1788441833;csrf_ospos_v4|s:32:\"28082464f36252421a788ad29c87d367\";'),
('ospos_session:8b35efdd2a5e8628549f09f6755bb130','127.0.0.1','2026-09-03 14:09:12','__ci_last_regenerate|i:1788444552;csrf_ospos_v4|s:32:\"3cb8e4c86f6b81ba1c345acc7832cfd9\";'),
('ospos_session:8c010f3ddfaa2c697d4c7ae607b531f8','127.0.0.1','2026-09-03 13:33:24','__ci_last_regenerate|i:1788442404;csrf_ospos_v4|s:32:\"bb28e9d2a1abb9c64e486ece0bdd17ea\";'),
('ospos_session:8cbe3f7b75f7835e61a8bad506a9473a','127.0.0.1','2026-09-03 13:57:10','__ci_last_regenerate|i:1788443830;csrf_ospos_v4|s:32:\"b66609d7c163f53ed7136acc674bc946\";'),
('ospos_session:8d575f230f1d49a5bbb447d4eff99024','127.0.0.1','2026-09-03 14:14:44','__ci_last_regenerate|i:1788444884;csrf_ospos_v4|s:32:\"86ddf99b22d1a8a4e6007749e57c9238\";'),
('ospos_session:8ef6d50c674f8eab2a90454ffb1655ed','127.0.0.1','2026-09-03 13:15:22','__ci_last_regenerate|i:1788441322;csrf_ospos_v4|s:32:\"a6f9ff4c41a87b791b6832fb1253c304\";'),
('ospos_session:8ff0bfe2be493c4787e85284dfec6d0a','127.0.0.1','2026-09-03 13:24:53','__ci_last_regenerate|i:1788441893;csrf_ospos_v4|s:32:\"57b727ed79562c612342cf47689f419d\";'),
('ospos_session:927f0c4972114de0d77c688152709d87','127.0.0.1','2026-09-03 13:52:27','__ci_last_regenerate|i:1788443547;csrf_ospos_v4|s:32:\"4a7e12738caedc4479be479ef80e2446\";'),
('ospos_session:93d4cb512cdd1d2221369d9752a439ea','127.0.0.1','2026-09-03 14:04:11','__ci_last_regenerate|i:1788444251;csrf_ospos_v4|s:32:\"73cddd5e5bf7847d5cfc03a16efcc64b\";'),
('ospos_session:961c71166c28dff15c2c6e757906bcd2','127.0.0.1','2026-09-03 14:13:44','__ci_last_regenerate|i:1788444824;csrf_ospos_v4|s:32:\"c91e45848458bbcac05b36b75e037292\";'),
('ospos_session:97c29def5433fae2d1269b538eae5879','127.0.0.1','2026-09-03 13:51:27','__ci_last_regenerate|i:1788443487;csrf_ospos_v4|s:32:\"e2da637f9272f530976b8db4b9074cab\";'),
('ospos_session:9a725443e90108cd6ecb29293eb0cf06','127.0.0.1','2026-09-03 14:06:42','__ci_last_regenerate|i:1788444402;csrf_ospos_v4|s:32:\"c4b0bffb036e2478688d04b3ad790261\";'),
('ospos_session:9b45c92613ad54f92bd5d63781b03453','127.0.0.1','2026-09-03 13:14:21','__ci_last_regenerate|i:1788441261;csrf_ospos_v4|s:32:\"9639dc69766510aa6ab8f5c8a41035ff\";'),
('ospos_session:9cac63ed36336d96fd0be881cd4ef424','127.0.0.1','2026-09-03 13:31:54','__ci_last_regenerate|i:1788442314;csrf_ospos_v4|s:32:\"e251b2b740e7c9b2e79b8c1952ddaff6\";'),
('ospos_session:9e0ed9516c11e75678082329b44686e9','127.0.0.1','2026-09-03 13:36:25','__ci_last_regenerate|i:1788442585;csrf_ospos_v4|s:32:\"45602d540af0454b68fda514821be795\";'),
('ospos_session:9e7b6c8ac97ad44d95e53e21beb83ce6','127.0.0.1','2026-09-03 14:00:41','__ci_last_regenerate|i:1788444041;csrf_ospos_v4|s:32:\"73f804fe40bb876039427ea49e4c9cfe\";'),
('ospos_session:9f0c4c222646816ac928f772d67f1fbf','127.0.0.1','2026-09-03 13:47:57','__ci_last_regenerate|i:1788443277;csrf_ospos_v4|s:32:\"f9157bc28983b6b343e5a9e01265d4c3\";'),
('ospos_session:a1775746ebe239be5280b57d170ac030','127.0.0.1','2026-09-03 13:34:55','__ci_last_regenerate|i:1788442495;csrf_ospos_v4|s:32:\"a0bd4cfdae42436dca6e7907e769ec8d\";'),
('ospos_session:a4ad62f082a8254920327815c635f28f','127.0.0.1','2026-09-03 13:25:53','__ci_last_regenerate|i:1788441953;csrf_ospos_v4|s:32:\"1b88b49d9d0619a8e1a612e6a0b57934\";'),
('ospos_session:a7938c67726c107f79aa6683dbd53014','127.0.0.1','2026-09-03 14:00:11','__ci_last_regenerate|i:1788444011;csrf_ospos_v4|s:32:\"5c4a293dad4aa5785c1b61fe7d11df33\";'),
('ospos_session:a9e91e99948175e38ba0b8c3cb8bf016','127.0.0.1','2026-09-03 14:06:11','__ci_last_regenerate|i:1788444371;csrf_ospos_v4|s:32:\"fa19ee054b2a1242cf244cbd8ea28a31\";'),
('ospos_session:b02658ac2c36a14c2c2f6fee7ab1230f','127.0.0.1','2026-09-03 13:10:51','__ci_last_regenerate|i:1788441051;csrf_ospos_v4|s:32:\"a085eded9f16a051e468c067542fd7f1\";'),
('ospos_session:b5820c7c910e1e698037f0698b75125b','127.0.0.1','2026-09-03 13:50:57','__ci_last_regenerate|i:1788443457;csrf_ospos_v4|s:32:\"cf235e7e215f8aa8e512f4a8655fcef0\";'),
('ospos_session:b5e9b7c2b0e751ce505800e8b19b0614','127.0.0.1','2026-09-03 13:33:54','__ci_last_regenerate|i:1788442434;csrf_ospos_v4|s:32:\"1027485d22448ef5b16ee26864bc003f\";'),
('ospos_session:b8e46d8e6c9eaf56fcd7f334451b7311','127.0.0.1','2026-09-03 13:11:21','__ci_last_regenerate|i:1788441081;csrf_ospos_v4|s:32:\"c815aa56150286da23455c15a099d6d8\";'),
('ospos_session:bac00bf621795bb46f5fa2f97bffd349','127.0.0.1','2026-09-03 13:28:24','__ci_last_regenerate|i:1788442104;csrf_ospos_v4|s:32:\"4ca331190981c670697a6e581ac51949\";'),
('ospos_session:bb7824527e322c3b4c0addbd6849793a','127.0.0.1','2026-09-03 14:05:41','__ci_last_regenerate|i:1788444341;csrf_ospos_v4|s:32:\"d4d10b3e911470fe71e7d129a418dd35\";'),
('ospos_session:c59e1dcfa0441c2045bf014a7f8dc12c','127.0.0.1','2026-09-03 14:03:11','__ci_last_regenerate|i:1788444191;csrf_ospos_v4|s:32:\"ee0dd6f2ee40eb62de413fae8755dbc6\";'),
('ospos_session:c95d21fe24907aead75010af8cd1b677','127.0.0.1','2026-09-03 13:26:23','__ci_last_regenerate|i:1788441983;csrf_ospos_v4|s:32:\"3ddbb4ea3fb8f83fc3a35ca163abe6cf\";'),
('ospos_session:c9c527263de429275aa3534c73d79190','127.0.0.1','2026-09-03 13:20:52','__ci_last_regenerate|i:1788441652;csrf_ospos_v4|s:32:\"6aa5b049437c09cfe20749064d11d1ba\";'),
('ospos_session:ccb0fcfd5de6c594fefcc4a5ab9765a4','127.0.0.1','2026-09-03 13:13:21','__ci_last_regenerate|i:1788441201;csrf_ospos_v4|s:32:\"82d8642697d1a88157814349522f57bc\";'),
('ospos_session:cef11736334d8bf22fa891ae9e2fd2b2','127.0.0.1','2026-09-03 14:07:12','__ci_last_regenerate|i:1788444432;csrf_ospos_v4|s:32:\"886bfbc7292db5eecab0f1ebebdc3d45\";'),
('ospos_session:d438a8d168e8933335c8bc5e345c7671','127.0.0.1','2026-09-03 13:41:26','__ci_last_regenerate|i:1788442886;csrf_ospos_v4|s:32:\"ede25869bacee6aea5a2442d480797b1\";'),
('ospos_session:d6f7826a2306f6003d9fda5acae69acf','127.0.0.1','2026-09-03 13:58:10','__ci_last_regenerate|i:1788443890;csrf_ospos_v4|s:32:\"d7b1d20eb8ee1bcfb253440d229f7444\";'),
('ospos_session:d6fe8c2e47f54a484fe4069553cdb91c','127.0.0.1','2026-09-03 13:32:24','__ci_last_regenerate|i:1788442344;csrf_ospos_v4|s:32:\"d02e6d08b5d15eb51c269eee3df5283d\";'),
('ospos_session:d97236a9fb68e821380a0910fb4662e3','127.0.0.1','2026-09-03 14:07:42','__ci_last_regenerate|i:1788444462;csrf_ospos_v4|s:32:\"75dc88bb729652ad26fece14a27f4847\";'),
('ospos_session:da9b6e1a2c62fdf7ba699e5e25f5f5b7','127.0.0.1','2026-09-03 13:15:52','__ci_last_regenerate|i:1788441352;csrf_ospos_v4|s:32:\"01f6fac1bf06a8f4615c41ec12ac5ebd\";'),
('ospos_session:dce099f6ddac3492b59a5b686531bc67','127.0.0.1','2026-09-03 13:38:25','__ci_last_regenerate|i:1788442705;csrf_ospos_v4|s:32:\"32375b37d0870ddc8e84e5c578be5eff\";'),
('ospos_session:de9007ca77e88263684b0cc90c2dd8f5','127.0.0.1','2026-09-03 13:29:54','__ci_last_regenerate|i:1788442194;csrf_ospos_v4|s:32:\"aa3f6bdedd4f3c7beb712e4bb0d2ccce\";'),
('ospos_session:e05e84016c3e9a35fa04da2bd39bf404','127.0.0.1','2026-09-03 13:37:25','__ci_last_regenerate|i:1788442645;csrf_ospos_v4|s:32:\"f3771e1fc94c3c5082a32469bc6ba51d\";'),
('ospos_session:e06da972db7ed75e0ea69ee7b3f02358','127.0.0.1','2026-09-03 13:12:21','__ci_last_regenerate|i:1788441141;csrf_ospos_v4|s:32:\"cb897d066d69862a6bcc0c4bb9948910\";'),
('ospos_session:e12e25197f1b124508cfbf16cbc910bd','127.0.0.1','2026-09-03 13:11:51','__ci_last_regenerate|i:1788441111;csrf_ospos_v4|s:32:\"273f91ba9e7ab79cdfc5aad591ec42c6\";'),
('ospos_session:e280fbcc4120a86aa9c714805a3bf4f2','127.0.0.1','2026-09-03 14:11:44','__ci_last_regenerate|i:1788444704;csrf_ospos_v4|s:32:\"65a94a46a4ccdd408b0eeeb26a2cda1c\";'),
('ospos_session:e2b74813372f6ddb20dfb31ac7c56607','127.0.0.1','2026-09-03 13:56:40','__ci_last_regenerate|i:1788443800;csrf_ospos_v4|s:32:\"0a073bec55115e8ca4eceda6a21b99ca\";'),
('ospos_session:e43af2ab597e344799831bd679b2dffd','127.0.0.1','2026-09-03 13:50:27','__ci_last_regenerate|i:1788443427;csrf_ospos_v4|s:32:\"3bd70b2e3bccf2ac6826c604214d3dc1\";'),
('ospos_session:e6b04c85b662a49c483789d18ef81212','127.0.0.1','2026-09-03 14:04:41','__ci_last_regenerate|i:1788444281;csrf_ospos_v4|s:32:\"b3d75244216e6cbe0caa6e827470c48e\";'),
('ospos_session:e72f0df24544c59892b940be1bf046c5','127.0.0.1','2026-09-03 13:44:56','__ci_last_regenerate|i:1788443096;csrf_ospos_v4|s:32:\"635585358ff43ccde1f13cc3cd82d5cf\";'),
('ospos_session:e908288de5e6204bec246073aea2602a','127.0.0.1','2026-09-03 13:40:25','__ci_last_regenerate|i:1788442825;csrf_ospos_v4|s:32:\"abf945db1202f689a2c519ba7efc4a35\";'),
('ospos_session:e93e5876ab024fbcd717dd75eccb9c54','127.0.0.1','2026-09-03 13:18:52','__ci_last_regenerate|i:1788441532;csrf_ospos_v4|s:32:\"3d6e7a54f215b0f1689b2c2438f76492\";'),
('ospos_session:e9526255523770ecfa914ae0d669bb3e','127.0.0.1','2026-09-03 13:46:56','__ci_last_regenerate|i:1788443216;csrf_ospos_v4|s:32:\"4027561ac8b8081020956629b033470f\";'),
('ospos_session:ea23a4f8050e2b3cb432a7582a5add27','127.0.0.1','2026-09-03 13:55:59','__ci_last_regenerate|i:1788443759;csrf_ospos_v4|s:32:\"28fa3e345378eae658739dcdb493033a\";'),
('ospos_session:ea65acffe639a177488fa3daa6f57a83','127.0.0.1','2026-09-03 13:38:55','__ci_last_regenerate|i:1788442735;csrf_ospos_v4|s:32:\"f060e1c9afd3524baad31c44a7a501a6\";'),
('ospos_session:eab1a4eaea79d95f056b1b0804317ae2','127.0.0.1','2026-09-03 14:08:12','__ci_last_regenerate|i:1788444492;csrf_ospos_v4|s:32:\"91243058fbb55bdfac710b2c71b9272f\";'),
('ospos_session:eb94fd85a9ff1723f97a2f468ff52ba3','127.0.0.1','2026-09-03 13:21:53','__ci_last_regenerate|i:1788441713;csrf_ospos_v4|s:32:\"ed81badcf834e40681cd2d203a73f8d4\";'),
('ospos_session:ed482bc6aba07e537c2255b5ec71924d','127.0.0.1','2026-09-03 13:31:24','__ci_last_regenerate|i:1788442284;csrf_ospos_v4|s:32:\"4a946bd88ec0ecbd88ce3fe594d096fc\";'),
('ospos_session:ef9be8abe791b80bee1592c9df321d2a','127.0.0.1','2026-09-03 13:25:23','__ci_last_regenerate|i:1788441923;csrf_ospos_v4|s:32:\"bf9bcb85de81110e609eb97dfd66a70d\";'),
('ospos_session:f1f60993636cbbcce76fdb248a2d4742','127.0.0.1','2026-09-03 13:16:22','__ci_last_regenerate|i:1788441382;csrf_ospos_v4|s:32:\"2ad35c7cf9bdbba1129fae07e7ad419c\";'),
('ospos_session:f30bc2dd9a48cd6b6125a0b8502d5ca5','127.0.0.1','2026-09-03 13:16:52','__ci_last_regenerate|i:1788441412;csrf_ospos_v4|s:32:\"175d4ce124828b6683a26bcb1f77d86b\";'),
('ospos_session:f363f5a2ceefd8aef836fae1662f104b','127.0.0.1','2026-09-03 13:52:57','__ci_last_regenerate|i:1788443577;csrf_ospos_v4|s:32:\"612d6eabf79818d97e6ec32fee00355a\";'),
('ospos_session:f6aa93f8a8cc60263b4e86961135f23b','127.0.0.1','2026-09-03 14:02:41','__ci_last_regenerate|i:1788444161;csrf_ospos_v4|s:32:\"ca7c626ed302138cc74bbf72e26defc1\";'),
('ospos_session:f7225b3a8cb2ccd0be3278682c3be6bc','127.0.0.1','2026-09-03 13:35:55','__ci_last_regenerate|i:1788442555;csrf_ospos_v4|s:32:\"8dcc03f609a74833ef1561fa0d1e6c01\";'),
('ospos_session:f7619325ccba11a559344da99aed9314','127.0.0.1','2026-09-03 13:58:40','__ci_last_regenerate|i:1788443920;csrf_ospos_v4|s:32:\"020ed553d8117b0828a6bc4aee8922e2\";'),
('ospos_session:f96fd623f810b0af6920b4a4a085184c','127.0.0.1','2026-09-03 14:12:44','__ci_last_regenerate|i:1788444764;csrf_ospos_v4|s:32:\"2a75ce47e96ef2d8305d62b00c881573\";'),
('ospos_session:fa650097fac1b54b48890a5b50636959','127.0.0.1','2026-09-03 14:01:41','__ci_last_regenerate|i:1788444101;csrf_ospos_v4|s:32:\"0bacc0c17e95fee95dbce082ced72b1b\";'),
('ospos_session:ff03c6a87ed04187282eba5fc6b6443c','127.0.0.1','2026-09-03 13:34:24','__ci_last_regenerate|i:1788442464;csrf_ospos_v4|s:32:\"b9aeb67c2c45a76b11de77b85cc8ac5a\";'),
('ospos_session:ff268c40b6b2890e55c8ddae28b992c8','127.0.0.1','2026-09-03 13:23:23','__ci_last_regenerate|i:1788441803;csrf_ospos_v4|s:32:\"c42498b9317fede0821859851684fd9f\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'Warehouse',0),
(2,'Shop',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(2,'FFC','FFC',NULL,'',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03 14:16:13
