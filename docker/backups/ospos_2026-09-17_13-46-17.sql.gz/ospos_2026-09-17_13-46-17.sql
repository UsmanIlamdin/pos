/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for Linux (aarch64)
--
-- Host: db    Database: pos
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ospos_app_config`
--

DROP TABLE IF EXISTS `ospos_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_app_config` (
  `key` varchar(50) NOT NULL,
  `value` varchar(500) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_app_config`
--

LOCK TABLES `ospos_app_config` WRITE;
/*!40000 ALTER TABLE `ospos_app_config` DISABLE KEYS */;
INSERT INTO `ospos_app_config` VALUES
('account_number',''),
('address','123 Nowhere street'),
('allow_duplicate_barcodes','0'),
('barcode_content','id'),
('barcode_first_row','name'),
('barcode_font','0'),
('barcode_font_size','10'),
('barcode_formats','null'),
('barcode_generate_if_empty','0'),
('barcode_height','50'),
('barcode_num_in_row','2'),
('barcode_page_cellspacing','20'),
('barcode_page_width','100'),
('barcode_second_row','item_code'),
('barcode_third_row','unit_price'),
('barcode_type','C128'),
('barcode_width','250'),
('cash_decimals','2'),
('cash_rounding_code','0'),
('category_dropdown','0'),
('clcdesq_api_key',''),
('clcdesq_api_url',''),
('company','CortexFlow Point of Sale'),
('company_logo','Test2.png'),
('country_codes','us'),
('currency_code',''),
('currency_decimals','2'),
('currency_symbol','$'),
('customer_reward_enable','0'),
('dateformat','m/d/Y'),
('date_or_time_format',''),
('default_receivings_discount','0'),
('default_receivings_discount_type','0'),
('default_register_mode','sale'),
('default_sales_discount','0'),
('default_sales_discount_type','0'),
('default_tax_1_name',''),
('default_tax_1_rate',''),
('default_tax_2_name',''),
('default_tax_2_rate',''),
('default_tax_category','Standard'),
('default_tax_code',''),
('default_tax_jurisdiction',''),
('default_tax_rate','8'),
('derive_sale_quantity','0'),
('dinner_table_enable','0'),
('email','changeme@example.com'),
('email_receipt_check_behaviour','never'),
('enforce_privacy','0'),
('fax',''),
('financial_year','1'),
('gcaptcha_enable','0'),
('gcaptcha_secret_key',''),
('gcaptcha_site_key',''),
('giftcard_number','series'),
('image_allowed_types','jpg,gif,png'),
('image_max_height','640'),
('image_max_size','1024'),
('image_max_width','821'),
('include_hsn','0'),
('invoice_default_comments','Thanks'),
('invoice_email_message','Dear {CU}, In attachment the receipt for sale {ISEQ}'),
('invoice_enable','1'),
('invoice_type','invoice'),
('key_amount','53 | ALT + 5'),
('key_cancel','27 | ESC'),
('key_complete','55 | ALT + 7'),
('key_customers','50 | ALT + 2'),
('key_finish','56 | ALT + 8'),
('key_help','57 | ALT + 9'),
('key_items','49 | ALT + 1'),
('key_payment','54 | ALT + 6'),
('key_suspend','51 | ALT + 3'),
('key_suspended','52 | ALT + 4'),
('language','english'),
('language_code','en'),
('last_used_invoice_number','12003'),
('last_used_quote_number','200'),
('last_used_work_order_number','0'),
('lines_per_page','25'),
('line_sequence','0'),
('login_form','floating_labels'),
('mailchimp_api_key',''),
('mailchimp_list_id',''),
('mailpath','/usr/sbin/sendmail'),
('msg_msg',''),
('msg_pwd',''),
('msg_src',''),
('msg_uid',''),
('multi_pack_enabled','0'),
('notify_horizontal_position','center'),
('notify_vertical_position','bottom'),
('number_locale','en_US'),
('payment_message',''),
('payment_options_order','cashdebitcredit'),
('phone','555-555-5555'),
('print_bottom_margin',''),
('print_delay_autoreturn','0'),
('print_footer','0'),
('print_header','0'),
('print_left_margin',''),
('print_receipt_check_behaviour','never'),
('print_right_margin',''),
('print_silently','0'),
('print_top_margin',''),
('protocol','mail'),
('quantity_decimals','0'),
('quote_default_comments','This is a default quote comment'),
('receipt_font_size','12'),
('receipt_show_company_name','1'),
('receipt_show_description','0'),
('receipt_show_serialnumber','1'),
('receipt_show_taxes','1'),
('receipt_show_tax_ind','1'),
('receipt_show_total_discount','1'),
('receipt_template','receipt_default'),
('receiving_calculate_average_price','0'),
('recv_invoice_format','{CO}'),
('return_policy','Test'),
('sales_invoice_format','{CO}'),
('sales_quote_format','Q%y{QSEQ:6}'),
('smtp_crypto','ssl'),
('smtp_host',''),
('smtp_pass',''),
('smtp_port','465'),
('smtp_timeout','5'),
('smtp_user',''),
('statistics','1'),
('suggestions_first_column','name'),
('suggestions_second_column',''),
('suggestions_third_column',''),
('tax_decimals','2'),
('tax_id',''),
('tax_included','0'),
('theme','flatly'),
('thousands_separator','1'),
('timeformat','H:i:s'),
('timezone','America/New_York'),
('use_destination_based_tax','0'),
('website',''),
('work_order_enable','0'),
('work_order_format','W%y{WSEQ:6}');
/*!40000 ALTER TABLE `ospos_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_definitions`
--

DROP TABLE IF EXISTS `ospos_attribute_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_definitions` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `definition_name` varchar(255) NOT NULL,
  `definition_type` varchar(45) NOT NULL,
  `definition_unit` varchar(16) DEFAULT NULL,
  `definition_flags` tinyint(1) NOT NULL,
  `definition_fk` int(10) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`definition_id`),
  KEY `definition_fk` (`definition_fk`),
  KEY `definition_name` (`definition_name`),
  KEY `definition_type` (`definition_type`),
  CONSTRAINT `fk_ospos_attribute_definitions_ibfk_1` FOREIGN KEY (`definition_fk`) REFERENCES `ospos_attribute_definitions` (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_definitions`
--

LOCK TABLES `ospos_attribute_definitions` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_definitions` DISABLE KEYS */;
INSERT INTO `ospos_attribute_definitions` VALUES
(1,'Expiry Date','DATE',NULL,7,NULL,0),
(2,'New','DROPDOWN',NULL,7,NULL,0),
(3,'Is Shelf Life','CHECKBOX',NULL,7,NULL,0);
/*!40000 ALTER TABLE `ospos_attribute_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_links`
--

DROP TABLE IF EXISTS `ospos_attribute_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_links` (
  `attribute_id` int(11) DEFAULT NULL,
  `definition_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `receiving_id` int(11) DEFAULT NULL,
  `generated_unique_column` varchar(255) GENERATED ALWAYS AS (case when `sale_id` is null and `receiving_id` is null and `item_id` is not null then concat(`definition_id`,'-',`item_id`) else NULL end) STORED,
  UNIQUE KEY `attribute_links_uq1` (`attribute_id`,`definition_id`,`item_id`,`sale_id`,`receiving_id`),
  UNIQUE KEY `attribute_links_uq2` (`item_id`,`receiving_id`,`sale_id`,`definition_id`,`attribute_id`),
  UNIQUE KEY `attribute_links_uq3` (`generated_unique_column`),
  KEY `attribute_id` (`attribute_id`),
  KEY `definition_id` (`definition_id`),
  KEY `item_id` (`item_id`),
  KEY `sale_id` (`sale_id`),
  KEY `receiving_id` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_1` FOREIGN KEY (`definition_id`) REFERENCES `ospos_attribute_definitions` (`definition_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `ospos_attribute_values` (`attribute_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_4` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`),
  CONSTRAINT `ospos_attribute_links_ibfk_5` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_links`
--

LOCK TABLES `ospos_attribute_links` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_links` DISABLE KEYS */;
INSERT INTO `ospos_attribute_links` VALUES
(1,1,1,NULL,NULL,'1-1'),
(2,2,NULL,NULL,NULL,NULL),
(3,2,NULL,NULL,NULL,NULL),
(2,2,1,NULL,NULL,'2-1'),
(4,3,1,NULL,NULL,'3-1'),
(1,1,1,4,NULL,NULL),
(2,2,1,4,NULL,NULL),
(4,3,1,4,NULL,NULL),
(5,1,2,NULL,NULL,'1-2');
/*!40000 ALTER TABLE `ospos_attribute_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_attribute_values`
--

DROP TABLE IF EXISTS `ospos_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_attribute_values` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_value` varchar(255) DEFAULT NULL,
  `attribute_date` date DEFAULT NULL,
  `attribute_decimal` decimal(7,3) DEFAULT NULL,
  PRIMARY KEY (`attribute_id`),
  UNIQUE KEY `attribute_value` (`attribute_value`),
  UNIQUE KEY `attribute_date` (`attribute_date`),
  UNIQUE KEY `attribute_decimal` (`attribute_decimal`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_attribute_values`
--

LOCK TABLES `ospos_attribute_values` WRITE;
/*!40000 ALTER TABLE `ospos_attribute_values` DISABLE KEYS */;
INSERT INTO `ospos_attribute_values` VALUES
(1,NULL,'2026-09-20',NULL),
(2,'A',NULL,NULL),
(3,'B',NULL,NULL),
(4,'1',NULL,NULL),
(5,NULL,'2026-09-24',NULL);
/*!40000 ALTER TABLE `ospos_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_cash_up`
--

DROP TABLE IF EXISTS `ospos_cash_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_cash_up` (
  `cashup_id` int(10) NOT NULL AUTO_INCREMENT,
  `open_date` timestamp NULL DEFAULT current_timestamp(),
  `close_date` timestamp NULL DEFAULT NULL,
  `open_amount_cash` decimal(15,2) NOT NULL,
  `transfer_amount_cash` decimal(15,2) NOT NULL,
  `note` tinyint(4) NOT NULL DEFAULT 0,
  `closed_amount_cash` decimal(15,2) NOT NULL,
  `closed_amount_card` decimal(15,2) NOT NULL,
  `closed_amount_check` decimal(15,2) NOT NULL,
  `closed_amount_total` decimal(15,2) NOT NULL,
  `description` varchar(255) NOT NULL,
  `open_employee_id` int(10) NOT NULL,
  `close_employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `closed_amount_due` decimal(15,2) NOT NULL,
  PRIMARY KEY (`cashup_id`),
  KEY `open_employee_id` (`open_employee_id`),
  KEY `close_employee_id` (`close_employee_id`),
  CONSTRAINT `ospos_cash_up_ibfk_1` FOREIGN KEY (`open_employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_cash_up_ibfk_2` FOREIGN KEY (`close_employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_cash_up`
--

LOCK TABLES `ospos_cash_up` WRITE;
/*!40000 ALTER TABLE `ospos_cash_up` DISABLE KEYS */;
INSERT INTO `ospos_cash_up` VALUES
(1,'2026-09-13 13:13:33','2026-09-13 13:13:33',0.00,0.00,0,0.00,0.00,0.00,0.00,'',2,2,0,0.00);
/*!40000 ALTER TABLE `ospos_cash_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers`
--

DROP TABLE IF EXISTS `ospos_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `taxable` tinyint(1) NOT NULL DEFAULT 1,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `employee_id` int(10) NOT NULL,
  `consent` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sales_tax_code_id` (`sales_tax_code_id`),
  KEY `account_number` (`account_number`),
  KEY `company_name` (`company_name`),
  CONSTRAINT `ospos_customers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`),
  CONSTRAINT `ospos_customers_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_ibfk_3` FOREIGN KEY (`sales_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers`
--

LOCK TABLES `ospos_customers` WRITE;
/*!40000 ALTER TABLE `ospos_customers` DISABLE KEYS */;
INSERT INTO `ospos_customers` VALUES
(3,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-13 13:17:23',1,1),
(4,NULL,NULL,0,'',NULL,NULL,NULL,0,0.00,0,'2026-09-13 13:22:53',1,1);
/*!40000 ALTER TABLE `ospos_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_packages`
--

DROP TABLE IF EXISTS `ospos_customers_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_packages` (
  `package_id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(255) DEFAULT NULL,
  `points_percent` float NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`package_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_packages`
--

LOCK TABLES `ospos_customers_packages` WRITE;
/*!40000 ALTER TABLE `ospos_customers_packages` DISABLE KEYS */;
INSERT INTO `ospos_customers_packages` VALUES
(1,'Default',0,0),
(2,'Bronze',10,0),
(3,'Silver',20,0),
(4,'Gold',30,0),
(5,'Premium',50,0);
/*!40000 ALTER TABLE `ospos_customers_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_customers_points`
--

DROP TABLE IF EXISTS `ospos_customers_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_customers_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `points_earned` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`),
  KEY `package_id` (`package_id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_customers_points_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_customers_points_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `ospos_customers_packages` (`package_id`),
  CONSTRAINT `ospos_customers_points_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_customers_points`
--

LOCK TABLES `ospos_customers_points` WRITE;
/*!40000 ALTER TABLE `ospos_customers_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_customers_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_dinner_tables`
--

DROP TABLE IF EXISTS `ospos_dinner_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_dinner_tables` (
  `dinner_table_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dinner_table_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_dinner_tables`
--

LOCK TABLES `ospos_dinner_tables` WRITE;
/*!40000 ALTER TABLE `ospos_dinner_tables` DISABLE KEYS */;
INSERT INTO `ospos_dinner_tables` VALUES
(1,'Delivery',0,0),
(2,'Take Away',0,0);
/*!40000 ALTER TABLE `ospos_dinner_tables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_employees`
--

DROP TABLE IF EXISTS `ospos_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_employees` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `hash_version` tinyint(1) NOT NULL DEFAULT 2,
  `language` varchar(48) DEFAULT NULL,
  `language_code` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `ospos_employees_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_employees`
--

LOCK TABLES `ospos_employees` WRITE;
/*!40000 ALTER TABLE `ospos_employees` DISABLE KEYS */;
INSERT INTO `ospos_employees` VALUES
('admin','$2y$10$vJBSMlD02EC7ENSrKfVQXuvq9tNRHMtcOA8MSK2NYS748HHWm.gcG',1,0,2,NULL,NULL),
('admin1','$2y$10$57DDuHE6hTzSpfV8ftRU5OfpVbnsiGOAj38dfXg58mwpfpzYOYhoe',2,0,2,'','');
/*!40000 ALTER TABLE `ospos_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expense_categories`
--

DROP TABLE IF EXISTS `ospos_expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expense_categories` (
  `expense_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) DEFAULT NULL,
  `category_description` varchar(255) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`expense_category_id`),
  UNIQUE KEY `category_name` (`category_name`),
  KEY `category_description` (`category_description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expense_categories`
--

LOCK TABLES `ospos_expense_categories` WRITE;
/*!40000 ALTER TABLE `ospos_expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expense_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_expenses`
--

DROP TABLE IF EXISTS `ospos_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_expenses` (
  `expense_id` int(10) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT current_timestamp(),
  `amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `supplier_tax_code` varchar(255) DEFAULT NULL,
  `tax_amount` decimal(15,2) DEFAULT NULL,
  `supplier_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `employee_id` (`employee_id`),
  KEY `date` (`date`),
  KEY `payment_type` (`payment_type`),
  KEY `amount` (`amount`),
  KEY `ospos_expenses_ibfk_3` (`supplier_id`),
  CONSTRAINT `ospos_expenses_ibfk_1` FOREIGN KEY (`expense_category_id`) REFERENCES `ospos_expense_categories` (`expense_category_id`),
  CONSTRAINT `ospos_expenses_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_expenses_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_expenses`
--

LOCK TABLES `ospos_expenses` WRITE;
/*!40000 ALTER TABLE `ospos_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_giftcards`
--

DROP TABLE IF EXISTS `ospos_giftcards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_giftcards` (
  `record_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `giftcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `giftcard_number` varchar(255) DEFAULT NULL,
  `value` decimal(15,2) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `person_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`giftcard_id`),
  UNIQUE KEY `giftcard_number` (`giftcard_number`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `ospos_giftcards_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_giftcards`
--

LOCK TABLES `ospos_giftcards` WRITE;
/*!40000 ALTER TABLE `ospos_giftcards` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_giftcards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_grants`
--

DROP TABLE IF EXISTS `ospos_grants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_grants` (
  `permission_id` varchar(255) NOT NULL,
  `person_id` int(10) NOT NULL,
  `menu_group` varchar(32) DEFAULT 'home',
  PRIMARY KEY (`permission_id`,`person_id`),
  KEY `ospos_grants_ibfk_2` (`person_id`),
  CONSTRAINT `ospos_grants_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `ospos_permissions` (`permission_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_grants_ibfk_2` FOREIGN KEY (`person_id`) REFERENCES `ospos_employees` (`person_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_grants`
--

LOCK TABLES `ospos_grants` WRITE;
/*!40000 ALTER TABLE `ospos_grants` DISABLE KEYS */;
INSERT INTO `ospos_grants` VALUES
('attributes',1,'office'),
('cashups',1,'home'),
('cashups',2,'office'),
('config',1,'office'),
('customers',1,'home'),
('employees',1,'office'),
('expenses',1,'home'),
('expenses_categories',1,'office'),
('giftcards',1,'home'),
('home',1,'office'),
('items',1,'home'),
('items_stock',1,'home'),
('item_kits',1,'home'),
('messages',1,'home'),
('office',1,'home'),
('receivings',1,'home'),
('receivings_stock',1,'home'),
('reports',1,'home'),
('reports_categories',1,'home'),
('reports_customers',1,'home'),
('reports_discounts',1,'home'),
('reports_employees',1,'home'),
('reports_expenses_categories',1,'home'),
('reports_inventory',1,'home'),
('reports_items',1,'home'),
('reports_payments',1,'home'),
('reports_receivings',1,'home'),
('reports_sales',1,'home'),
('reports_sales_taxes',1,'home'),
('reports_suppliers',1,'home'),
('reports_taxes',1,'home'),
('sales',1,'home'),
('sales',2,'both'),
('sales_change_price',1,'--'),
('sales_change_price',2,'--'),
('sales_delete',1,'--'),
('sales_delete',2,'--'),
('sales_stock',1,'home'),
('sales_stock',2,'--'),
('suppliers',1,'home');
/*!40000 ALTER TABLE `ospos_grants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_inventory`
--

DROP TABLE IF EXISTS `ospos_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_inventory` (
  `trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `trans_items` int(11) NOT NULL DEFAULT 0,
  `trans_user` int(11) NOT NULL DEFAULT 0,
  `trans_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `trans_comment` text NOT NULL,
  `trans_location` int(11) NOT NULL,
  `trans_inventory` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`trans_id`),
  KEY `trans_items` (`trans_items`),
  KEY `trans_user` (`trans_user`),
  KEY `trans_location` (`trans_location`),
  KEY `trans_date` (`trans_date`),
  KEY `trans_items_trans_date` (`trans_items`,`trans_date`),
  CONSTRAINT `ospos_inventory_ibfk_1` FOREIGN KEY (`trans_items`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_inventory_ibfk_2` FOREIGN KEY (`trans_user`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_inventory_ibfk_3` FOREIGN KEY (`trans_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_inventory`
--

LOCK TABLES `ospos_inventory` WRITE;
/*!40000 ALTER TABLE `ospos_inventory` DISABLE KEYS */;
INSERT INTO `ospos_inventory` VALUES
(1,1,1,'2026-09-13 12:47:09','Manual Edit of Quantity',1,0.000),
(2,1,2,'2026-09-13 13:12:28','POS 1',1,-90.000),
(3,1,1,'2026-09-13 13:15:55','Manual Edit of Quantity',1,20090.000),
(4,1,1,'2026-09-13 13:20:53','POS 2',1,-11.000),
(5,1,1,'2026-09-13 13:23:09','POS 3',1,-1.000),
(6,2,1,'2026-09-13 13:53:16','Manual Edit of Quantity',1,0.000),
(7,1,1,'2026-09-14 07:38:50','POS 4',1,-2.000),
(8,2,1,'2026-09-15 08:45:52','Manual Edit of Quantity',1,200.000),
(9,3,1,'2026-09-15 10:00:06','Manual Edit of Quantity',1,0.000),
(10,4,1,'2026-09-15 10:00:11','Manual Edit of Quantity',1,0.000),
(11,5,1,'2026-09-15 10:00:19','Manual Edit of Quantity',1,0.000),
(12,6,1,'2026-09-15 10:00:25','Manual Edit of Quantity',1,0.000),
(13,7,1,'2026-09-15 10:00:33','Manual Edit of Quantity',1,0.000),
(14,8,1,'2026-09-15 10:00:40','Manual Edit of Quantity',1,0.000),
(15,9,1,'2026-09-15 10:00:47','Manual Edit of Quantity',1,0.000),
(16,10,1,'2026-09-15 10:00:55','Manual Edit of Quantity',1,0.000),
(17,11,1,'2026-09-15 10:01:00','Manual Edit of Quantity',1,0.000),
(18,12,1,'2026-09-15 10:01:08','Manual Edit of Quantity',1,0.000),
(19,13,1,'2026-09-15 10:01:13','Manual Edit of Quantity',1,0.000),
(20,14,1,'2026-09-15 10:01:23','Manual Edit of Quantity',1,0.000),
(21,15,1,'2026-09-15 10:01:29','Manual Edit of Quantity',1,0.000),
(22,16,1,'2026-09-15 10:01:35','Manual Edit of Quantity',1,0.000),
(23,17,1,'2026-09-15 10:01:42','Manual Edit of Quantity',1,0.000),
(24,18,1,'2026-09-15 10:01:54','Manual Edit of Quantity',1,0.000),
(25,19,1,'2026-09-15 10:02:00','Manual Edit of Quantity',1,0.000),
(26,20,1,'2026-09-15 10:02:06','Manual Edit of Quantity',1,0.000),
(27,21,1,'2026-09-15 10:02:12','Manual Edit of Quantity',1,0.000),
(28,22,1,'2026-09-15 10:02:18','Manual Edit of Quantity',1,0.000),
(29,23,1,'2026-09-15 10:02:23','Manual Edit of Quantity',1,0.000),
(30,24,1,'2026-09-15 10:02:28','Manual Edit of Quantity',1,0.000),
(31,3,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(32,12,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(33,13,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(34,11,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(35,10,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(36,9,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(37,24,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(38,18,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(39,20,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(40,4,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(41,22,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(42,23,1,'2026-09-15 10:03:34','POS 5',1,-2.000),
(43,17,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(44,16,1,'2026-09-15 10:03:34','POS 5',1,-1.000),
(45,3,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(46,4,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(47,5,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(48,6,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(49,7,1,'2026-09-15 10:09:00','POS 6',1,-2.000),
(50,8,1,'2026-09-15 10:09:00','POS 6',1,-1.000),
(51,9,1,'2026-09-15 10:09:00','POS 6',1,-1.000);
/*!40000 ALTER TABLE `ospos_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kit_items`
--

DROP TABLE IF EXISTS `ospos_item_kit_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kit_items` (
  `item_kit_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `kit_sequence` int(3) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`,`item_id`,`quantity`),
  KEY `ospos_item_kit_items_ibfk_2` (`item_id`),
  CONSTRAINT `ospos_item_kit_items_ibfk_1` FOREIGN KEY (`item_kit_id`) REFERENCES `ospos_item_kits` (`item_kit_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_item_kit_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kit_items`
--

LOCK TABLES `ospos_item_kit_items` WRITE;
/*!40000 ALTER TABLE `ospos_item_kit_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kit_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_kits`
--

DROP TABLE IF EXISTS `ospos_item_kits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_kits` (
  `item_kit_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_kit_number` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `kit_discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `kit_discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `price_option` tinyint(1) NOT NULL DEFAULT 0,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`item_kit_id`),
  KEY `item_kit_number` (`item_kit_number`),
  KEY `name` (`name`,`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_kits`
--

LOCK TABLES `ospos_item_kits` WRITE;
/*!40000 ALTER TABLE `ospos_item_kits` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_item_kits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_item_quantities`
--

DROP TABLE IF EXISTS `ospos_item_quantities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_item_quantities` (
  `item_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `quantity` decimal(15,3) NOT NULL DEFAULT 0.000,
  PRIMARY KEY (`item_id`,`location_id`),
  KEY `item_id` (`item_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_item_quantities_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_item_quantities`
--

LOCK TABLES `ospos_item_quantities` WRITE;
/*!40000 ALTER TABLE `ospos_item_quantities` DISABLE KEYS */;
INSERT INTO `ospos_item_quantities` VALUES
(1,1,19986.000),
(2,1,200.000),
(3,1,-3.000),
(4,1,-2.000),
(5,1,-1.000),
(6,1,-1.000),
(7,1,-2.000),
(8,1,-1.000),
(9,1,-2.000),
(10,1,-1.000),
(11,1,-2.000),
(12,1,-2.000),
(13,1,-1.000),
(14,1,0.000),
(15,1,0.000),
(16,1,-1.000),
(17,1,-1.000),
(18,1,-2.000),
(19,1,0.000),
(20,1,-1.000),
(21,1,0.000),
(22,1,-1.000),
(23,1,-2.000),
(24,1,-2.000);
/*!40000 ALTER TABLE `ospos_item_quantities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items`
--

DROP TABLE IF EXISTS `ospos_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items` (
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `item_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `reorder_level` decimal(15,3) NOT NULL DEFAULT 0.000,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  `item_id` int(10) NOT NULL AUTO_INCREMENT,
  `pic_filename` varchar(255) DEFAULT NULL,
  `allow_alt_description` tinyint(1) NOT NULL,
  `is_serialized` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `stock_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_type` tinyint(1) NOT NULL DEFAULT 0,
  `tax_category_id` int(11) DEFAULT NULL,
  `qty_per_pack` decimal(15,3) NOT NULL DEFAULT 1.000,
  `pack_name` varchar(8) DEFAULT 'Each',
  `low_sell_item_id` int(10) DEFAULT 0,
  `hsn_code` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `items_uq1` (`supplier_id`,`item_id`,`deleted`,`item_type`),
  KEY `supplier_id` (`supplier_id`),
  KEY `item_number` (`item_number`),
  KEY `deleted` (`deleted`,`item_type`),
  KEY `item_id` (`item_id`,`deleted`),
  CONSTRAINT `ospos_items_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items`
--

LOCK TABLES `ospos_items` WRITE;
/*!40000 ALTER TABLE `ospos_items` DISABLE KEYS */;
INSERT INTO `ospos_items` VALUES
('Coca Cola 1.5L','Beverage',NULL,'Coca Cola 1.5L','',190.00,200.00,10.000,20000.000,1,NULL,0,0,0,0,0,NULL,1.000,'Each',1,''),
('Coca Cola 1L','Beverage',NULL,'011235698702','',20.00,20.00,10.000,10.000,2,NULL,0,0,0,0,0,NULL,1.000,'Each',2,''),
('Test 1','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,3,NULL,0,0,0,0,0,NULL,1.000,'Each',3,''),
('Test 2','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,4,NULL,0,0,0,0,0,NULL,1.000,'Each',4,''),
('Test 3','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,5,NULL,0,0,0,0,0,NULL,1.000,'Each',5,''),
('Test 4','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,6,NULL,0,0,0,0,0,NULL,1.000,'Each',6,''),
('Test 5','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,7,NULL,0,0,0,0,0,NULL,1.000,'Each',7,''),
('Test 6','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,8,NULL,0,0,0,0,0,NULL,1.000,'Each',8,''),
('Test 7','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,9,NULL,0,0,0,0,0,NULL,1.000,'Each',9,''),
('Test 8','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,10,NULL,0,0,0,0,0,NULL,1.000,'Each',10,''),
('Test 9','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,11,NULL,0,0,0,0,0,NULL,1.000,'Each',11,''),
('Test 10','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,12,NULL,0,0,0,0,0,NULL,1.000,'Each',12,''),
('Test 11','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,13,NULL,0,0,0,0,0,NULL,1.000,'Each',13,''),
('Test 12','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,14,NULL,0,0,0,0,0,NULL,1.000,'Each',14,''),
('Test 13','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,15,NULL,0,0,0,0,0,NULL,1.000,'Each',15,''),
('Test 14','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,16,NULL,0,0,0,0,0,NULL,1.000,'Each',16,''),
('Test 15','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,17,NULL,0,0,0,0,0,NULL,1.000,'Each',17,''),
('Test 16','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,18,NULL,0,0,0,0,0,NULL,1.000,'Each',18,''),
('Test 17','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,19,NULL,0,0,0,0,0,NULL,1.000,'Each',19,''),
('Test 18','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,20,NULL,0,0,0,0,0,NULL,1.000,'Each',20,''),
('Test 19','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,21,NULL,0,0,0,0,0,NULL,1.000,'Each',21,''),
('Test 20','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,22,NULL,0,0,0,0,0,NULL,1.000,'Each',22,''),
('Test 21','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,23,NULL,0,0,0,0,0,NULL,1.000,'Each',23,''),
('Test 22','Beverage',NULL,NULL,'',0.00,0.00,1.000,1.000,24,NULL,0,0,0,0,0,NULL,1.000,'Each',24,'');
/*!40000 ALTER TABLE `ospos_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_items_taxes`
--

DROP TABLE IF EXISTS `ospos_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_items_taxes` (
  `item_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,3) NOT NULL,
  PRIMARY KEY (`item_id`,`name`,`percent`),
  CONSTRAINT `ospos_items_taxes_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_items_taxes`
--

LOCK TABLES `ospos_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_migrations`
--

DROP TABLE IF EXISTS `ospos_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_migrations`
--

LOCK TABLES `ospos_migrations` WRITE;
/*!40000 ALTER TABLE `ospos_migrations` DISABLE KEYS */;
INSERT INTO `ospos_migrations` VALUES
(1,'20170501000000','App\\Database\\Migrations\\Migration_Initial_Schema','default','App',1789267453,1),
(2,'20170501150000','App\\Database\\Migrations\\Migration_Upgrade_To_3_1_1','default','App',1789267453,1),
(3,'20170502221506','App\\Database\\Migrations\\Migration_Sales_Tax_Data','default','App',1789267453,1),
(4,'20180225100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_0','default','App',1789267453,1),
(5,'20180501100000','App\\Database\\Migrations\\Migration_Upgrade_To_3_2_1','default','App',1789267453,1),
(6,'20181015100000','App\\Database\\Migrations\\Migration_Attributes','default','App',1789267453,1),
(7,'20190111270000','App\\Database\\Migrations\\Migration_Upgrade_To_3_3_0','default','App',1789267453,1),
(8,'20190129212600','App\\Database\\Migrations\\Migration_IndiaGST','default','App',1789267454,1),
(9,'20190213210000','App\\Database\\Migrations\\Migration_IndiaGST1','default','App',1789267454,1),
(10,'20190220210000','App\\Database\\Migrations\\Migration_IndiaGST2','default','App',1789267454,1),
(11,'20190301124900','App\\Database\\Migrations\\Migration_decimal_attribute_type','default','App',1789267454,1),
(12,'20190317102600','App\\Database\\Migrations\\Migration_add_iso_4217','default','App',1789267454,1),
(13,'20190427100000','App\\Database\\Migrations\\Migration_PaymentTracking','default','App',1789267454,1),
(14,'20190502100000','App\\Database\\Migrations\\Migration_RefundTracking','default','App',1789267454,1),
(15,'20190612100000','App\\Database\\Migrations\\Migration_DBFix','default','App',1789267454,1),
(16,'20190615100000','App\\Database\\Migrations\\Migration_fix_attribute_datetime','default','App',1789267454,1),
(17,'20190712150200','App\\Database\\Migrations\\Migration_fix_empty_reports','default','App',1789267454,1),
(18,'20191008100000','App\\Database\\Migrations\\Migration_receipttaxindicator','default','App',1789267454,1),
(19,'20191231100000','App\\Database\\Migrations\\Migration_PaymentDateFix','default','App',1789267454,1),
(20,'20200125100000','App\\Database\\Migrations\\Migration_SalesChangePrice','default','App',1789267454,1),
(21,'20200202000000','App\\Database\\Migrations\\Migration_TaxAmount','default','App',1789267454,1),
(22,'20200215100000','App\\Database\\Migrations\\Migration_taxgroupconstraint','default','App',1789267454,1),
(23,'20200508000000','App\\Database\\Migrations\\Migration_image_upload_defaults','default','App',1789267454,1),
(24,'20200819000000','App\\Database\\Migrations\\Migration_modify_attr_links_constraint','default','App',1789267454,1),
(25,'20201108100000','App\\Database\\Migrations\\Migration_cashrounding','default','App',1789267454,1),
(26,'20201110000000','App\\Database\\Migrations\\Migration_add_item_kit_number','default','App',1789267454,1),
(27,'20210103000000','App\\Database\\Migrations\\Migration_modify_session_datatype','default','App',1789267454,1),
(28,'20210422000000','App\\Database\\Migrations\\Migration_database_optimizations','default','App',1789267454,1),
(29,'20210422000001','App\\Database\\Migrations\\Migration_remove_duplicate_links','default','App',1789267454,1),
(30,'20210714140000','App\\Database\\Migrations\\Migration_move_expenses_categories','default','App',1789267454,1),
(31,'20220127000000','App\\Database\\Migrations\\ConvertToCI4','default','App',1789267454,1),
(32,'20230307000000','App\\Database\\Migrations\\IntToTinyint','default','App',1789267454,1),
(33,'20230412000000','App\\Database\\Migrations\\Migration_add_missing_config','default','App',1789267454,1),
(34,'20230412000001','App\\Database\\Migrations\\Migration_drop_account_number_index','default','App',1789267454,1),
(35,'20240319000000','App\\Database\\Migrations\\Migration_Convert_Barcode_Types','default','App',1789267454,1),
(36,'20240630000001','App\\Database\\Migrations\\Migration_fix_keys_for_db_upgrade','default','App',1789267454,1),
(37,'20240826000000','App\\Database\\Migrations\\fix_duplicate_attributes','default','App',1789267454,1),
(38,'20250213000000','App\\Database\\Migrations\\Migration_Attributes_fix_cascading_delete','default','App',1789267454,1),
(39,'20250425000000','App\\Database\\Migrations\\Migration_sessions_migration','default','App',1789267454,1),
(40,'20250519000000','App\\Database\\Migrations\\MigrationOptimizationIndices','default','App',1789267454,1),
(41,'20250521000000','App\\Database\\Migrations\\FixImageFilenameSpaces','default','App',1789267454,1),
(42,'20250522000000','App\\Database\\Migrations\\AttributeLinksUniqueConstraint','default','App',1789267454,1),
(43,'20250716170000','App\\Database\\Migrations\\Migration_MissingConfigKeys','default','App',1789267454,1),
(44,'20250729170000','App\\Database\\Migrations\\Migration_NullableTaxCategoryId','default','App',1789267454,1),
(45,'20260506000000','App\\Database\\Migrations\\AddShortcutKeys','default','App',1789267454,1);
/*!40000 ALTER TABLE `ospos_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_modules`
--

DROP TABLE IF EXISTS `ospos_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_modules` (
  `name_lang_key` varchar(255) NOT NULL,
  `desc_lang_key` varchar(255) NOT NULL,
  `sort` int(10) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `desc_lang_key` (`desc_lang_key`),
  UNIQUE KEY `name_lang_key` (`name_lang_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_modules`
--

LOCK TABLES `ospos_modules` WRITE;
/*!40000 ALTER TABLE `ospos_modules` DISABLE KEYS */;
INSERT INTO `ospos_modules` VALUES
('module_attributes','module_attributes_desc',107,'attributes'),
('module_cashups','module_cashups_desc',110,'cashups'),
('module_config','module_config_desc',900,'config'),
('module_customers','module_customers_desc',10,'customers'),
('module_employees','module_employees_desc',80,'employees'),
('module_expenses','module_expenses_desc',108,'expenses'),
('module_expenses_categories','module_expenses_categories_desc',109,'expenses_categories'),
('module_giftcards','module_giftcards_desc',90,'giftcards'),
('module_home','module_home_desc',1,'home'),
('module_items','module_items_desc',20,'items'),
('module_item_kits','module_item_kits_desc',30,'item_kits'),
('module_messages','module_messages_desc',98,'messages'),
('module_office','module_office_desc',999,'office'),
('module_receivings','module_receivings_desc',60,'receivings'),
('module_reports','module_reports_desc',50,'reports'),
('module_sales','module_sales_desc',70,'sales'),
('module_suppliers','module_suppliers_desc',40,'suppliers'),
('module_taxes','module_taxes_desc',105,'taxes');
/*!40000 ALTER TABLE `ospos_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_people`
--

DROP TABLE IF EXISTS `ospos_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_people` (
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(1) DEFAULT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`person_id`),
  KEY `email` (`email`),
  KEY `first_name` (`first_name`,`last_name`,`email`,`phone_number`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_people`
--

LOCK TABLES `ospos_people` WRITE;
/*!40000 ALTER TABLE `ospos_people` DISABLE KEYS */;
INSERT INTO `ospos_people` VALUES
('John','Doe',NULL,'555-555-5555','changeme@example.com','Address 1','','','','','','',1),
('Admin','Admin',1,'','admin@gmail.com','','','','','','','',2),
('Zahidul','Islam',1,'+9230158043754','changeme@example.com','Street # 4, Makkah Town, Khudian, Kasur','','Kasur','','','Pakistan','',3),
('Alex','Alex',NULL,'','','','','','','','','',4),
('Umair','Umair',1,'','','','','','','','','',5),
('Usman','Usman',NULL,'','','','','','','','','',6);
/*!40000 ALTER TABLE `ospos_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_permissions`
--

DROP TABLE IF EXISTS `ospos_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_permissions` (
  `permission_id` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `location_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`permission_id`),
  KEY `module_id` (`module_id`),
  KEY `ospos_permissions_ibfk_2` (`location_id`),
  CONSTRAINT `ospos_permissions_ibfk_1` FOREIGN KEY (`module_id`) REFERENCES `ospos_modules` (`module_id`) ON DELETE CASCADE,
  CONSTRAINT `ospos_permissions_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `ospos_stock_locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_permissions`
--

LOCK TABLES `ospos_permissions` WRITE;
/*!40000 ALTER TABLE `ospos_permissions` DISABLE KEYS */;
INSERT INTO `ospos_permissions` VALUES
('attributes','attributes',NULL),
('cashups','cashups',NULL),
('config','config',NULL),
('customers','customers',NULL),
('employees','employees',NULL),
('expenses','expenses',NULL),
('expenses_categories','expenses_categories',NULL),
('giftcards','giftcards',NULL),
('home','home',NULL),
('items','items',NULL),
('items_stock','items',1),
('item_kits','item_kits',NULL),
('messages','messages',NULL),
('office','office',NULL),
('receivings','receivings',NULL),
('receivings_stock','receivings',1),
('reports','reports',NULL),
('reports_categories','reports',NULL),
('reports_customers','reports',NULL),
('reports_discounts','reports',NULL),
('reports_employees','reports',NULL),
('reports_expenses_categories','reports',NULL),
('reports_inventory','reports',NULL),
('reports_items','reports',NULL),
('reports_payments','reports',NULL),
('reports_receivings','reports',NULL),
('reports_sales','reports',NULL),
('reports_sales_taxes','reports',NULL),
('reports_suppliers','reports',NULL),
('reports_taxes','reports',NULL),
('sales','sales',NULL),
('sales_change_price','sales',NULL),
('sales_delete','sales',NULL),
('sales_stock','sales',1),
('suppliers','suppliers',NULL),
('taxes','taxes',NULL);
/*!40000 ALTER TABLE `ospos_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings`
--

DROP TABLE IF EXISTS `ospos_receivings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings` (
  `receiving_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `supplier_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `receiving_id` int(10) NOT NULL AUTO_INCREMENT,
  `payment_type` varchar(20) DEFAULT NULL,
  `reference` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`receiving_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `employee_id` (`employee_id`),
  KEY `reference` (`reference`),
  KEY `receiving_time` (`receiving_time`),
  CONSTRAINT `ospos_receivings_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_receivings_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `ospos_suppliers` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings`
--

LOCK TABLES `ospos_receivings` WRITE;
/*!40000 ALTER TABLE `ospos_receivings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_receivings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_receivings_items`
--

DROP TABLE IF EXISTS `ospos_receivings_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_receivings_items` (
  `receiving_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(30) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `receiving_quantity` decimal(15,3) NOT NULL DEFAULT 1.000,
  PRIMARY KEY (`receiving_id`,`item_id`,`line`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_receivings_items_ibfk_2` FOREIGN KEY (`receiving_id`) REFERENCES `ospos_receivings` (`receiving_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_receivings_items`
--

LOCK TABLES `ospos_receivings_items` WRITE;
/*!40000 ALTER TABLE `ospos_receivings_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_receivings_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales`
--

DROP TABLE IF EXISTS `ospos_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales` (
  `sale_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `customer_id` int(10) DEFAULT NULL,
  `employee_id` int(10) NOT NULL DEFAULT 0,
  `comment` text NOT NULL,
  `invoice_number` varchar(32) DEFAULT NULL,
  `dinner_table_id` int(11) DEFAULT NULL,
  `sale_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_number` varchar(32) DEFAULT NULL,
  `sale_status` tinyint(1) NOT NULL DEFAULT 0,
  `work_order_number` varchar(32) DEFAULT NULL,
  `sale_type` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`),
  KEY `employee_id` (`employee_id`),
  KEY `sale_time` (`sale_time`),
  KEY `dinner_table_id` (`dinner_table_id`),
  CONSTRAINT `ospos_sales_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `ospos_customers` (`person_id`),
  CONSTRAINT `ospos_sales_ibfk_3` FOREIGN KEY (`dinner_table_id`) REFERENCES `ospos_dinner_tables` (`dinner_table_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales`
--

LOCK TABLES `ospos_sales` WRITE;
/*!40000 ALTER TABLE `ospos_sales` DISABLE KEYS */;
INSERT INTO `ospos_sales` VALUES
('2026-09-13 13:12:28',NULL,2,'',NULL,NULL,1,NULL,0,NULL,0),
('2026-09-13 13:20:53',NULL,1,'',NULL,NULL,2,NULL,0,NULL,0),
('2026-09-13 13:23:09',4,1,'',NULL,NULL,3,NULL,0,NULL,0),
('2026-09-14 07:38:50',NULL,1,'',NULL,NULL,4,NULL,0,NULL,0),
('2026-09-15 10:03:34',NULL,1,'','5',NULL,5,NULL,0,NULL,0),
('2026-09-15 10:09:00',4,1,'','1',NULL,6,NULL,0,NULL,1);
/*!40000 ALTER TABLE `ospos_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items`
--

DROP TABLE IF EXISTS `ospos_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items` (
  `sale_id` int(10) NOT NULL DEFAULT 0,
  `item_id` int(10) NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `serialnumber` varchar(30) DEFAULT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `quantity_purchased` decimal(15,3) NOT NULL DEFAULT 0.000,
  `item_cost_price` decimal(15,2) NOT NULL,
  `item_unit_price` decimal(15,2) NOT NULL,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_type` tinyint(1) NOT NULL DEFAULT 0,
  `item_location` int(11) NOT NULL,
  `print_option` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sale_id`,`item_id`,`line`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  KEY `item_location` (`item_location`),
  CONSTRAINT `ospos_sales_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`),
  CONSTRAINT `ospos_sales_items_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_items_ibfk_3` FOREIGN KEY (`item_location`) REFERENCES `ospos_stock_locations` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items`
--

LOCK TABLES `ospos_sales_items` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items` DISABLE KEYS */;
INSERT INTO `ospos_sales_items` VALUES
(1,1,'','',1,90.000,0.00,0.00,0.00,0,1,0),
(2,1,'','',1,11.000,0.00,0.00,0.00,0,1,0),
(3,1,'','',1,1.000,190.00,200.00,0.00,0,1,0),
(4,1,'','',1,2.000,190.00,200.00,0.00,0,1,0),
(5,3,'','',1,2.000,0.00,0.00,0.00,0,1,0),
(5,4,'','',10,1.000,0.00,0.00,0.00,0,1,0),
(5,9,'','',6,1.000,0.00,0.00,0.00,0,1,0),
(5,10,'','',5,1.000,0.00,0.00,0.00,0,1,0),
(5,11,'','',4,2.000,0.00,0.00,0.00,0,1,0),
(5,12,'','',2,2.000,0.00,0.00,0.00,0,1,0),
(5,13,'','',3,1.000,0.00,0.00,0.00,0,1,0),
(5,16,'','',14,1.000,0.00,0.00,0.00,0,1,0),
(5,17,'','',13,1.000,0.00,0.00,0.00,0,1,0),
(5,18,'','',8,2.000,0.00,0.00,0.00,0,1,0),
(5,20,'','',9,1.000,0.00,0.00,0.00,0,1,0),
(5,22,'','',11,1.000,0.00,0.00,0.00,0,1,0),
(5,23,'','',12,2.000,0.00,0.00,0.00,0,1,0),
(5,24,'','',7,2.000,0.00,0.00,0.00,0,1,0),
(6,3,'','',1,1.000,0.00,0.00,0.00,0,1,0),
(6,4,'','',2,1.000,0.00,0.00,0.00,0,1,0),
(6,5,'','',3,1.000,0.00,0.00,0.00,0,1,0),
(6,6,'','',4,1.000,0.00,0.00,0.00,0,1,0),
(6,7,'','',5,2.000,0.00,0.00,0.00,0,1,0),
(6,8,'','',6,1.000,0.00,0.00,0.00,0,1,0),
(6,9,'','',7,1.000,0.00,0.00,0.00,0,1,0);
/*!40000 ALTER TABLE `ospos_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_items_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_items_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_items_taxes` (
  `sale_id` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `line` int(3) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `percent` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_type` tinyint(1) NOT NULL DEFAULT 0,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `item_tax_amount` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sale_id`,`item_id`,`line`,`name`,`percent`),
  KEY `sale_id` (`sale_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_1` FOREIGN KEY (`sale_id`, `item_id`, `line`) REFERENCES `ospos_sales_items` (`sale_id`, `item_id`, `line`),
  CONSTRAINT `ospos_sales_items_taxes_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `ospos_items` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_items_taxes`
--

LOCK TABLES `ospos_sales_items_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_items_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_payments`
--

DROP TABLE IF EXISTS `ospos_sales_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `payment_type` varchar(40) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL,
  `cash_refund` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cash_adjustment` tinyint(4) NOT NULL DEFAULT 0,
  `employee_id` int(11) DEFAULT NULL,
  `payment_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`payment_id`),
  KEY `payment_sale` (`sale_id`,`payment_type`),
  KEY `employee_id` (`employee_id`),
  KEY `payment_time` (`payment_time`),
  CONSTRAINT `ospos_sales_payments_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`),
  CONSTRAINT `ospos_sales_payments_ibfk_2` FOREIGN KEY (`employee_id`) REFERENCES `ospos_employees` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_payments`
--

LOCK TABLES `ospos_sales_payments` WRITE;
/*!40000 ALTER TABLE `ospos_sales_payments` DISABLE KEYS */;
INSERT INTO `ospos_sales_payments` VALUES
(1,3,'Due',200.00,0.00,0,1,'2026-09-13 17:23:09',''),
(2,4,'Cash',400.00,0.00,0,1,'2026-09-14 11:38:50','');
/*!40000 ALTER TABLE `ospos_sales_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_reward_points`
--

DROP TABLE IF EXISTS `ospos_sales_reward_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_reward_points` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `earned` float NOT NULL,
  `used` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  CONSTRAINT `ospos_sales_reward_points_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `ospos_sales` (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_reward_points`
--

LOCK TABLES `ospos_sales_reward_points` WRITE;
/*!40000 ALTER TABLE `ospos_sales_reward_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_reward_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sales_taxes`
--

DROP TABLE IF EXISTS `ospos_sales_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sales_taxes` (
  `sales_taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) NOT NULL,
  `jurisdiction_id` int(11) DEFAULT NULL,
  `tax_category_id` int(11) DEFAULT NULL,
  `tax_type` smallint(2) NOT NULL,
  `tax_group` varchar(32) NOT NULL,
  `sale_tax_basis` decimal(15,4) NOT NULL,
  `sale_tax_amount` decimal(15,4) NOT NULL,
  `print_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL,
  `sales_tax_code_id` int(11) DEFAULT NULL,
  `rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`sales_taxes_id`),
  KEY `print_sequence` (`sale_id`,`print_sequence`,`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sales_taxes`
--

LOCK TABLES `ospos_sales_taxes` WRITE;
/*!40000 ALTER TABLE `ospos_sales_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_sales_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_sessions`
--

DROP TABLE IF EXISTS `ospos_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` blob NOT NULL,
  PRIMARY KEY (`id`,`ip_address`),
  KEY `ospos_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_sessions`
--

LOCK TABLES `ospos_sessions` WRITE;
/*!40000 ALTER TABLE `ospos_sessions` DISABLE KEYS */;
INSERT INTO `ospos_sessions` VALUES
('ospos_session:01fcf7626c4e2db967cfdd85a62ff521','127.0.0.1','2026-09-15 13:59:58','__ci_last_regenerate|i:1789480798;csrf_ospos_v4|s:32:\"97c550a4d0fa64f7caa36cda456fc7a8\";'),
('ospos_session:041fa664e387cf5182b3855165f8782a','127.0.0.1','2026-09-15 12:51:17','__ci_last_regenerate|i:1789476677;csrf_ospos_v4|s:32:\"7c680a376a7a62ec7a0b7dfef4a44a8b\";'),
('ospos_session:04e22bc7b0e09357b258caaa58619c7a','127.0.0.1','2026-09-15 12:52:18','__ci_last_regenerate|i:1789476738;csrf_ospos_v4|s:32:\"905a369e347587241ed544f717aa1c20\";'),
('ospos_session:0598bcb2c1bb11367ac8597a2d6d9fdb','127.0.0.1','2026-09-15 13:53:57','__ci_last_regenerate|i:1789480437;csrf_ospos_v4|s:32:\"9428a7c0e538bda206fed8451cf7a428\";'),
('ospos_session:0744d08d2fb7e9e03e533a7a68344bf6','127.0.0.1','2026-09-15 14:20:30','__ci_last_regenerate|i:1789482030;csrf_ospos_v4|s:32:\"7f4668647f8460852054952653c8262b\";'),
('ospos_session:0b7ff0dd1f4f1e71bc7b90763c96aebd','127.0.0.1','2026-09-15 14:07:59','__ci_last_regenerate|i:1789481279;csrf_ospos_v4|s:32:\"8ae9254cf39acec87158169cebd15df5\";'),
('ospos_session:0bc590906446d6b01875c0d72dd2c32b','127.0.0.1','2026-09-15 14:11:59','__ci_last_regenerate|i:1789481519;csrf_ospos_v4|s:32:\"0f164df0a24e49b152c1633be41d9b2e\";'),
('ospos_session:0fa2d245b17aec4f2bb54decb3ecb074','127.0.0.1','2026-09-15 12:42:46','__ci_last_regenerate|i:1789476166;csrf_ospos_v4|s:32:\"d17adb5334f1f372a1cf191936e160da\";'),
('ospos_session:10d15aa60ea7e6f05e25e5d4af0a0401','127.0.0.1','2026-09-15 13:51:27','__ci_last_regenerate|i:1789480287;csrf_ospos_v4|s:32:\"d763b1bc7b599d618e060da0f9bbb04d\";'),
('ospos_session:111dee247e852b389ed8ac849c75de50','127.0.0.1','2026-09-15 13:04:19','__ci_last_regenerate|i:1789477459;csrf_ospos_v4|s:32:\"efec81479ec5e4bafe13d6b4054381dd\";'),
('ospos_session:11d5dc3ac60c3271e3e9b52d6b977436','127.0.0.1','2026-09-15 13:02:19','__ci_last_regenerate|i:1789477339;csrf_ospos_v4|s:32:\"fed6a66a15d213afd2a97ed8e4f33b9d\";'),
('ospos_session:12bf59568b3a118660484cd4e54aff50','127.0.0.1','2026-09-15 14:09:29','__ci_last_regenerate|i:1789481369;csrf_ospos_v4|s:32:\"71036eb7be5fc430f37e0204b86fba0f\";'),
('ospos_session:13620b3acc4ca28ec3ddbed329026c1f','127.0.0.1','2026-09-15 14:03:58','__ci_last_regenerate|i:1789481038;csrf_ospos_v4|s:32:\"7427340af117c605ff8e2d563119fac6\";'),
('ospos_session:181b1b75ffedceb4a7c75adeb368f269','127.0.0.1','2026-09-15 12:51:48','__ci_last_regenerate|i:1789476708;csrf_ospos_v4|s:32:\"b97378a36bff21caf82701e84512a1a3\";'),
('ospos_session:18c1a3dda798f06c7c57d1d96ab492c7','127.0.0.1','2026-09-15 13:42:55','__ci_last_regenerate|i:1789479775;csrf_ospos_v4|s:32:\"ea9dcedcc3f5ff559345508ed92eba96\";'),
('ospos_session:197420b2c7711af9b862b1c7ef6272eb','127.0.0.1','2026-09-15 12:57:18','__ci_last_regenerate|i:1789477038;csrf_ospos_v4|s:32:\"325872696b6bd90f41fd6050431f4e06\";'),
('ospos_session:1afee73de2572d7f4e534b68a0a4a931','127.0.0.1','2026-09-15 13:11:21','__ci_last_regenerate|i:1789477881;csrf_ospos_v4|s:32:\"572e6a2cc4c86d726442e6ec79304bf4\";'),
('ospos_session:1bc5bf0dbe84a12d009bc3168933d331','127.0.0.1','2026-09-15 13:45:56','__ci_last_regenerate|i:1789479956;csrf_ospos_v4|s:32:\"f64be6dd110d2156dc3de1b5999a86cd\";'),
('ospos_session:1c40497260d433f949d2609449b156f2','127.0.0.1','2026-09-15 13:42:25','__ci_last_regenerate|i:1789479745;csrf_ospos_v4|s:32:\"ed9e1b34387753b8dc3996de644b0089\";'),
('ospos_session:1e1b333a93f0e691440bc61683f72ed7','127.0.0.1','2026-09-15 13:55:27','__ci_last_regenerate|i:1789480527;csrf_ospos_v4|s:32:\"55df48051ed9d5ba08e223976b22322c\";'),
('ospos_session:1f3ffff93eca29bde4c9a1c1a99dbace','127.0.0.1','2026-09-15 14:10:29','__ci_last_regenerate|i:1789481429;csrf_ospos_v4|s:32:\"b722851ea93b85d440d84f5af610e03f\";'),
('ospos_session:1f51c533538106eabe8d3b536c10a29c','127.0.0.1','2026-09-15 13:44:56','__ci_last_regenerate|i:1789479896;csrf_ospos_v4|s:32:\"8917f86719e8bf10b725247ef0ce4399\";'),
('ospos_session:20f554494645ddf4a7a37c3fbd200640','127.0.0.1','2026-09-15 13:50:26','__ci_last_regenerate|i:1789480226;csrf_ospos_v4|s:32:\"35a52fb6101ae67569b521e91d322970\";'),
('ospos_session:21c6991e22da01ff9582dd3ac672755e','127.0.0.1','2026-09-15 13:56:57','__ci_last_regenerate|i:1789480617;csrf_ospos_v4|s:32:\"e4d14ec1ef6535f27913045b141644ad\";'),
('ospos_session:2368422bd0c97b0ce652a08309cb394a','127.0.0.1','2026-09-15 12:49:47','__ci_last_regenerate|i:1789476587;csrf_ospos_v4|s:32:\"48605610a514828319300f062b067df5\";'),
('ospos_session:236bcc57808d921cb47d26cef7d35708','127.0.0.1','2026-09-15 13:07:20','__ci_last_regenerate|i:1789477640;csrf_ospos_v4|s:32:\"c3600015d653f74d3a7d8faca5c45bc6\";'),
('ospos_session:23d9f3cebd1a46b0e06351ba31d0daec','127.0.0.1','2026-09-15 13:47:56','__ci_last_regenerate|i:1789480076;csrf_ospos_v4|s:32:\"76d513c62dee87474c3fbfb5ae9f2bc8\";'),
('ospos_session:284a7d0b047f6a2a634f7b637cd2e56a','127.0.0.1','2026-09-15 13:09:50','__ci_last_regenerate|i:1789477790;csrf_ospos_v4|s:32:\"47d4924f38e66fdb0ba74ad8f9406f5c\";'),
('ospos_session:2880bb0d45faf0ad31928a861ddbf86d','127.0.0.1','2026-09-15 14:16:30','__ci_last_regenerate|i:1789481790;csrf_ospos_v4|s:32:\"97e75cca1f19120d57e7f976b71cf819\";'),
('ospos_session:28941f5ef418c36629f98ca15cef608a','127.0.0.1','2026-09-15 14:14:00','__ci_last_regenerate|i:1789481640;csrf_ospos_v4|s:32:\"a14edbd6f7b334d79061b5668700dd97\";'),
('ospos_session:295deb6096c391431ba1cfdc1d83a2f3','127.0.0.1','2026-09-15 13:00:49','__ci_last_regenerate|i:1789477249;csrf_ospos_v4|s:32:\"5b03b4f9cd180ecd2910965089220450\";'),
('ospos_session:2a81bd4717a6c0bdd6431c58857046f7','127.0.0.1','2026-09-15 14:06:29','__ci_last_regenerate|i:1789481189;csrf_ospos_v4|s:32:\"3d57d2b6744c9b0731a2c90c40d51fba\";'),
('ospos_session:2ebd6bfbd4be74ac4d7af692eee1e945','127.0.0.1','2026-09-15 13:26:53','__ci_last_regenerate|i:1789478813;csrf_ospos_v4|s:32:\"b65adda25f0aa25a1d04b436919551b5\";'),
('ospos_session:32d8d3cc0f5e53863445c92723d94bce','127.0.0.1','2026-09-15 13:54:57','__ci_last_regenerate|i:1789480497;csrf_ospos_v4|s:32:\"9e4bbd270410260dae5d38ac7c1faaed\";'),
('ospos_session:32e1ecfe1b5b98a4c67bd046c5278aa4','127.0.0.1','2026-09-15 14:13:30','__ci_last_regenerate|i:1789481610;csrf_ospos_v4|s:32:\"27ccd7c18b0055d9c287f461592b41d5\";'),
('ospos_session:33c935ea09fd3900f8d721dc99d16b67','127.0.0.1','2026-09-15 14:04:59','__ci_last_regenerate|i:1789481099;csrf_ospos_v4|s:32:\"95ab7d5bf72dd3665cad3fdc158d4d40\";'),
('ospos_session:343d79342d115161e6236becc3ceee01','127.0.0.1','2026-09-15 13:25:53','__ci_last_regenerate|i:1789478753;csrf_ospos_v4|s:32:\"853423daa2f476ef5b55df4d3901ff2d\";'),
('ospos_session:35859acb05a4c36863678bb5bdc6260f','127.0.0.1','2026-09-15 13:13:51','__ci_last_regenerate|i:1789478031;csrf_ospos_v4|s:32:\"653c184aed90349d6a9563a870762185\";'),
('ospos_session:36fd29d90edb36b5cecf45ad49736ead','127.0.0.1','2026-09-15 13:10:51','__ci_last_regenerate|i:1789477851;csrf_ospos_v4|s:32:\"04f4bafe7134a38e0bd1d7c09a8f8322\";'),
('ospos_session:382e3064a61e1cae2b536d4d89eb4189','127.0.0.1','2026-09-15 13:48:26','__ci_last_regenerate|i:1789480106;csrf_ospos_v4|s:32:\"6f612971ea694c9700ab71f40d90c0d9\";'),
('ospos_session:3848d1cfc4b1dd8fa920597aebbf70c7','127.0.0.1','2026-09-15 12:54:48','__ci_last_regenerate|i:1789476888;csrf_ospos_v4|s:32:\"d9d81a80d8d6fe2c3651969680ee7c07\";'),
('ospos_session:39fba96ca987dd95e185276946d675c9','127.0.0.1','2026-09-15 13:23:53','__ci_last_regenerate|i:1789478633;csrf_ospos_v4|s:32:\"6a771bbd84e648d73e7cb9405906c852\";'),
('ospos_session:3b9d3be29f02644f958fbf0e8c38c55d','127.0.0.1','2026-09-15 13:20:22','__ci_last_regenerate|i:1789478422;csrf_ospos_v4|s:32:\"e7ad22c6e3eb5d5c507bac0339c0a596\";'),
('ospos_session:3cde37a2de9369ae81ed13f2089518a5','127.0.0.1','2026-09-15 13:36:24','__ci_last_regenerate|i:1789479384;csrf_ospos_v4|s:32:\"1ea86b1b1e9d768dec40a3c4520b48a7\";'),
('ospos_session:3e4a67bbe40472fed573263f8cd08028','127.0.0.1','2026-09-15 13:37:25','__ci_last_regenerate|i:1789479445;csrf_ospos_v4|s:32:\"32407e026845b7cd192569ef202e21f2\";'),
('ospos_session:3e4e107280d096f76733c0872dc704e7','127.0.0.1','2026-09-15 13:33:24','__ci_last_regenerate|i:1789479204;csrf_ospos_v4|s:32:\"48c01b72d362e022a45391cca7c95643\";'),
('ospos_session:414abd68fe7143e43c0b85f49b78ce26','127.0.0.1','2026-09-15 14:09:59','__ci_last_regenerate|i:1789481399;csrf_ospos_v4|s:32:\"6b5adefedc4bdaaf6046c5297408560d\";'),
('ospos_session:425086dd8de568207ce2f85309f04bce','127.0.0.1','2026-09-15 13:06:20','__ci_last_regenerate|i:1789477580;csrf_ospos_v4|s:32:\"de096ba91ebe0159e56becfe6420d6d9\";'),
('ospos_session:447d1a87c633ad8e3aacc2003caeb953','127.0.0.1','2026-09-15 13:22:22','__ci_last_regenerate|i:1789478542;csrf_ospos_v4|s:32:\"3e8c700f4b0deb5c1e63a3ae12406b65\";'),
('ospos_session:46aadd8574bfe309bd63b1eb7ba97a31','127.0.0.1','2026-09-15 13:28:23','__ci_last_regenerate|i:1789478903;csrf_ospos_v4|s:32:\"be91f596f268518322293cd208aa8f14\";'),
('ospos_session:46d7797cc6cd56e3666ef5509348c40e','127.0.0.1','2026-09-15 12:42:16','__ci_last_regenerate|i:1789476136;csrf_ospos_v4|s:32:\"2584d3045c714c9d30659396fae8b06b\";'),
('ospos_session:475e96ac87ec0b3385bb40260c7ef27a','127.0.0.1','2026-09-15 14:19:30','__ci_last_regenerate|i:1789481970;csrf_ospos_v4|s:32:\"5a326e413a71317483c482d1265849cd\";'),
('ospos_session:477906347ee06cdb13b22fdd81b667cd','127.0.0.1','2026-09-15 13:41:55','__ci_last_regenerate|i:1789479715;csrf_ospos_v4|s:32:\"47ad4916900faf9ccdc6052db57a2e6d\";'),
('ospos_session:47d88ddf2129192aa1ec46fa3f3701f5','127.0.0.1','2026-09-15 14:16:00','__ci_last_regenerate|i:1789481760;csrf_ospos_v4|s:32:\"570148470ba233c1b8e5e9a9ca807f14\";'),
('ospos_session:48e5160f63fc80c1fd8b3c2735b3e574','127.0.0.1','2026-09-15 12:59:49','__ci_last_regenerate|i:1789477189;csrf_ospos_v4|s:32:\"0aa00431366131e6c64a4918befdde98\";'),
('ospos_session:48e9297b11fd9c08a09e943ceb4ba438','127.0.0.1','2026-09-15 12:43:46','__ci_last_regenerate|i:1789476226;csrf_ospos_v4|s:32:\"359fbad08c92f611b7767c4ff1b39603\";'),
('ospos_session:49c85be0e5616e088b1f6b6344bad0ab','127.0.0.1','2026-09-15 14:01:58','__ci_last_regenerate|i:1789480918;csrf_ospos_v4|s:32:\"865cd4e2addeb43d49fc9d2ede165b19\";'),
('ospos_session:49f101c1f0b3f2696f07a1dc56201141','127.0.0.1','2026-09-15 13:16:51','__ci_last_regenerate|i:1789478211;csrf_ospos_v4|s:32:\"58194ec9cbd5b420186b721f3b4e660c\";'),
('ospos_session:4b389f45a9c1fc0656b26181e065cf83','127.0.0.1','2026-09-15 14:07:29','__ci_last_regenerate|i:1789481249;csrf_ospos_v4|s:32:\"2a584b9dc4d18b5dfbe497d27889874f\";'),
('ospos_session:4b648b89f47192cf169ecfba6c896469','127.0.0.1','2026-09-15 12:58:19','__ci_last_regenerate|i:1789477099;csrf_ospos_v4|s:32:\"30928fd4b60c2f416bec91d3111a5f50\";'),
('ospos_session:4b949ebdbf076b646f36484f8f8af9e2','127.0.0.1','2026-09-15 14:18:00','__ci_last_regenerate|i:1789481880;csrf_ospos_v4|s:32:\"f9b8435a7f97b5c6fa2fb1f1294cd83a\";'),
('ospos_session:4c4253c92a029d794ea9bc6593bdd151','127.0.0.1','2026-09-15 13:54:27','__ci_last_regenerate|i:1789480467;csrf_ospos_v4|s:32:\"57c6a88aad1ad82b6bbb4ad2cda9932d\";'),
('ospos_session:4c63ad63117c8e776afe46c510a81dee','127.0.0.1','2026-09-15 13:43:25','__ci_last_regenerate|i:1789479805;csrf_ospos_v4|s:32:\"9d0e75f03384a5da358b5f3f5cafec4f\";'),
('ospos_session:4c7d06143bcb443868746170c3f3b612','127.0.0.1','2026-09-15 14:12:29','__ci_last_regenerate|i:1789481549;csrf_ospos_v4|s:32:\"bc59a090f709a188e074077055eded4c\";'),
('ospos_session:4e00707af9c953ae12aa8b485a854d3b','127.0.0.1','2026-09-15 13:38:25','__ci_last_regenerate|i:1789479505;csrf_ospos_v4|s:32:\"e749b656e529c4a3f79aeccd4b70f4bd\";'),
('ospos_session:4ec88c3a9325019d390e4ccfafda24a0','127.0.0.1','2026-09-15 14:24:01','__ci_last_regenerate|i:1789482241;csrf_ospos_v4|s:32:\"495edd4a9d84a047be0ef89c703b5612\";'),
('ospos_session:4f1cc3ec6b93740f378e9d8165ad8ef1','127.0.0.1','2026-09-15 13:17:22','__ci_last_regenerate|i:1789478242;csrf_ospos_v4|s:32:\"02b5966d8f86f2fcafe5176c1fd76d3d\";'),
('ospos_session:50f84e39490a847216ac168eade36b8d','127.0.0.1','2026-09-15 13:04:50','__ci_last_regenerate|i:1789477490;csrf_ospos_v4|s:32:\"a642a9b5e06a90cbcf67eed0e71466d3\";'),
('ospos_session:54168dca08c988103003c2e6a9288486','127.0.0.1','2026-09-15 13:34:54','__ci_last_regenerate|i:1789479294;csrf_ospos_v4|s:32:\"dbf5e1a9debb5c5ff855b777e9655ee7\";'),
('ospos_session:55202032ea16c7443a1537f565bfe8bd','127.0.0.1','2026-09-15 13:21:22','__ci_last_regenerate|i:1789478482;csrf_ospos_v4|s:32:\"501bd44fda5f02078bceaf9f12eb38af\";'),
('ospos_session:553fa8e1c17dd0da583b6e90cb934fdc','127.0.0.1','2026-09-15 14:01:28','__ci_last_regenerate|i:1789480888;csrf_ospos_v4|s:32:\"d55f95df332676e373f8771aecc31259\";'),
('ospos_session:56b6555c078d8494538976739fabe1be','127.0.0.1','2026-09-15 14:02:28','__ci_last_regenerate|i:1789480948;csrf_ospos_v4|s:32:\"a1ff49244d6ece1659d2a605e447e637\";'),
('ospos_session:56d0927d901e7bdcd0cfec9159f69f75','127.0.0.1','2026-09-15 13:14:21','__ci_last_regenerate|i:1789478061;csrf_ospos_v4|s:32:\"ac4d3de9a4b2c0db394118ae504f80c3\";'),
('ospos_session:58e334f366ba3e39991965a8f929348e','127.0.0.1','2026-09-15 14:17:30','__ci_last_regenerate|i:1789481850;csrf_ospos_v4|s:32:\"b7dec8977cea62217c75d0959e361908\";'),
('ospos_session:5a3bb2152a5ce84b98d1833de31ecc8a','127.0.0.1','2026-09-15 13:22:52','__ci_last_regenerate|i:1789478572;csrf_ospos_v4|s:32:\"01d69d03ef8639cb088fa68516eabb98\";'),
('ospos_session:5ab2f58f95cf38b61466705eeb3c5d80','127.0.0.1','2026-09-15 13:15:51','__ci_last_regenerate|i:1789478151;csrf_ospos_v4|s:32:\"47c0950b527d7e56b6a7c4a54fb4db70\";'),
('ospos_session:5be050002c033947d34713653986f257','127.0.0.1','2026-09-15 14:19:00','__ci_last_regenerate|i:1789481940;csrf_ospos_v4|s:32:\"4ee9d1c8f16561d065ce291836134a33\";'),
('ospos_session:5d2db5df83b8fa7c26f6705182ae3ae5','127.0.0.1','2026-09-15 13:24:53','__ci_last_regenerate|i:1789478693;csrf_ospos_v4|s:32:\"05016d7b1d1c04628ba0000ba135d1b4\";'),
('ospos_session:5d6593a87fbc2c779bcd66e5278e6c81','127.0.0.1','2026-09-15 13:35:24','__ci_last_regenerate|i:1789479324;csrf_ospos_v4|s:32:\"87c7b116517981ed74a5fb0f7dede105\";'),
('ospos_session:5e06600013e8783568dcd2ceb4f0a2b2','127.0.0.1','2026-09-15 14:14:30','__ci_last_regenerate|i:1789481670;csrf_ospos_v4|s:32:\"0a0d5c8b5ed2ea70dc48354a2b014f85\";'),
('ospos_session:5ea9fe1fd91380b40152a82ed209ca28','127.0.0.1','2026-09-15 12:46:47','__ci_last_regenerate|i:1789476407;csrf_ospos_v4|s:32:\"a63d97a92f27f98dda5eef9472cf57ef\";'),
('ospos_session:5eac4487eab608c43ef5a0391cfefc92','127.0.0.1','2026-09-15 13:19:22','__ci_last_regenerate|i:1789478362;csrf_ospos_v4|s:32:\"978f81244b107f36a70d0802c322c0b9\";'),
('ospos_session:5efbb29ad0a89c882d6ffb96b5acbdb4','127.0.0.1','2026-09-15 13:33:54','__ci_last_regenerate|i:1789479234;csrf_ospos_v4|s:32:\"a7a8e4163a97cf4692a5d27698140f72\";'),
('ospos_session:5f375e33b6600d0f6d77da976ebe123c','172.20.0.3','2026-09-15 14:14:41','__ci_last_regenerate|i:1789481462;csrf_ospos_v4|s:32:\"9a1d5369413cabe1b6f29957f844cb12\";_ci_previous_url|s:40:\"https://ghazi-pos.local/sales/changeMode\";person_id|s:1:\"1\";menu_group|s:4:\"home\";allow_temp_items|i:1;item_location|s:1:\"1\";sale_id|i:-1;sales_location|i:1;sales_employee|i:1;cash_adjustment_amount|d:0;recv_cart|a:0:{}recv_mode|s:7:\"receive\";recv_supplier|i:-1;cash_rounding|i:0;cash_mode|i:0;sales_cart|a:0:{}sales_customer|i:-1;sales_mode|s:10:\"sale_quote\";sale_type|i:3;sales_payments|a:0:{}'),
('ospos_session:60bdca856e726a4f4c9205aecc70a8a2','127.0.0.1','2026-09-15 13:58:58','__ci_last_regenerate|i:1789480738;csrf_ospos_v4|s:32:\"b01a400e9f0188bd839c48d2be25453a\";'),
('ospos_session:60df4ad987e184321bc17fd5994a8641','127.0.0.1','2026-09-15 14:15:00','__ci_last_regenerate|i:1789481700;csrf_ospos_v4|s:32:\"a8eea213bddd5d6438978404f95c3bb5\";'),
('ospos_session:61ccfeb533ac0c8b1dae364afe7d5b88','127.0.0.1','2026-09-15 13:08:20','__ci_last_regenerate|i:1789477700;csrf_ospos_v4|s:32:\"d8a3409b2db713cff700fb8f16e3c4e8\";'),
('ospos_session:6678a390fb253fd8989cd8b266fc8fc0','127.0.0.1','2026-09-15 13:46:26','__ci_last_regenerate|i:1789479986;csrf_ospos_v4|s:32:\"02e5811bc3dd9d1c60cd347d8955fe7f\";'),
('ospos_session:6bdee5c10a07591eea1076a6a92b90c2','127.0.0.1','2026-09-15 13:12:21','__ci_last_regenerate|i:1789477941;csrf_ospos_v4|s:32:\"2d8913cf710d26b9a8702fa11021b45c\";'),
('ospos_session:6e98368184d41d91269236890a977eb0','127.0.0.1','2026-09-15 13:27:53','__ci_last_regenerate|i:1789478873;csrf_ospos_v4|s:32:\"0f1c24bec9e7802e1e9c45a6e48548f9\";'),
('ospos_session:6ec9778897212f334e17cd1ecc10858b','127.0.0.1','2026-09-15 13:18:22','__ci_last_regenerate|i:1789478302;csrf_ospos_v4|s:32:\"25ce6102634587b5e987e5e4baa31e74\";'),
('ospos_session:6f8dc102c3824bebc495118fbe2d85b3','127.0.0.1','2026-09-15 12:46:17','__ci_last_regenerate|i:1789476377;csrf_ospos_v4|s:32:\"6c69d12f5592feacd7feb5e4f9ee89bc\";'),
('ospos_session:71f15d25b56db42a9d058ec8709c236b','127.0.0.1','2026-09-15 13:19:52','__ci_last_regenerate|i:1789478392;csrf_ospos_v4|s:32:\"55c25e9de1864651a394bd9a5d9928dd\";'),
('ospos_session:7310dc283dd2379c2f69fb60aebc96af','127.0.0.1','2026-09-15 13:47:26','__ci_last_regenerate|i:1789480046;csrf_ospos_v4|s:32:\"13b687d7d2c762969edb16cc66286012\";'),
('ospos_session:7327658037c4587d5e8aae177e7cbd7c','127.0.0.1','2026-09-15 14:08:29','__ci_last_regenerate|i:1789481309;csrf_ospos_v4|s:32:\"7b3cb1a05f11beedcf50d736ff44b0c5\";'),
('ospos_session:7410cecf85a4a28f342d623ce4573bd1','127.0.0.1','2026-09-15 12:48:47','__ci_last_regenerate|i:1789476527;csrf_ospos_v4|s:32:\"cd48176a5540ef13c70f6359b14a1589\";'),
('ospos_session:74aa3e7f17e5e39fc416e3d69a6f0938','127.0.0.1','2026-09-15 12:59:19','__ci_last_regenerate|i:1789477159;csrf_ospos_v4|s:32:\"07c6399feec828cfb3c594946cf0b4e1\";'),
('ospos_session:769130d4b79e806e2ee4ae756441a3da','127.0.0.1','2026-09-15 13:15:21','__ci_last_regenerate|i:1789478121;csrf_ospos_v4|s:32:\"8a0ef8c3ba250d84156fdf4d8a0ce9cf\";'),
('ospos_session:7734823a71e7ae37a1821cd44e2d19e3','127.0.0.1','2026-09-15 13:03:19','__ci_last_regenerate|i:1789477399;csrf_ospos_v4|s:32:\"ffaf47c492256258d7d5494761842de6\";'),
('ospos_session:7ace5783a0ba5164e694bce52b6f0859','127.0.0.1','2026-09-15 14:17:00','__ci_last_regenerate|i:1789481820;csrf_ospos_v4|s:32:\"083c8b14c52c6e8f1686b559bc27aec8\";'),
('ospos_session:7b62fa370c96f32d8a14dbc14a80cbb9','127.0.0.1','2026-09-15 13:31:24','__ci_last_regenerate|i:1789479084;csrf_ospos_v4|s:32:\"37a3778247a19d3014a042ae9dc8e672\";'),
('ospos_session:7b76bf5a1f0bf7b0168a67e76450c11d','127.0.0.1','2026-09-15 13:13:21','__ci_last_regenerate|i:1789478001;csrf_ospos_v4|s:32:\"50df80ab9ba97f38f1f2ab777e9d812e\";'),
('ospos_session:7d0143e5fa140d3ddc2aa3ebda069ec5','127.0.0.1','2026-09-15 13:29:54','__ci_last_regenerate|i:1789478994;csrf_ospos_v4|s:32:\"cafb3af8645a2767caabb97ca1c11038\";'),
('ospos_session:7e51eadc33234353172f2fe7ee2cfdbc','127.0.0.1','2026-09-15 14:13:00','__ci_last_regenerate|i:1789481580;csrf_ospos_v4|s:32:\"ad200c4a6d83d3dc90c44c999d9c1c95\";'),
('ospos_session:7eacede12e0b8594bddf9927e1b1cb31','127.0.0.1','2026-09-15 12:55:48','__ci_last_regenerate|i:1789476948;csrf_ospos_v4|s:32:\"48ef4bbf6ee311707ccd07365b176e88\";'),
('ospos_session:82b3018d774eb3a09de7b4534a29c8f5','127.0.0.1','2026-09-15 13:44:26','__ci_last_regenerate|i:1789479866;csrf_ospos_v4|s:32:\"1be921394844fbe5916f5b0830f6d31d\";'),
('ospos_session:832b55a4f0d6b011a9171317db948a2b','127.0.0.1','2026-09-15 13:52:27','__ci_last_regenerate|i:1789480347;csrf_ospos_v4|s:32:\"6ea081baee46db7545b78d8b73bc7d07\";'),
('ospos_session:849a384384b57f935f7e4719b92c6814','127.0.0.1','2026-09-15 13:12:51','__ci_last_regenerate|i:1789477971;csrf_ospos_v4|s:32:\"30c0c971f520319f5046c5669f537ba1\";'),
('ospos_session:84b6fadeee31eefd55041fac4ddbf78a','127.0.0.1','2026-09-15 12:49:17','__ci_last_regenerate|i:1789476557;csrf_ospos_v4|s:32:\"0975ff927de3caa2f5ed21735c1b4068\";'),
('ospos_session:87bec11ac9e04b0584fc9d1e05cc327e','127.0.0.1','2026-09-15 13:31:54','__ci_last_regenerate|i:1789479114;csrf_ospos_v4|s:32:\"8226596682ed24defc1b1460e5934f20\";'),
('ospos_session:89651b5b941503e03110c852b2aabef3','127.0.0.1','2026-09-15 13:06:50','__ci_last_regenerate|i:1789477610;csrf_ospos_v4|s:32:\"c2d4541cc4d1a399a08e9f6c467a8d07\";'),
('ospos_session:8af62fca669de7930eabb263ce4fa83c','127.0.0.1','2026-09-15 12:47:17','__ci_last_regenerate|i:1789476437;csrf_ospos_v4|s:32:\"04960d4d1a7ff6713a987e5d8b55b3dc\";'),
('ospos_session:8b4766109c4030f51ec4b65d190612e4','127.0.0.1','2026-09-15 13:43:55','__ci_last_regenerate|i:1789479835;csrf_ospos_v4|s:32:\"47da99ab9255fa8ca8de4c4dc98a695b\";'),
('ospos_session:8bd8a8382adcb2b77d2c71954bf778c4','127.0.0.1','2026-09-15 13:00:19','__ci_last_regenerate|i:1789477219;csrf_ospos_v4|s:32:\"4ecfb961715ec6418b50b7ba3f9b0cd5\";'),
('ospos_session:8ceb668641896fd884ac36177381a95e','127.0.0.1','2026-09-15 13:30:54','__ci_last_regenerate|i:1789479054;csrf_ospos_v4|s:32:\"54967af18f3bc12ea602a544a65d320b\";'),
('ospos_session:8e091b8d007208f1918dbfbb78e304e9','127.0.0.1','2026-09-15 13:28:53','__ci_last_regenerate|i:1789478933;csrf_ospos_v4|s:32:\"a062245d3ddc0aef1dfa3444373c8b83\";'),
('ospos_session:8f211116179ae0987325307dba62cc4e','127.0.0.1','2026-09-15 13:18:52','__ci_last_regenerate|i:1789478332;csrf_ospos_v4|s:32:\"48773871d55bdedadc353e5446aadbb0\";'),
('ospos_session:8f8fef6ca4c8c3ebb88d1986a0a45b50','127.0.0.1','2026-09-15 13:35:54','__ci_last_regenerate|i:1789479354;csrf_ospos_v4|s:32:\"cac357c91581a8fbaffff1298259d5a2\";'),
('ospos_session:91a1b81c84e8bab589771d0f9668541e','127.0.0.1','2026-09-15 14:08:59','__ci_last_regenerate|i:1789481339;csrf_ospos_v4|s:32:\"5f1898bce38d745f606c32548ff82a87\";'),
('ospos_session:9205b676b1c4cb3851a37f629384617e','127.0.0.1','2026-09-15 13:59:28','__ci_last_regenerate|i:1789480768;csrf_ospos_v4|s:32:\"be02ae2beea294a8c90ea1f7001ef54e\";'),
('ospos_session:9299f894fda97b34c1ed1f478a065319','127.0.0.1','2026-09-15 12:52:48','__ci_last_regenerate|i:1789476768;csrf_ospos_v4|s:32:\"c4971d9c6855ec28be800073ef3e3493\";'),
('ospos_session:93c03692beeff861c208add5d1400ff7','127.0.0.1','2026-09-15 12:41:46','__ci_last_regenerate|i:1789476106;csrf_ospos_v4|s:32:\"b304bad35b04c3531fbf77a7bae02f51\";'),
('ospos_session:93c7911e09327f8a854ba0bf5ef943d4','127.0.0.1','2026-09-15 12:55:18','__ci_last_regenerate|i:1789476918;csrf_ospos_v4|s:32:\"b8871efd0fb90cc8d6f3e5e6e7d600e7\";'),
('ospos_session:93e4bbd16e319f15852570a55bc854e4','127.0.0.1','2026-09-15 12:44:17','__ci_last_regenerate|i:1789476257;csrf_ospos_v4|s:32:\"fcf1c083c8040ab55f514443c24ee63b\";'),
('ospos_session:9417f7be8fd5e37180a5ba3c0d22d63a','127.0.0.1','2026-09-15 13:32:54','__ci_last_regenerate|i:1789479174;csrf_ospos_v4|s:32:\"63589bfefc4f9bf9b65b2240b74444a6\";'),
('ospos_session:94fce071740d0a19d44fecdd07238841','127.0.0.1','2026-09-15 13:05:50','__ci_last_regenerate|i:1789477550;csrf_ospos_v4|s:32:\"ce28ce486f8441fd2252f62d0cf9a203\";'),
('ospos_session:97c5026891cb75970485cefad641cedc','127.0.0.1','2026-09-15 13:37:55','__ci_last_regenerate|i:1789479475;csrf_ospos_v4|s:32:\"a8c87b3994befc2a1bca248b88eb3539\";'),
('ospos_session:982732f429f10eed68d9b5bd4827f529','127.0.0.1','2026-09-15 13:36:54','__ci_last_regenerate|i:1789479414;csrf_ospos_v4|s:32:\"c89cff57078552edd493eb938821f04c\";'),
('ospos_session:98e0257dace22cd20776b9ff6e77c3a0','127.0.0.1','2026-09-15 13:58:28','__ci_last_regenerate|i:1789480708;csrf_ospos_v4|s:32:\"ff2b5c7751d8a727a402bd6354126c19\";'),
('ospos_session:9adb2a1e63664a5f590b3f4bd2171adb','127.0.0.1','2026-09-15 13:40:25','__ci_last_regenerate|i:1789479625;csrf_ospos_v4|s:32:\"42840b0eee4509c4d9cd85a70f4b4f2a\";'),
('ospos_session:9d42b38658f3da82b09b1ca68bf7d321','127.0.0.1','2026-09-15 14:15:30','__ci_last_regenerate|i:1789481730;csrf_ospos_v4|s:32:\"37018c15b71f43e2f9b45d2d60041303\";'),
('ospos_session:a029da52077737f0309c992e6b50da96','127.0.0.1','2026-09-15 13:14:51','__ci_last_regenerate|i:1789478091;csrf_ospos_v4|s:32:\"481a2079b485a643260e3f184c85a8d8\";'),
('ospos_session:a203564ae8143ee2f4b207a4ad90826a','127.0.0.1','2026-09-15 13:07:50','__ci_last_regenerate|i:1789477670;csrf_ospos_v4|s:32:\"4bae0979e63f8b8199af97afdf399a24\";'),
('ospos_session:a2dd04222faaeb19f36351a91eb5356a','127.0.0.1','2026-09-15 13:41:25','__ci_last_regenerate|i:1789479685;csrf_ospos_v4|s:32:\"71306be20d680dccf4ead0328931b07a\";'),
('ospos_session:a4ec3868719aee0e5cabc2d4f5687e29','127.0.0.1','2026-09-15 12:50:17','__ci_last_regenerate|i:1789476617;csrf_ospos_v4|s:32:\"7b8f700acbe26457eb09d7532d782d84\";'),
('ospos_session:a61ff9984b3383a7335f326fa89bae04','127.0.0.1','2026-09-15 13:29:23','__ci_last_regenerate|i:1789478963;csrf_ospos_v4|s:32:\"39fe23fe1dd0b224cbcc9fb8b55c223e\";'),
('ospos_session:a680d48742772841ed625407aaedaa38','127.0.0.1','2026-09-15 13:17:52','__ci_last_regenerate|i:1789478272;csrf_ospos_v4|s:32:\"9ee16b97731a10a295afe831eb028184\";'),
('ospos_session:a7572d6df51baaf1fc544768827e682c','127.0.0.1','2026-09-15 13:09:20','__ci_last_regenerate|i:1789477760;csrf_ospos_v4|s:32:\"e3675859a503e5e4d1d808ea2a66be8a\";'),
('ospos_session:aa2bd21bf87a8d226f1ce2c9b8711c30','127.0.0.1','2026-09-15 13:21:52','__ci_last_regenerate|i:1789478512;csrf_ospos_v4|s:32:\"8c59c07ddc3945578291c2e527563677\";'),
('ospos_session:abfbe863c30a415c3bc2d0e1d94e5ba6','127.0.0.1','2026-09-15 12:58:49','__ci_last_regenerate|i:1789477129;csrf_ospos_v4|s:32:\"ec4e3a80abc59c44a5e98da5aacef753\";'),
('ospos_session:adcac879437a759ee493fc6745c7e210','127.0.0.1','2026-09-15 12:56:48','__ci_last_regenerate|i:1789477008;csrf_ospos_v4|s:32:\"ca0bf29a291c8122f1df1132465577a1\";'),
('ospos_session:aecd069531dc8dc05e214f292be6fff8','127.0.0.1','2026-09-15 14:20:00','__ci_last_regenerate|i:1789482000;csrf_ospos_v4|s:32:\"939d83e93dd7eac1ef00b8fb20dfcbab\";'),
('ospos_session:b21022f9bd223057ba882d17ce8c12b7','127.0.0.1','2026-09-15 13:25:23','__ci_last_regenerate|i:1789478723;csrf_ospos_v4|s:32:\"1ea1cef4e8f017004dd9260fb9be5c07\";'),
('ospos_session:b2d4c744a61d69a9751dceeefaf3723b','127.0.0.1','2026-09-15 14:11:29','__ci_last_regenerate|i:1789481489;csrf_ospos_v4|s:32:\"63473adcfa5aef4ff05c1627e80d3446\";'),
('ospos_session:b3f462efa3c80f82893ac0a6c0d5d9a3','127.0.0.1','2026-09-15 13:16:21','__ci_last_regenerate|i:1789478181;csrf_ospos_v4|s:32:\"df76d7908921e2817811b0929e0f9f1a\";'),
('ospos_session:b7274010acf31d807efc37f62fa7f020','127.0.0.1','2026-09-15 13:57:27','__ci_last_regenerate|i:1789480647;csrf_ospos_v4|s:32:\"e43f2729545c05b85110288e0ff105a1\";'),
('ospos_session:b75f0efdf60132f1dec85cdf7cbd0e2a','127.0.0.1','2026-09-15 13:34:24','__ci_last_regenerate|i:1789479264;csrf_ospos_v4|s:32:\"264a9cf49b0cc4392d607c13f84feda7\";'),
('ospos_session:b8eebf97efbd6edbe208e0780ece4f18','127.0.0.1','2026-09-15 12:43:16','__ci_last_regenerate|i:1789476196;csrf_ospos_v4|s:32:\"39ac01a61544dbba5570eca10b32d851\";'),
('ospos_session:b97cf106cfc5aeeca8a8fa29071c3ae0','127.0.0.1','2026-09-15 14:00:58','__ci_last_regenerate|i:1789480858;csrf_ospos_v4|s:32:\"a0835748f7e99d61bef57c8e582b5e83\";'),
('ospos_session:b98c57644fde7428ec9f4786ff7cddfa','127.0.0.1','2026-09-15 14:21:30','__ci_last_regenerate|i:1789482090;csrf_ospos_v4|s:32:\"f3f92f5efa36d1ab9176315a216ce77e\";'),
('ospos_session:bd1f0a14bed9e9bd3d8e3c267377c422','127.0.0.1','2026-09-15 13:20:52','__ci_last_regenerate|i:1789478452;csrf_ospos_v4|s:32:\"bcedfe84987b545343a7bf6634ebb119\";'),
('ospos_session:c0d187aeaa570404b5b237572a37e3ec','127.0.0.1','2026-09-15 14:23:31','__ci_last_regenerate|i:1789482211;csrf_ospos_v4|s:32:\"d8d7dfd368b22c7469cd70a05e9205d7\";'),
('ospos_session:c2f1ce0f4a753a9b88e2e4aeee303391','127.0.0.1','2026-09-15 14:04:28','__ci_last_regenerate|i:1789481068;csrf_ospos_v4|s:32:\"f32323b94acb663b44c67ee988ff173e\";'),
('ospos_session:c5c0e4a13a91346817b57563b126ec93','127.0.0.1','2026-09-15 13:49:56','__ci_last_regenerate|i:1789480196;csrf_ospos_v4|s:32:\"05ed8486f6de6977b85c075c2e4c1c12\";'),
('ospos_session:c84f1a1f36c651cd3c3efcc4293e50c7','127.0.0.1','2026-09-15 13:38:55','__ci_last_regenerate|i:1789479535;csrf_ospos_v4|s:32:\"9c307531e1bfd9d645b0695b6091bb95\";'),
('ospos_session:c9236aa6bb3ae10043727a2604eec9b8','127.0.0.1','2026-09-15 13:39:25','__ci_last_regenerate|i:1789479565;csrf_ospos_v4|s:32:\"470d6dcd9e86a72d63823a80bbbfcc09\";'),
('ospos_session:caa1236e9454a05c9e900642e94cc14b','127.0.0.1','2026-09-15 13:08:50','__ci_last_regenerate|i:1789477730;csrf_ospos_v4|s:32:\"a5d74ada5f9cbd085c2720f05e371b23\";'),
('ospos_session:cafe39e74aefe7fbab9f7c20ec4506ff','127.0.0.1','2026-09-15 13:26:23','__ci_last_regenerate|i:1789478783;csrf_ospos_v4|s:32:\"d34fe0f02c826889e751a59e0479e295\";'),
('ospos_session:cc82e5a162972dc5f655b700f1d0b41c','127.0.0.1','2026-09-15 14:22:01','__ci_last_regenerate|i:1789482121;csrf_ospos_v4|s:32:\"3b4867f5a5cbed7adf598a2194dbc9da\";'),
('ospos_session:cd61dbc36f5f115f6df60545e45ddfd6','127.0.0.1','2026-09-15 14:18:30','__ci_last_regenerate|i:1789481910;csrf_ospos_v4|s:32:\"289a513b815ea7abb8c132c8a3854105\";'),
('ospos_session:ce344ba3b7c9fe1edf521ce19da689bb','127.0.0.1','2026-09-15 12:45:17','__ci_last_regenerate|i:1789476317;csrf_ospos_v4|s:32:\"3565471da217dd1bb8621dfb2f10e757\";'),
('ospos_session:ce5ea7e3f71397fe78077113c36cbab4','127.0.0.1','2026-09-15 13:02:49','__ci_last_regenerate|i:1789477369;csrf_ospos_v4|s:32:\"db42563e47fd450eedbddf33745a72ad\";'),
('ospos_session:d07bd2b0fead66fb20bee592733dd228','127.0.0.1','2026-09-15 14:10:59','__ci_last_regenerate|i:1789481459;csrf_ospos_v4|s:32:\"24f65c2297b4d3e49b49c9857288a696\";'),
('ospos_session:d129013dadc7b7339012b842aa788c8d','127.0.0.1','2026-09-15 14:02:58','__ci_last_regenerate|i:1789480978;csrf_ospos_v4|s:32:\"01874c37a0d6f2deeeb3c65759f46b50\";'),
('ospos_session:d2e4fe65e125d108c2c7ace34f6e05cc','127.0.0.1','2026-09-15 14:23:01','__ci_last_regenerate|i:1789482181;csrf_ospos_v4|s:32:\"308c2846dbe03512ff8d5a3e7dbe657b\";'),
('ospos_session:d4ae035d09199ccadb068223652ffbb8','127.0.0.1','2026-09-15 12:50:47','__ci_last_regenerate|i:1789476647;csrf_ospos_v4|s:32:\"3edacf14909c68a58f3b8f83322a4395\";'),
('ospos_session:d50f38508aa83fc5d639d11a8a52ead4','127.0.0.1','2026-09-15 13:05:20','__ci_last_regenerate|i:1789477520;csrf_ospos_v4|s:32:\"d4ea49dd2f0c6438a794d59458e609e4\";'),
('ospos_session:d5c51796daf21647ed4b355e49ce49bf','127.0.0.1','2026-09-15 13:50:57','__ci_last_regenerate|i:1789480257;csrf_ospos_v4|s:32:\"513a5cbc42f397175f57c2f82ad7ee8e\";'),
('ospos_session:d60525634eb3c662d40feadfc3a736c4','127.0.0.1','2026-09-15 13:01:49','__ci_last_regenerate|i:1789477309;csrf_ospos_v4|s:32:\"ace7dfd971dd219531e08f8ec18a1d56\";'),
('ospos_session:d6cd2c76c2ff84ab1e32a8d055669031','127.0.0.1','2026-09-15 12:45:47','__ci_last_regenerate|i:1789476347;csrf_ospos_v4|s:32:\"f47910ff8d6190eecf6407eabf38e022\";'),
('ospos_session:d7fdc26349da5b6b861f1be50c79383b','127.0.0.1','2026-09-15 13:23:23','__ci_last_regenerate|i:1789478603;csrf_ospos_v4|s:32:\"8f135c88118962303d8253fb17937925\";'),
('ospos_session:d8ba9b42b539e620d2f0d2add4b44f1f','127.0.0.1','2026-09-15 13:30:24','__ci_last_regenerate|i:1789479024;csrf_ospos_v4|s:32:\"1763a0ce2d8ca849b4ce69e88c703770\";'),
('ospos_session:d9eca1c7e7d32e54fd8cc46468863655','127.0.0.1','2026-09-15 12:48:17','__ci_last_regenerate|i:1789476497;csrf_ospos_v4|s:32:\"0167d7d83f89f35e5bbb1099de3c6e22\";'),
('ospos_session:da8328e5ce610f94e5f7584cd6395273','127.0.0.1','2026-09-15 14:00:28','__ci_last_regenerate|i:1789480828;csrf_ospos_v4|s:32:\"86dec9302b84c95e6c5d22439f6ec621\";'),
('ospos_session:db5fb10d12576da58ac3a2626de3b916','127.0.0.1','2026-09-15 12:47:47','__ci_last_regenerate|i:1789476467;csrf_ospos_v4|s:32:\"329efff9bb8ebed3231284b2d8988cbb\";'),
('ospos_session:dbfde937d6ce955d0910635c7aa7aee2','127.0.0.1','2026-09-15 14:05:29','__ci_last_regenerate|i:1789481129;csrf_ospos_v4|s:32:\"1d5d58b5c43b48eecaf2befd0928f464\";'),
('ospos_session:dc38d74c7a3995dc27ccd8ef901a4522','127.0.0.1','2026-09-15 14:05:59','__ci_last_regenerate|i:1789481159;csrf_ospos_v4|s:32:\"3e8557af666743ec26c574ce7e7932b1\";'),
('ospos_session:dcd873f760df4f4e7b176a8afbcce29e','127.0.0.1','2026-09-15 12:44:47','__ci_last_regenerate|i:1789476287;csrf_ospos_v4|s:32:\"bef01856c25a3b92566c69001e361d87\";'),
('ospos_session:dcf45a4de3e32344b57ceeacfe4f46d4','127.0.0.1','2026-09-15 13:49:26','__ci_last_regenerate|i:1789480166;csrf_ospos_v4|s:32:\"1a5595f65ee0135b3e65bb435c7cb232\";'),
('ospos_session:ddd3f865aae017698261e565e4b4ea89','127.0.0.1','2026-09-15 12:57:48','__ci_last_regenerate|i:1789477068;csrf_ospos_v4|s:32:\"940acfff411d99c00de09c459781d67f\";'),
('ospos_session:dfd8457dbc312e1160fba8296964514a','127.0.0.1','2026-09-15 12:56:18','__ci_last_regenerate|i:1789476978;csrf_ospos_v4|s:32:\"631fecb2b95b800c178b724708da9850\";'),
('ospos_session:e30de188a2b6fdd32ed6b2aaa99f72cb','127.0.0.1','2026-09-15 13:46:56','__ci_last_regenerate|i:1789480016;csrf_ospos_v4|s:32:\"a2b6b2de3262e86b8d9f7eb6ad880f05\";'),
('ospos_session:e34e62263befe1029abefcf2ef6eb730','127.0.0.1','2026-09-15 12:53:48','__ci_last_regenerate|i:1789476828;csrf_ospos_v4|s:32:\"50617115f743a7ebdf782a3aace9e391\";'),
('ospos_session:e3e76c69b0bd510a30ebbeb402572d1a','127.0.0.1','2026-09-15 13:32:24','__ci_last_regenerate|i:1789479144;csrf_ospos_v4|s:32:\"ec9d445260e4248056546a156c9d4e1b\";'),
('ospos_session:e5194957a0ea5e0f96ea6f4e74873d95','127.0.0.1','2026-09-15 14:24:31','__ci_last_regenerate|i:1789482271;csrf_ospos_v4|s:32:\"fe49c2c733be77b7d5d1237a8238619b\";'),
('ospos_session:e5a59a965d6570c42b9a3a10abc89a33','127.0.0.1','2026-09-15 13:55:57','__ci_last_regenerate|i:1789480557;csrf_ospos_v4|s:32:\"f27458ddf87bb54bbd3f4c84ef9efaff\";'),
('ospos_session:e6a83dfaedec7766575a811304c0c41e','127.0.0.1','2026-09-15 14:03:28','__ci_last_regenerate|i:1789481008;csrf_ospos_v4|s:32:\"8ed0f64ffc978e865eb5513b4fd9c1ce\";'),
('ospos_session:ea9c8524f625a4edea229ccd62b97383','127.0.0.1','2026-09-15 13:56:27','__ci_last_regenerate|i:1789480587;csrf_ospos_v4|s:32:\"fc8fd05242ba13d4aaa6d12c798f6e83\";'),
('ospos_session:eb2bf9a17501c495c0f4c1ac64eb61f0','127.0.0.1','2026-09-15 13:10:20','__ci_last_regenerate|i:1789477820;csrf_ospos_v4|s:32:\"ad3f755b555c983b3b151966937d6435\";'),
('ospos_session:ed69db2c9a95ffe4d1513c0573673a13','127.0.0.1','2026-09-15 13:57:58','__ci_last_regenerate|i:1789480678;csrf_ospos_v4|s:32:\"81a78dec790f640b58d7d0fee0eeac55\";'),
('ospos_session:ed69dd92de9ba22b86df7985ac5abbfd','127.0.0.1','2026-09-15 13:53:27','__ci_last_regenerate|i:1789480407;csrf_ospos_v4|s:32:\"8d534fccead98e2ee00a84b9f937b11d\";'),
('ospos_session:ee4373a9d743b849c3ecb16e92ffde76','127.0.0.1','2026-09-15 13:40:55','__ci_last_regenerate|i:1789479655;csrf_ospos_v4|s:32:\"7c5bcc74f4a030a443ec1fcdaddd59e6\";'),
('ospos_session:eebb2a520d601b5aeafba4dbed371cca','127.0.0.1','2026-09-15 13:01:19','__ci_last_regenerate|i:1789477279;csrf_ospos_v4|s:32:\"6d0cd1751dc2bfb87734d1ea3b47048a\";'),
('ospos_session:f03c9e70846eb2c1164a3b2b404eb0a7','127.0.0.1','2026-09-15 14:21:00','__ci_last_regenerate|i:1789482060;csrf_ospos_v4|s:32:\"0485e33603579003e478c9413dae1bb0\";'),
('ospos_session:f06864b04d009a0259d788d0b246a036','127.0.0.1','2026-09-15 13:52:57','__ci_last_regenerate|i:1789480377;csrf_ospos_v4|s:32:\"734020f025dbdafabfa26df4729cdd22\";'),
('ospos_session:f1e8a2e8c268acf16b129e636dfb32d3','127.0.0.1','2026-09-15 13:45:26','__ci_last_regenerate|i:1789479926;csrf_ospos_v4|s:32:\"15dc50607ba715118650ad64fd0ca768\";'),
('ospos_session:f2fa9ade3c6b6857182294b5d91ab175','127.0.0.1','2026-09-15 13:39:55','__ci_last_regenerate|i:1789479595;csrf_ospos_v4|s:32:\"c42123496eac14f5edfeb18b94fcf0fa\";'),
('ospos_session:f316fa6ca27feaf8a78de228e3ed0a40','127.0.0.1','2026-09-15 13:51:57','__ci_last_regenerate|i:1789480317;csrf_ospos_v4|s:32:\"51e4f46b24e0a317306316014635dbd1\";'),
('ospos_session:f34b52f32532ac4c5c39b1afe2095e0a','127.0.0.1','2026-09-15 13:11:51','__ci_last_regenerate|i:1789477911;csrf_ospos_v4|s:32:\"c950276c7b7c97605183f1198e043d6e\";'),
('ospos_session:f52a48958bc33b94a888555330b458e1','127.0.0.1','2026-09-15 12:53:18','__ci_last_regenerate|i:1789476798;csrf_ospos_v4|s:32:\"e879cd05644b3db84a8d869154a53100\";'),
('ospos_session:f6a13014a9809beafe9401c955c17d6f','127.0.0.1','2026-09-15 13:48:56','__ci_last_regenerate|i:1789480136;csrf_ospos_v4|s:32:\"4237a741bd231997cbd32598cc4e95f9\";'),
('ospos_session:f878738cd2279463be5107b23b7e38b6','127.0.0.1','2026-09-15 14:22:31','__ci_last_regenerate|i:1789482151;csrf_ospos_v4|s:32:\"024e8c458fade10805894f1af9d15fcc\";'),
('ospos_session:f88a367117aefe2b7aca46f5159b291c','127.0.0.1','2026-09-15 12:54:18','__ci_last_regenerate|i:1789476858;csrf_ospos_v4|s:32:\"b641a4363f927e3584eebce04f557b0b\";'),
('ospos_session:fa46770292d5204f67008f86e1659ec1','127.0.0.1','2026-09-15 14:06:59','__ci_last_regenerate|i:1789481219;csrf_ospos_v4|s:32:\"76ca4888d1e3a5c753a95f09c9ddfb5e\";'),
('ospos_session:fa771590280a9f7c3b6e14e8700b7921','127.0.0.1','2026-09-15 13:27:23','__ci_last_regenerate|i:1789478843;csrf_ospos_v4|s:32:\"abff2b04cbbcd02803254e042101fe4f\";'),
('ospos_session:fb3dbddb21c87d4fa7bb7adf488c8389','127.0.0.1','2026-09-15 13:24:23','__ci_last_regenerate|i:1789478663;csrf_ospos_v4|s:32:\"9efdf64a970ca8ddd62afd81755908f3\";'),
('ospos_session:fc66f3c01985e2a34f6eb6582dc02a7f','127.0.0.1','2026-09-15 13:03:49','__ci_last_regenerate|i:1789477429;csrf_ospos_v4|s:32:\"501c609be8d16b77057a37b0342f0000\";');
/*!40000 ALTER TABLE `ospos_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_stock_locations`
--

DROP TABLE IF EXISTS `ospos_stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_stock_locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_stock_locations`
--

LOCK TABLES `ospos_stock_locations` WRITE;
/*!40000 ALTER TABLE `ospos_stock_locations` DISABLE KEYS */;
INSERT INTO `ospos_stock_locations` VALUES
(1,'stock',0);
/*!40000 ALTER TABLE `ospos_stock_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_suppliers`
--

DROP TABLE IF EXISTS `ospos_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_suppliers` (
  `person_id` int(10) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `agency_name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `tax_id` varchar(32) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  `category` tinyint(1) NOT NULL,
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `account_number` (`account_number`),
  KEY `category` (`category`),
  KEY `company_name` (`company_name`,`deleted`),
  CONSTRAINT `ospos_suppliers_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `ospos_people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_suppliers`
--

LOCK TABLES `ospos_suppliers` WRITE;
/*!40000 ALTER TABLE `ospos_suppliers` DISABLE KEYS */;
INSERT INTO `ospos_suppliers` VALUES
(5,'PakLight','',NULL,'',0,0),
(6,'KM','',NULL,'',0,0);
/*!40000 ALTER TABLE `ospos_suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_categories`
--

DROP TABLE IF EXISTS `ospos_tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_categories` (
  `tax_category_id` int(10) NOT NULL AUTO_INCREMENT,
  `tax_category` varchar(32) NOT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_categories`
--

LOCK TABLES `ospos_tax_categories` WRITE;
/*!40000 ALTER TABLE `ospos_tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_codes`
--

DROP TABLE IF EXISTS `ospos_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_codes` (
  `tax_code_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_code` varchar(32) NOT NULL,
  `tax_code_name` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(255) NOT NULL DEFAULT '',
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_codes`
--

LOCK TABLES `ospos_tax_codes` WRITE;
/*!40000 ALTER TABLE `ospos_tax_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_jurisdictions`
--

DROP TABLE IF EXISTS `ospos_tax_jurisdictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_jurisdictions` (
  `jurisdiction_id` int(11) NOT NULL AUTO_INCREMENT,
  `jurisdiction_name` varchar(255) DEFAULT NULL,
  `tax_group` varchar(32) NOT NULL,
  `tax_type` smallint(2) NOT NULL,
  `reporting_authority` varchar(255) DEFAULT NULL,
  `tax_group_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `cascade_sequence` tinyint(1) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`jurisdiction_id`),
  UNIQUE KEY `tax_jurisdictions_uq1` (`tax_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_jurisdictions`
--

LOCK TABLES `ospos_tax_jurisdictions` WRITE;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_jurisdictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ospos_tax_rates`
--

DROP TABLE IF EXISTS `ospos_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ospos_tax_rates` (
  `tax_rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_tax_code_id` int(11) NOT NULL,
  `rate_tax_category_id` int(10) NOT NULL,
  `rate_jurisdiction_id` int(11) NOT NULL,
  `tax_rate` decimal(15,4) NOT NULL DEFAULT 0.0000,
  `tax_rounding_code` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tax_rate_id`),
  KEY `rate_tax_category_id` (`rate_tax_category_id`),
  KEY `rate_tax_code_id` (`rate_tax_code_id`),
  KEY `rate_jurisdiction_id` (`rate_jurisdiction_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_1` FOREIGN KEY (`rate_tax_category_id`) REFERENCES `ospos_tax_categories` (`tax_category_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_2` FOREIGN KEY (`rate_tax_code_id`) REFERENCES `ospos_tax_codes` (`tax_code_id`),
  CONSTRAINT `ospos_tax_rates_ibfk_3` FOREIGN KEY (`rate_jurisdiction_id`) REFERENCES `ospos_tax_jurisdictions` (`jurisdiction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ospos_tax_rates`
--

LOCK TABLES `ospos_tax_rates` WRITE;
/*!40000 ALTER TABLE `ospos_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ospos_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 13:46:17
